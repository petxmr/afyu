---@diagnostic disable: undefined-global
local CLIENT_FOLDER = "nightx"
local CLIENT_FOLDER_BIN = "nightx/bin"

local Status = Drawing.new("Text")
Status.Visible = true
Status.Text = "Downloading Client files... (/)"
Status.Color = Color3.fromRGB(255, 255, 255)
Status.Center = true
Status.Outline = true
Status.OutlineColor = Color3.fromRGB(1, 1, 1)
Status.Position = Vector2.new(130, 30)
Status.Size = 30
Status.Font = 1

task.wait(2)

Status.Text = "Created `Framework.lua` data file!"

if not isfolder(CLIENT_FOLDER) and not isfolder(CLIENT_FOLDER_BIN) then
    makefolder(CLIENT_FOLDER)
    makefolder(CLIENT_FOLDER_BIN)
    if not isfile(CLIENT_FOLDER_BIN .. "/Framework.lua") then
        writefile(CLIENT_FOLDER_BIN .. "/Framework.lua", "print('hey')")
    end
end

task.wait(2)

Status.Text = "Setup finished!"

task.wait(4)

Status:Remove()

local function get_framework() 
    if isfolder(CLIENT_FOLDER_BIN) then
        local framework = readfile(CLIENT_FOLDER_BIN.."/Framework.lua")
        return framework
    end
end

local framework = get_framework()
loadstring(framework)