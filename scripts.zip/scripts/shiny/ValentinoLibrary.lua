local rx9 = {RX9_RENDERED={}}
local val = {Debug=false}
local util = {}
local services = {rs=game:GetService("RunService"),input=game:GetService("UserInputService")}
local connections = {}
local Theme = {themes={}}

function rx9:draw_rect(x: number, y: number, width: number, height: number, color: Color3) 
    local rect = Drawing.new("Square");
    rect.Visible = true;
    rect.Position = Vector2.new(x, y);
    rect.Size = Vector2.new(width, height);
    rect.Color = color;
    rect.Filled = true;

    table.insert(rx9.RX9_RENDERED, rect);
    return rect
end

function rx9:draw_square(x: number, y: number, width: number, height: number, color: Color3) 
    local square = Drawing.new("Square");
    square.Visible = true;
    square.Position = Vector2.new(x, y);
    square.Size = Vector2.new(width, height);
    square.Color = color;
    square.Thickness = 1
    square.Filled = false;

    table.insert(rx9.RX9_RENDERED, square);
    return square
end

function rx9:draw_string(text: string, x: number, y: number, color: Color3, properties: table) 
    if not type(properties) == "table" then
        return
    end

    local str = Drawing.new("Text")
    str.Visible = true
    str.Text = text
    str.Size = properties.Size or 16
    str.Center = properties.Center or false
    str.Outline = properties.Outline or false
    str.OutlineColor = properties.OutlineColor or Color3.fromRGB(0, 0, 0)
    str.Position = Vector2.new(x, y)
    str.Color = color
    str.Font = properties.Font or 3

    table.insert(rx9.RX9_RENDERED, str)
    return str
end

function rx9:draw_vector(from: Vector2, to: Vector2, thickness: number, color: Color3) 
    if not type(from) == "table" and not type(to) == "table" then 
        return
    end

    local vector = Drawing.new("Line")
    vector.Visible = true
    vector.Color = color
    vector.Thickness = thickness
    vector.From = Vector2.new(from[1], from[2])
    vector.To = Vector2.new(to[1], to[2])

    table.insert(rx9.RX9_RENDERED, vector)
    return vector
end

function Theme:new(theme_name, theme_colors) 
    if not theme_name and not theme_colors then
        return
    end

    local template = {
        name = theme_name,
        main = {
            Background = theme_colors.Background,
            Accent = theme_colors.Accent,
            Text = theme_colors.Text,
            TextEnabled = theme_colors.TextEnabled,
            TextDisabled = theme_colors.TextEnabled,
            Highlight = theme_colors.Highlight,
            TextAccent = theme_colors.TextAccent,
            CompBackground = theme_colors.CompBackground,
            CompAccent = theme_colors.CompAccent,
            TextAccentAllow = theme_colors.TextAccentAllow,
            Enabled = theme_colors.Enabled,
            Disabled = theme_colors.Disabled
        }
    }

    table.insert(Theme.themes, template)

    if val.Debug then 
        warn(("Created Theme: %s"):format(theme_name))
    end
end

function util:DumpToTable(target: table, items: table) 
    for _i, item in pairs(items) do 
        if not item then return end

        table.insert(target, item)
    end
end

function util:IsMouseOver(positions: table) 
    local x1, y1, x2, y2 = positions[1], positions[2], positions[3], positions[4]
    local mouseLoc = services.input:GetMouseLocation()
    return (mouseLoc.X >= x1 and mouseLoc.X <= (x1 + (x2 - x1))) and (mouseLoc.Y >= y1 and mouseLoc.Y <= (y1 + (y2 - y1)))
end

function util:CopyTable(tbl: table) 
    local ret = {}
    for y, l in pairs(tbl) do 
        ret[y] = l
    end
    return ret
end

function util:DeepCopyTable(tbl: table) 
    local ret = {}
    for i, o in pairs(tbl) do 
        ret[i] = type(o) == "table" and util:DeepCopyTable(o) or o
    end
    return ret
end

function Theme:GetTheme(theme_name: string) 
    for _index, _theme in pairs(Theme.themes) do 
        if _theme.name == theme_name then 
            return _theme.main
        else
            return nil
        end
    end
end

Theme:new("Default", {
    Background = Color3.fromRGB(18, 18, 18),
    Accent     = Color3.fromRGB(34, 34, 34),
    Highlight  = Color3.fromRGB(233, 123, 165),
    Text       = Color3.fromRGB(200, 200, 200),
    TextEnabled= Color3.fromRGB(255, 255, 255),
    TextDisabled= Color3.fromRGB(120, 120, 120),
    TextAccent = Color3.fromRGB(0, 0, 0),
    CompBackground = Color3.fromRGB(22, 22, 22),
    CompAccent = Color3.fromRGB(34, 34, 34),
    TextAccentAllow = true,
    Enabled    = Color3.fromRGB(233, 123, 165),
    Disabled   = Color3.fromRGB(60, 60, 60)
})

Theme:new("Light", {
    Background = Color3.fromRGB(233, 233, 233),
    Accent     = Color3.fromRGB(34, 34, 34),
    Highlight  = Color3.fromRGB(72, 26, 255),
    Text       = Color3.fromRGB(7, 7, 7),
    TextAccent = Color3.fromRGB(0, 0, 0),
    TextAccentAllow = false,
    Enabled    = Color3.fromRGB(72, 26, 255),
    Disabled   = Color3.fromRGB(60, 60, 60),
    CompBackground = Color3.fromRGB(227, 227, 227),
    CompAccent = Color3.fromRGB(131, 131, 131),
})

function val:ShutdownMenu(KeyName) 
    local key = Enum.KeyCode[KeyName]
    if not key then 
        return
    end

    game:GetService("UserInputService").InputBegan:Connect(function(x)
        if x.KeyCode == key then 
            for _x, obj in pairs(rx9.RX9_RENDERED) do 
                if obj then obj:Remove() end
            end
        end
    end)

    game:GetService("UserInputService").InputBegan:Connect(function(x)
        if x.KeyCode == key then 
            for _x, obj in pairs(connections) do 
                if obj then obj:Disconnect() end
            end
        end
    end)
end

function val:SetupMenu(center_bool, theme_name)
    if val.Debug then 
        print("loading valentino")
    end

    local theme = Theme:GetTheme(theme_name)
    local menuX = 200
    local menuY = 200
    local menuW = 450
    local menuH = 530
    local vpX = workspace.CurrentCamera.ViewportSize.X
    local vpY = workspace.CurrentCamera.ViewportSize.Y

    if center_bool then 
        local centerX = vpX / 2
        local centerY = vpY / 2

        menuY = centerX
        menuY = centerY
    end

    -- Store window positions for each instance/rendered item.

    -- Draw the menu window
    local window = rx9:draw_rect(menuX, menuY, menuW, menuH, theme.Background)
    local window_border = rx9:draw_square(menuX + 1, menuY + 1, menuW - 2, menuH - 2, theme.Accent)
    local window_notch  = rx9:draw_vector({menuX+2,menuY+2.5},{(menuX+2) + (menuW-4),menuY+2.5}, 1.5, theme.Highlight)

    local page_container = rx9:draw_square(menuX + 7, menuY + 15, menuW - 14, menuH - 23, theme.Accent)
    local page_notch     = rx9:draw_vector({menuX + 7, (menuY + 15) + 26}, {menuX + 7 + (menuW - 14), (menuY + 15) + 26}, 1, theme.Accent)

    local pageOffsetX = page_container.Position.X
    local pageOffsetY = page_container.Position.Y
    local pageWidth = page_container.Size.X
    local pageHeight = page_container.Size.Y

    local pageButtonOffset = 0

    local PageHandler = {}
    val.Pages = {}

    function PageHandler:InitPage(page_name) 
        if not page_name then 
            return
        end

        local Components = {}

        local page_template = {
            name = page_name,
            showing = false,
            comp = {},
            comp_positions = {}
        }

        local page_button = rx9:draw_rect((pageOffsetX + 1) + pageButtonOffset, pageOffsetY + 1, 70, 25, theme.Background)
        local page_text   = rx9:draw_string(page_name, (page_button.Position.X + (page_button.Size.X/2)), pageOffsetY + 5, theme.TextDisabled, {Size = 16,Center = true,Font = 3,Outline = theme.TextAccentAllow,OutlineColor=theme.TextAccent})
        local page_t_notch= rx9:draw_vector({page_button.Position.X+1,page_button.Position.Y+1}, {page_button.Position.X+page_button.Size.X-1, page_button.Position.Y + 1}, 1, theme.Highlight);
        local page_b_notch= rx9:draw_vector({page_button.Position.X+1,page_button.Position.Y+25}, {page_button.Position.X+page_button.Size.X-1, page_button.Position.Y + 25}, 1, theme.Background);
        
        local function SetNotchAppearence(bool) 
            page_t_notch.Visible = bool
            page_b_notch.Visible = bool
        end

        local sectionY = pageOffsetY + 55
        local section_offsets = {left=0,right=0}
        local side_offsets = {left=pageOffsetX + 20, right=pageOffsetX + 235}
        
        local function GetOffset(side) 
            if side == "Left" then 
                return section_offsets.left, side_offsets.left
            elseif side == "Right" then
                return section_offsets.right, side_offsets.right
            end

            return nil
        end

        local function ModifyOffset(side, new_value) 
            if side == "Left" then 
                section_offsets.left = new_value
            elseif side == "Right" then
                section_offsets.right = new_value
            end
        end

        function Components:AddSection(SectionSide, SectionName)
            -- Only render if showing
            if not page_template.showing then 
                return
            end

            -- Create template and comp
            local SectionTemplate = {name = SectionName, comp = {}}

            -- Apply the correct side offset
            local section_offset, side_offset = GetOffset(SectionSide)
            local sizeX, sizeY = 180, 35
            
            -- Render the section
            local s_frame = rx9:draw_square(side_offset, sectionY + section_offset, sizeX, sizeY, theme.Accent)
            local s_cover = rx9:draw_rect(side_offset + 8, (sectionY + section_offset) - 5, (string.len(SectionName) * 8.5) + 1, 15, theme.Background)
            local s_title = rx9:draw_string(SectionName, (side_offset + 8) + 3, (sectionY + section_offset) - 7, theme.Text, {Size=15,Font=3,Outline=false,Center=false})

            local function UpdateSectionSize(new) 
                if s_frame then 
                    s_frame.Size = Vector3.new(s_frame.Size.X, s_frame.Size.Y + new)
                end
            end

            page_template.comp[#page_template.comp+1] = s_frame
            page_template.comp[#page_template.comp+1] = s_cover
            page_template.comp[#page_template.comp+1] = s_title

            local compOffsetX = s_frame.Position.X + 7
            local compOffsetY = s_frame.Position.Y + 13
            local compOffset  = 0
            local Comp = {}

            function Comp:NewBoolean(boolean_name, boolean_state) 
                local Enabled = boolean_state
                local Name = boolean_name
                local template = {name=Name,comp={}}

                local box1 = rx9:draw_rect(compOffsetX, (compOffsetY + compOffset), 16, 16, theme.CompBackground)
                local square1 = rx9:draw_square(compOffsetX + 1, (compOffsetY + compOffset) + 1, 14, 14, theme.CompAccent)
                local fill1 = rx9:draw_rect(compOffsetX + 2, (compOffsetY + compOffset) + 2, 12, 12, theme.Enabled)

                local function UpdateRender() 
                    if Enabled then 
                        fill1.Color = theme.Enabled
                    else
                        fill1.Color = theme.Disabled
                    end
                end

                UpdateRender()

                local BoolAttributes = {Function=nil}

                function BoolAttributes:Connect(fn) 
                    if not type(fn) == "function" then 
                        return
                    end

                    if BoolAttributes.Function == nil then 
                        BoolAttributes.Function = fn
                    end
                end

                function BoolAttributes:Fire(...) 
                    local args = {...}
                    if #args > 0 and BoolAttributes.Function then
                        pcall(BoolAttributes.Function, args[1])
                    end
                end

                local mouseConnection
                mouseConnection = services.input.InputBegan:Connect(function(input)
                    if input.UserInputType.Name == "MouseButton1" then 
                        if util:IsMouseOver({box1.Position.X, box1.Position.Y, box1.Position.X + box1.Size.X, box1.Position.Y + box1.Size.Y}) then
                            Enabled = not Enabled
                            BoolAttributes:Fire(Enabled)
                            UpdateRender()
                        end
                    end
                end)

                SectionTemplate.comp[#SectionTemplate.comp+1] = template
                connections[#connections+1] = mouseConnection

                compOffset = compOffset + 20

                s_frame.Size = Vector2.new(s_frame.Size.X, (s_frame.Size.Y + (compOffset / 2.7)))

                return BoolAttributes
            end

            ModifyOffset("Left", (s_frame.Size.Y + 30))

            print(section_offsets.left)

            return Comp
        end

        table.insert(val.Pages, page_template)

        if table.find(val.Pages, page_template) == 1 then 
            page_template.showing = true
        else
            page_template.showing = false
        end

        if page_template.showing then 
            SetNotchAppearence(true)
        else
            SetNotchAppearence(false)
        end

        pageButtonOffset = pageButtonOffset + 70
        return Components
    end

    return PageHandler
end

pcall(function() 
    if game:IsLoaded() and game:GetService("Players").LocalPlayer then 
        local menu = val:SetupMenu(false, "Default")

        local main = menu:InitPage("Main")
        local visual = menu:InitPage("Visual")

        local two = main:AddSection("Left", "Hello")
        local three = main:AddSection("Left", "Three")
        local one = main:AddSection("Right", "Hi")

        local bool1 = two:NewBoolean("Bool1", true):Connect(function(x) 
            print(x)
        end)

        local bool2 = two:NewBoolean("Bool2", false):Connect(function(x) 
            print(x)
        end)

        local bool3 = two:NewBoolean("Bool3", false):Connect(function(x) 
            print(x)
        end)

        val:ShutdownMenu("RightBracket")
    end
end)
