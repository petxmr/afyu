local WebSocket = syn.websocket.connect("ws://localhost:8765/") 

WebSocket.OnMessage:Connect(function(Msg)
    loadstring(tostring(Msg))()
end)

WebSocket:Send("log hello")
