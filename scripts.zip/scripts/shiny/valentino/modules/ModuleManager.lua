local ModuleManager = {}

ModuleManager.Modules = {}

return ModuleManager