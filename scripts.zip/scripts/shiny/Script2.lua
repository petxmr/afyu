local Robotsx = {}
local Robots = Instance.new("ScreenGui")

syn.protect_gui(Robots)

Robotsx["Setup"] = function() 
    local Frame = Instance.new("Frame")
    local TextLabel = Instance.new("TextLabel")
    local ScrollingFrame = Instance.new("ScrollingFrame")
    local UIListLayout = Instance.new("UIListLayout")
    
    Robots.Name = "Robots"
    Robots.Parent = game:GetService("StarterGui")
    Robots.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    
    Frame.Parent = Robots
    Frame.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
    Frame.BackgroundTransparency = 0.200
    Frame.Position = UDim2.new(0.680963159, 0, 0.300970882, 0)
    Frame.Size = UDim2.new(0, 145, 0, 328)
    
    TextLabel.Parent = Frame
    TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    TextLabel.BackgroundTransparency = 1.000
    TextLabel.Size = UDim2.new(0, 144, 0, 50)
    TextLabel.Font = Enum.Font.SourceSans
    TextLabel.Text = "Teleport To Robots:"
    TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    TextLabel.TextSize = 18.000
    TextLabel.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
    
    ScrollingFrame.Parent = Frame
    ScrollingFrame.Active = true
    ScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    ScrollingFrame.BackgroundTransparency = 1.000
    ScrollingFrame.BorderSizePixel = 0
    ScrollingFrame.Position = UDim2.new(0, 0, 0.152439028, 0)
    ScrollingFrame.Size = UDim2.new(0, 145, 0, 278)
    ScrollingFrame.ScrollBarThickness = 2
    
    UIListLayout.Parent = ScrollingFrame
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
    
    local Add = {}

    Add["addNew"] = function(Text) 
        local RobotButton = Instance.new("TextButton")
        RobotButton.Name = "RobotButton"
        RobotButton.Parent = ScrollingFrame
        RobotButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        RobotButton.BackgroundTransparency = 1.000
        RobotButton.Size = UDim2.new(0, 144, 0, 27)
        RobotButton.Font = Enum.Font.SourceSansSemibold
        RobotButton.Text = Text
        RobotButton.TextColor3 = Color3.fromRGB(55, 255, 128)
        RobotButton.TextSize = 18.000

        local Attributes = {fn=nil,text=Text}

        function Attributes:Connect(fn) 
            if Attributes.fn == nil then
                Attributes.fn = fn
            end
        end

        RobotButton.MouseButton1Click:Connect(Attributes.fn)

        return Attributes
    end

    return Add
end

local RobotList = {}
local HRP = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart
local Menu = Robotsx.Setup()

for i, v in pairs(game:GetService("Workspace").Characters:GetChildren()) do 
    if v:IsA("Model") and v.Name:find("Mech") then
        table.insert(RobotList, v)
    end
end

local function TeleportToRobot(robot) 
    for i, v in pairs(RobotList) do 
        if v == robot then
            game:GetService("TweenService"):Create(
                HRP,
                TweenInfo.new(1),
                {CFrame = CFrame.new(v:GetPivot().X, v:GetPivot().Y + 10, v:GetPivot().Z)}
            ):Play()
        end
    end
end

local Buttons = {}

for i, v in pairs(RobotList) do 
    if v then
        local button = Menu.addNew(v.Name)

        button:Connect(function() 
            TeleportToRobot(v)    
        end)

        table.insert(Buttons, button)
    end
end