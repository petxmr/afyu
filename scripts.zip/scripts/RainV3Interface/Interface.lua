local Services    = {}
local Interface   = {}
local Animation   = {}
local Utility     = {}
local Event       = {}
local EventBus    = {}

function Event:new()
    local obj = {}
    obj.listeners = {}

    setmetatable(obj, self)
    self.__index = self
    return obj
end

function Event:addListener(listener)
    table.insert(self.listeners, listener)
end

function Event:removeListener(listener)
    for i, h in ipairs(self.listeners) do 
        if h == listener then
            table.remove(self.listeners, i)
            break
        end
    end
end

function Event:invoke(...) 
    for _, listener in ipairs(self.listeners) do 
        listener(...)
    end
end

function EventBus:registerEvent(eventName) 
    self.events[eventName] = Event:new()
end

function EventBus:unregisterEvent(eventName)
    self.events[eventName] = nil
end

function EventBus:subscribe(eventName, listener) 
    local event = self.events[eventName]
    if (event) then
        event:addListener(listener)
    end
end

function EventBus:unsubscribe(eventName, listener)
    local event = self.events[eventName]
    if (event) then
        event:removeListener(listener)
    end
end

function EventBus:invokeEvent(eventName, ...) 
    local event = self.events[eventName]
    if (event) then
        event:invoke(...)
    end
end

function Utility:InitiateServices() 
    local service_list = { "UserInputServer", "RunService", "ContextActionService", "TweenService" }
    for i, service in pairs(service_list) do 
        table.insert(Services, game:GetService(service))
    end
end

function Utility:StopConnections(c) 
    for i, connection in pairs(c) do 
        if (connection ~= nil) then 
            connection:Disconnect()
        end
    end
end

function Animation:new(instance, options) 
    local methods = {}

    local tw = Services["TweenService"]
    
    repeat task.wait() until tw

    local options = options or {
        Properties = options.Properties or { },
        Style = options.Style or "Quart",
        Direction = options.Direction or "InOut",
        Time = options.Time or 1,
        Reverses = options.Reverses or false,
        DelayTime = options.DelayTime or 0,
        RepeatCount = options.RepeatCount or 0
    }

    local style, direction = Enum.EasingStyle[options.Style], Enum.EasingDirection[options.Direction]
    local t, reverses, delay_time, rep_count = options.Time, options.Reverses, options.DelayTime, options.RepeatCount
    local tween = tw:Create(instance, TweenInfo.new(
        t, style, direction, rep_count, reverses, delay_time
    ))

    function methods:OnFinished(callback) 
        if (tween ~= nil) then
            tween.Completed:Connect(callback)
        end
    end

    tween:Play()

    return methods
end

function Interface:BeginMenu(Options) 
    repeat task.wait() until game:IsLoaded()

    local flags = {side_bar_open=false,components_active=true,open=true}

    local client      = game:GetService("Players").LocalPlayer
    local connections = {}
    local gui         = {}
    local api         = {}
    local tabs        = {}

    local screen      = Instance.new("ScreenGui", game:GetService("CoreGui")); screen.Name = string.gsub(tostring(client.UserId, ".", function(c) return string.char(math.random(32, 126)) end))

    do
        function api:new_event(name, fn) 
            local event = Event:new()
            event:addListener(fn)
            EventBus:registerEvent(name)
            EventBus:subscribe(name, fn)
        end

        function api:unbind_event(name, fn) 
            EventBus:unregisterEvent(name)
            EventBus:unsubscribe(name, fn)
        end

        function api:update_component_gradient(frame, stroke, gradient)
            local function updateGradient(mousePosition)
                local frameSize = frame.AbsoluteSize
                local mouseX = mousePosition.X - frame.AbsolutePosition.X
                local gradientOffset = mouseX / frameSize.X

                stroke.Color = ColorSequence.new({
                    ColorSequenceKeypoint.new(0, Color3.new(0.137255, 0.137255, 0.137255)),
                    ColorSequenceKeypoint.new(gradientOffset, Color3.new(0.223529, 0.223529, 0.223529)),
                    ColorSequenceKeypoint.new(1, Color3.new(0.137255, 0.137255, 0.137255))
                })
            end

            frame.MouseEnter:Connect(function()
                frame.MouseMoved:Connect(function()
                    updateGradient(game:GetService("UserInputService"):GetMouseLocation())
                end)
            end)

            frame.MouseLeave:Connect(function()
                gradient.Color = ColorSequence.new(Color3.new(0.137255, 0.137255, 0.137255))
            end)
        end
    end

    do

        

        function gui:CreateTab(name) 
            local tab_class = {
                Name = name,
                Showing = false,
                UpdatePage = nil
            }



        end
    end

    local function handle_shutdown()

        Utility:StopConnections(connections)
    end

    return gui
end