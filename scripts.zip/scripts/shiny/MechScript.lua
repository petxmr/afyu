local function Mod() 
    local gmt = getrawmetatable(game);
    setreadonly(gmt, false);
    local oldIndex = gmt.__index;

    gmt.__index = function(instance, value) 
        if tostring(instance) == "Ammo" then 
            if tostring(value) == "Value" then 
                return 999;    
            end    
        end
        return oldIndex(instance, value);    
    end
end

local function ShootMech(position) 
        

    local ohTable1 = {
        [1] = -1492.9754638671875, 122.6954574584961, 729.7603759765625
    }
    local ohTable2 = {
        [1] = -1682.986328125, 121.8281021118164, 526.3178100585938
    }
    local ohTable3 = {
        [1] = workspace.Terrain
    }
    local ohTable4 = {
        [1] = -1492.9754638671875, 122.6954574584961, 729.7603759765625
    }
    local ohTable5 = {
        [1] = -0.09224493056535721, 0.9943032264709473, -0.05340495705604553
    }

    game:GetService("ReplicatedStorage").Events.ShootEvent:FireServer(ohTable1, ohTable2, ohTable3, ohTable4, ohTable5)
end 

local function ReloadGun()
    game:GetService("ReplicatedStorage").Events.ReloadEvent:FireServer()
end

local player = game:GetService("Players").LocalPlayer.Character
local hrp = player.HumanoidRootPart

local function tweenplayer(new_loc) 
    if player.Humanoid.Health ~= 0 then
        local tween = game:GetService("TweenService")
        tween:Create(
            hrp,
            TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
            {CFrame = new_loc}
        ):Play()
    end
end

while true do
    local mech = nil
    for i, v in pairs(game:GetService("Workspace").Characters:GetChildren()) do 
        if v:IsA("Model") and v.Name:find("Mech") and v.MechScript then
            mech = v
        end    
    end

    task.wait(.1)

    ShootMech(Vector3.new(mech:GetPivot().X, mech:GetPivot().Y, mech:GetPivot().Z))
    ReloadGun()

    task.wait(1)
end