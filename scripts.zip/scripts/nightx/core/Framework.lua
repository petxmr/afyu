local function get_utility_link(utility_name) 
    sucess, result = pcall(function() return game:HttpGet("https://raw.githubusercontent.com/blinxduh/nightx-files/main/"..utility_name..".lua?token=GHSAT0AAAAAAB3DXK3QCOSLDZY3JJUSAYHGY6ZL2VQ") end)
    if not sucess then
        error('failed to get / connect to github : nightx/'..utility_name.." : "..result)
    end
    return result
end

local module = get_utility_link("Module")

print(module)