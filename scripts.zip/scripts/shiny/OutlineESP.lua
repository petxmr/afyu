local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

for _index, player in pairs(Players:GetPlayers()) do
    local name = Drawing.new("Text")
    name.Visible = false
    name.Text = ""
    name.Size = 16
    name.Center = true
    name.Outline = false
    name.OutlineColor = Color3.fromRGB(0, 0, 0)
    name.Font = 3

    local outline = Instance.new("Highlight")
    outline.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    outline.Enabled = false
    outline.FillColor = Color3.fromRGB(255, 255, 255)
    outline.FillTransparency = 1
    outline.Name = tostring(syn.crypt.base64.encode("outline lol"))
    outline.OutlineColor = Color3.fromRGB(103, 2, 255)
    outline.OutlineTransparency = 0
    outline.Parent = nil

    function UpdateOutline() 
        if player ~= LocalPlayer and player.Character and player.Character.Humanoid.Health ~= 0 and not player.Character:FindFirstChildOfClass("Highlight") then
            outline.Parent = player.Character
            outline.Enabled = true
            name.Visible = true
            name.Position = Vector2.new(player.Character.PrimaryPart.Position.X, player.Character.PrimaryPart.Position.Y + 2)
            name.Text = string.format("[%s]", player.Name)
        else
            outline.Enabled = false
        end
    end
    coroutine.wrap(UpdateOutline)()
end

Players.PlayerAdded:Connect(function(player) 
    for _index, player in pairs(Players:GetPlayers()) do
        local name = Drawing.new("Text")
        name.Visible = false
        name.Text = ""
        name.Size = 16
        name.Center = true
        name.Outline = false
        name.OutlineColor = Color3.fromRGB(0, 0, 0)
        name.Font = 3
    
        local outline = Instance.new("Highlight")
        outline.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
        outline.Enabled = false
        outline.FillColor = Color3.fromRGB(255, 255, 255)
        outline.FillTransparency = 1
        outline.Name = tostring(syn.crypt.base64.encode("outline lol"))
        outline.OutlineColor = Color3.fromRGB(103, 2, 255)
        outline.OutlineTransparency = 0
        outline.Parent = nil
    
        function UpdateOutline() 
            if player ~= LocalPlayer and player.Character and player.Character.Humanoid.Health ~= 0 and not player.Character:FindFirstChildOfClass("Highlight") then
                outline.Parent = player.Character
                outline.Enabled = true
                name.Visible = true
                name.Position = Vector2.new(player.Character.PrimaryPart.Position.X, player.Character.PrimaryPart.Position.CFrame.Y + 2)
                name.Text = string.format("[%s]", player.Name)
            else
                outline.Enabled = false
            end
        end
        coroutine.wrap(UpdateOutline)()
    end
end)
