--[[
    main.lua

    experiment with lua code here, execute lua code with synapse execute

]]

local Players = game:GetService("Players")

local function GetGun(All, GunName) 
    for _i, player in pairs(Players:GetPlayers()) do
        if not All then
            if player:FindFirstChild("Folder") then
                if player.Folder:FindFirstChild(GunName) then
                   local gun = player.Folder:FindFirstChild(GunName)
       
                   local newGun = gun:Clone()
                   newGun.Name = GunName
                   newGun.Parent = Players.LocalPlayer.Folder
                   break
                end
            else
                error("Player does not have folder.")
            end
        else
            if player:FindFirstChild("Folder") then
                for _x, item in pairs(player.Folder:GetChildren()) do
                    if item:IsA("BoolValue") and item:FindFirstChild("InventoryEquipRemote") then
                        if Players.LocalPlayer.Folder then
                            local gun = item:Clone()
                            gun.Name = item.Name
                            gun.Parent = Players.LocalPlayer.Folder
                        end
                    end
                end
            end
        end
    end

    for _, gun in pairs(Players.LocalPlayer.Folder:GetChildren()) do 
        if gun then
            gun.InventoryEquipRemote:FireServer()
        end
    end

end

local function SpawnCar(CarType)

    local Prop = "Chassis"
    local CarType = CarType or "Camaro"

    game:GetService("ReplicatedStorage").GarageSpawnVehicle:FireServer(Prop, CarType)
end

-- SpawnCar("Jeep")
-- GetGun(true, nil)





