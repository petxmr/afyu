local Module = {}

Module.__index = Module
Module.__modules = {}

Module['init'] = function(ModuleName, ModuleDescription, ModuleSettings) 
    local ModuleSettings = ModuleSettings or {}
    local ModuleName = ModuleName
    local ModuleDescription = ModuleDescription
    local Tree = {
        ['Name'] = ModuleName,
        ['Description'] = ModuleDescription,
        ['Settings'] = {}
    }

    table.insert(Module.__modules, Tree)

    for i, setting in next, ModuleSettings do
        setting.ParentName = ModuleName
        if setting.Type == "Number" or "number" then
            local Struct = {
                ['Name'] = setting.Name,
                ['Description'] = setting.Description,
                ['Type'] = setting.Type,
                ['Value'] = setting.Value,
                ['Minimum'] = setting.Minimum,
                ['Maximum'] = setting.Maximum 
            }

            for i, module in next, Module.__modules do 
                if module.Name == setting.ParentName then
                    table.insert(module.Settings, Struct)
                end
            end
        elseif setting.Type == "Mode" or "mode" then
            local Struct = {
                ['Name'] = setting.Name,
                ['Description'] = setting.Description,
                ['Type'] = setting.Type,
                ['Modes'] = setting.Modes,
                ['Value'] = setting.Value,
            }

            for i, module in next, Module.__modules do 
                if module.Name == setting.ParentName then
                    table.insert(module.Settings, Struct)
                end
            end
        elseif setting.Type == "Boolean" or "boolean" then
            local Struct = {
                ['Name'] = setting.Name,
                ['Description'] = setting.Description,
                ['Type'] = setting.Type,
                ['Value'] = setting.Value,
            }

            for i, module in next, Module.__modules do 
                if module.Name == setting.ParentName then
                    table.insert(module.Settings, Struct)
                end
            end
        end
    end
end

Module['getModuleSettings'] = function(ModuleName) 
    for i, module in next, Module.__modules do 
        if module.Name == ModuleName then
            return module.Settings
        end
    end
end

Module['getModules'] = function() 
    return Module.__modules
end

return Module