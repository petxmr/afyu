local function NewStack()
    return {""}
end

local function AddString(stack, s) 
    table.insert(stack, s)
    for i = table.getn(stack) - 1, 1, -1 do
        if string.len(stack[i]) > string.len(stack[i + 1]) then
            break
        end
        stack[i] = stack[i] .. table.remove(stack)
    end
end

local function IdToB64(ID) 
    return syn.crypt.base64.encode(ID);
end

local function GenerateKey(UserID) 
    local ID = IdToB64(UserID);
    local CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890"
    local CSTACK = {}
    local KEY = ""
    local STACK = NewStack()
    for i = 0, string.len(CHARS), 1, -1 do
        table.insert(CSTACK, CHARS[i])
        local FirstQuad = ""
        while string.len(FirstQuad) <= 6 do
            FirstQuad = ("%s%s%s%s%s%s:"):format()
        end
    end
    return KEY
end