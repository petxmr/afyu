local function DrawObject(text) 
    local Object = Drawing.new("Text")
    Object.Visible = true
    Object.Text = text
    Object.Size = 16
    Object.Center = false
    Object.Outline = false
end