---@diagnostic disable: undefined-global, deprecated
-- shiny.lua
local repo = 'https://raw.githubusercontent.com/wally-rblx/LinoriaLib/main/'

local Library = loadstring(game:HttpGet(repo .. 'Library.lua'))()
local ThemeManager = loadstring(game:HttpGet(repo .. 'addons/ThemeManager.lua'))()
local SaveManager = loadstring(game:HttpGet(repo .. 'addons/SaveManager.lua'))()

local Window = Library:CreateWindow({
    Title = 'shiny.wtf - v1',
    Center = true, 
    AutoShow = true,
})

local tabs = {
    automatic = Window:AddTab("Automation"),
    ['UI Settings'] = Window:AddTab('UI Settings')
}

local coinDelay = 0.1
local coinEnabled = false
local coinThread = nil
local coins = tabs.automatic:AddLeftGroupbox('Coins')
coins:AddToggle('CoinEnable', {
    Text = 'Enable',
    Default = coinEnabled,
    Tooltip = 'Enable coin farm'
})

coins:AddSlider('CoinDelay', {
    Text = 'Delay',
    Default = coinDelay,
    Min = 0.1,
    Max = 5,
    Rounding = 1,
    Compact = false
})

coinThread = function() 
    while Toggles.CoinEnable.Value do
        task.wait(Options.CoinDelay.Value)
        game:GetService("ReplicatedStorage").Remote:FireServer("Roll2")
    end
end

Toggles.CoinEnable:OnChanged(coinThread)

local sellDelay = 0.1
local sellEnabled = false
local sellThread = nil
local sell = tabs.automatic:AddLeftGroupbox('Auto Sell')
sell:AddToggle('SellEnable', {
    Text = 'Enable',
    Default = sellEnabled,
    Tooltip = 'Enable auto sell'
})

sell:AddSlider('SellDelay', {
    Text = 'Delay',
    Default = sellDelay,
    Min = 0.1,
    Max = 5,
    Rounding = 1,
    Compact = false
})

sellThread = function() 
    while Toggles.SellEnable.Value do
        task.wait(Options.SellDelay.Value)
        game:GetService("ReplicatedStorage").Remote:FireServer("Sell2", workspace.Sells.Lobby)  
    end
end

Toggles.SellEnable:OnChanged(sellThread)

local gemDelay = 0.5
local gemEnabled = false
local gemThread = nil
local gem = tabs.automatic:AddRightGroupbox('Auto Gem')
gem:AddToggle('GemEnable', {
    Text = 'Enable',
    Default = gemEnabled,
    Tooltip = 'Enable auto gem (enable/disable if stops)'
})

gem:AddSlider('GemDelay', {
    Text = 'Delay',
    Default = gemDelay,
    Min = 0.5,
    Max = 5,
    Rounding = 1,
    Compact = false
})

gemThread = function() 
    while Toggles.GemEnable.Value do
        task.wait(Options.GemDelay.Value)
        local hrp = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart

        for i, v in pairs(game:GetService("Workspace").Gems:GetChildren()) do 
            if v:IsA("Part") and v ~= nil and v.Name:find("Gem") and v.TouchInterest then 
                firetouchinterest(hrp, v, 0)
                task.wait(Options.GemDelay.Value)
                firetouchinterest(hrp, v, 1)
            end
        end

        game:GetService("Workspace").Gems.Changed:Connect(function()
            for i, v in pairs(game:GetService("Workspace").Gems:GetChildren()) do 
                if v:IsA("Part") and v ~= nil and v.Name:find("Gem") and v.TouchInterest then 
                    firetouchinterest(hrp, v, 0)
                    task.wait(Options.GemDelay.Value)
                    firetouchinterest(hrp, v, 1)
                end
            end  
        end)
    end
end

Toggles.GemEnable:OnChanged(gemThread)