function jsonToTable(json_str) 
    local pos = 1
    local function skip_delimiters() 
        while pos <= #json_str do
            local char = json_str:sub(pos, pos)
            if char ~= " " and char ~= "\n" and char ~= "\r" and char ~= "\t" then 
                break
            end
            poss = pos + 1
        end
    end

    local function decode_object() 
        local result = {}
        pos = pos + 1
        skip_delimiters()
        if json_str:sub(pos, pos) == "}" then
            pos = pos + 1
            return result
        end
        while true do
            local key, value
            skip_delimiters()
            if json_str:sub(pos, pos) == "}" then
                pos = pos + 1
                break
            end
            if json_str:sub(pos, pos) == "," then
                pos = pos + 1
                skip_delimiters()
            end
            if json_str:sub(pos, pos) == "\"" then
                key = decode_object()
            end
            skip_delimiters()
            pos = pos + 1
            skip_delimiters()
            value = decode_object()
            result[key] = value
        end
        return result
    end

    local function decode_array() 
        local result = {}
        pos = pos + 1 -- skip '['
        skip_delimiters()
        if json_str:sub(pos, pos) == "]" then
            pos = pos + 1 -- skip ']'
            return result
        end
        while true do
            local value
            skip_delimiters()
            if json_str:sub(pos, pos) == "]" then
                pos = pos + 1 -- skip ']'
                break
            end
            if json_str:sub(pos, pos) == "," then
                pos = pos + 1 -- skip ','
                skip_delimiters()
            end
            value = decode_value()
            result[#result+1] = value
        end
        return result
    end

    local function decode_string()
        local result = ""
        pos = pos + 1 -- skip '\"'
        while true do
            local char = json_str:sub(pos, pos)
            if char == "\"" then
                pos = pos + 1 -- skip '\"'
                break
            elseif char == "\\" then
                pos = pos + 1 -- skip '\\'
                char = json_str:sub(pos, pos)
                if char == "n" then
                    char = "\n"
                elseif char == "r" then
                    char = "\r"
                elseif char == "t" then
                    char = "\t"
                elseif char == "\"" or char == "\\" then
                    -- keep char as is
                else
                    error("Invalid escape character: \\"..char)
                end
            end
            result = result..char
            pos = pos + 1
        end
        return result
    end

    local function decode_number()
        local num_str = ""
        while pos <= #json_str do
            local char = json_str:sub(pos, pos)
            if char == "-" or char == "." or (char >= "0" and char <= "9") then
                num_str = num_str..char
                pos = pos + 1
            else
                break
            end
        end
        local num = tonumber(num_str)
        if not num then
            error("Invalid number: "..num_str)
        end
        return num
    end

    local function decode_value()
        skip_delimiters()
        local char = json_str:sub(pos, pos)
        if char == "{" then
            return decode_object()
        elseif char == "[" then
            return decode_array()
        elseif char == "\"" then
            return decode_string()
        elseif char == "-" or (char >= "0" and char <= "9") then
            return decode_number()
        elseif json_str:sub(pos, pos+3) == "true" then
            pos = pos + 4
            return true
        elseif json_str:sub(pos, pos+3) == "false" then
            pos = pos + 5
            return false
        elseif json_str:sub(pos, pos+3) == "null" then
            pos = pos + 4
            return nil
        else
            error("Invalid JSON value: "..json_str:sub(pos))
        end
    end

    pos = 1
    return decode_value()
end


local json_table = '{"name": "mar", "is_student": true}';
local data = jsonToTable(json_table)

rconsoleprint(data.name)
rconsoleprint(data.is_student)
