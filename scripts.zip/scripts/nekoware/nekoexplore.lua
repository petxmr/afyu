local Objects = game:GetChildren()
local Explorer = {}

function Explorer:InitExplorer()
    local important_objects = {
        "Workspace", "Players", "Lighting", "MaterialService", "ReplicatedFirst", "ReplicatedStorage", 
        "ServerScriptService", "ServerStorage", "StarterGui", "StarterPack", "StarterPlayer", "Teams", "SoundService",
        "Chat", "TextChatService"
    }

    local Explorer = Instance.new("ScreenGui")
    local Properties = Instance.new("Frame")
    local UIListLayout = Instance.new("UIListLayout")
    local UIListLayout_2 = Instance.new("UIListLayout")
    local Window = Instance.new("Frame")
    local UIListLayout_3 = Instance.new("UIListLayout")
    local FilterField = Instance.new("Frame")
    local TextBox = Instance.new("TextBox")
    local TextBoxPadding = Instance.new("UIPadding")
    local Connections = {}

    local SelectedObject = nil

    Explorer.Name = "Explorer"
    Explorer.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
    Explorer.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

    Properties.Name = "Properties"
    Properties.Parent = Explorer
    Properties.Active = true
    Properties.AnchorPoint = Vector2.new(1, 0)
    Properties.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
    Properties.BorderSizePixel = 0
    Properties.Position = UDim2.new(1, 0, 0, 0)
    Properties.Size = UDim2.new(0, 250, 1, 0)
    Properties.Visible = true
    Properties.ClipsDescendants = true

    local function CreateNewProperty(PName, PValue) 
        local Property = Instance.new("Frame")
        local PropertyLayout = Instance.new("UIListLayout")
        local PropertyValue = Instance.new("TextLabel")
        local PropertyValuePadding = Instance.new("UIPadding")
        local PropertyName = Instance.new("TextLabel")
        local PropertyNamePadding = Instance.new("UIPadding")

        Property.Name = "Property"
        Property.Parent = Properties
        Property.BackgroundColor3 = Color3.fromRGB(46, 46, 46)
        Property.BorderColor3 = Color3.fromRGB(34, 34, 34)
        Property.Size = UDim2.new(1, 0, 0, 20)

        PropertyLayout.Name = "PropertyLayout"
        PropertyLayout.Parent = Property
        PropertyLayout.FillDirection = Enum.FillDirection.Horizontal
        PropertyLayout.SortOrder = Enum.SortOrder.LayoutOrder

        PropertyValue.Name = "PropertyValue"
        PropertyValue.Parent = Property
        PropertyValue.BackgroundColor3 = Color3.fromRGB(46, 46, 46)
        PropertyValue.BorderColor3 = Color3.fromRGB(34, 34, 34)
        PropertyValue.Size = UDim2.new(0.5, 0, 1, 0)
        PropertyValue.Font = Enum.Font.SourceSans
        
        -- if (SelectedObject[]) then 
        --     PropertyValue.Text = "nil"
        -- else
        --     PropertyValue.Text = PValue
        -- end

        for i, obj in pairs(important_objects) do 
            if (SelectedObject.ClassName == obj) then 
                if (PropertyName == "Parent") then
                    PropertyValue.Text = "game.Name"
                else
                    PropertyValue.Text = PValue
                end
            end
        end

        PropertyValue.TextColor3 = Color3.fromRGB(232, 232, 232)
        PropertyValue.TextSize = 14.000
        PropertyValue.TextXAlignment = Enum.TextXAlignment.Left

        PropertyValuePadding.Name = "PropertyValuePadding"
        PropertyValuePadding.Parent = PropertyValue
        PropertyValuePadding.PaddingBottom = UDim.new(0, 2)
        PropertyValuePadding.PaddingLeft = UDim.new(0, 7)

        PropertyName.Name = "PropertyName"
        PropertyName.Parent = Property
        PropertyName.BackgroundColor3 = Color3.fromRGB(46, 46, 46)
        PropertyName.BorderColor3 = Color3.fromRGB(34, 34, 34)
        PropertyName.Size = UDim2.new(0.5, 0, 1, 0)
        PropertyName.Font = Enum.Font.SourceSans

        for i, obj in pairs(important_objects) do 
            if (SelectedObject.ClassName == obj) then 
                if (PropertyName == "Parent") then
                    PropertyName.Text = "game.Name"
                else
                    PropertyName.Text = PName
                end
            end
        end

        PropertyName.TextColor3 = Color3.fromRGB(232, 232, 232)
        PropertyName.TextSize = 14.000
        PropertyName.TextXAlignment = Enum.TextXAlignment.Left

        PropertyNamePadding.Name = "PropertyNamePadding"
        PropertyNamePadding.Parent = PropertyName
        PropertyNamePadding.PaddingBottom = UDim.new(0, 2)
        PropertyNamePadding.PaddingLeft = UDim.new(0, 8)
    end

    local BaseProperties = {
        "Name",
        "Parent"
    }

    local function UpdateProperties() 
        for i, v in pairs(Properties:GetChildren()) do 
            if (v:IsA("Frame")) then v:Destroy() end
        end

        for i, prop in pairs(BaseProperties) do 
            if (SelectedObject[prop]) then
                CreateNewProperty(prop, SelectedObject[prop])
            end
        end
    end

    UIListLayout.Parent = Properties
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder

    UIListLayout_2.Parent = Explorer
    UIListLayout_2.FillDirection = Enum.FillDirection.Horizontal
    UIListLayout_2.HorizontalAlignment = Enum.HorizontalAlignment.Right
    UIListLayout_2.SortOrder = Enum.SortOrder.LayoutOrder

    Window.Name = "Window"
    Window.Parent = Explorer
    Window.Active = true
    Window.AnchorPoint = Vector2.new(1, 0)
    Window.BackgroundColor3 = Color3.fromRGB(27, 27, 27)
    Window.BorderSizePixel = 0
    Window.Position = UDim2.new(1, 0, 0, 0)
    Window.Size = UDim2.new(0, 300, 1, 0)

    UIListLayout_3.Parent = Window
    UIListLayout_3.SortOrder = Enum.SortOrder.LayoutOrder

    FilterField.Name = "FilterField"
    FilterField.Parent = Window
    FilterField.BackgroundColor3 = Color3.fromRGB(27, 27, 27)
    FilterField.BorderSizePixel = 0
    FilterField.Size = UDim2.new(1, 0, 0, 40)

    TextBox.Parent = FilterField
    TextBox.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    TextBox.BorderSizePixel = 0
    TextBox.Position = UDim2.new(0.0266666673, 0, 0.174999997, 0)
    TextBox.Size = UDim2.new(0, 286, 0, 26)
    TextBox.ClearTextOnFocus = false
    TextBox.FontFace = Font.fromId(12187365364)
    TextBox.PlaceholderColor3 = Color3.fromRGB(178, 178, 178)
    TextBox.PlaceholderText = "Filter workspace"
    TextBox.Text = ""
    TextBox.TextColor3 = Color3.fromRGB(202, 202, 202)
    TextBox.TextSize = 16.000
    TextBox.TextXAlignment = Enum.TextXAlignment.Left

    TextBoxPadding.Name = "TextBoxPadding"
    TextBoxPadding.Parent = TextBox
    TextBoxPadding.PaddingLeft = UDim.new(0, 8)

    local function CreateGameObject(Name)
        local GameObject = Instance.new("Frame")
        local GameObjectName = Instance.new("TextLabel")
        local UIPadding = Instance.new("UIPadding")
        local UIListLayout = Instance.new("UIListLayout")
        local ExpandSize = 0
        local RestSize = 25
        local Expanded = false

        GameObject.Name = "GameObject"
        GameObject.Parent = Window
        GameObject.BackgroundColor3 = Color3.fromRGB(27, 27, 27)
        GameObject.BorderSizePixel = 0
        GameObject.Size = UDim2.new(1, 0, 0, RestSize)
        GameObject.Visible = true
        GameObject.ClipsDescendants = true

        local function UpdateSize() 
            if (Expanded) then
                GameObject.Size = UDim2.new(1, 0, 0, ExpandSize + 25)
            else
                GameObject.Size = UDim2.new(1, 0, 0, RestSize)
            end
        end

        GameObjectName.Name = "GameObjectName"
        GameObjectName.Parent = GameObject
        GameObjectName.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        GameObjectName.BackgroundTransparency = 1.000
        GameObjectName.Size = UDim2.new(1, 0, 0, 25)
        GameObjectName.FontFace = Font.fromId(12187365364)
        GameObjectName.Text = Name
        GameObjectName.TextColor3 = Color3.fromRGB(239, 239, 239)
        GameObjectName.TextSize = 15.000
        GameObjectName.TextXAlignment = Enum.TextXAlignment.Left

        UIPadding.Parent = GameObjectName
        UIPadding.PaddingLeft = UDim.new(0, 15)

        UIListLayout.Parent = GameObject
        UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder

        local ObjectChildren = game[Name]:GetChildren()

        local function CreateDescendant(BName) 
            local ObjectDescendant = Instance.new("Frame")
            local ObjectDescendantName = Instance.new("TextLabel")
            local ObjectDescendantNamePadding = Instance.new("UIPadding")

            ObjectDescendant.Name = "ObjectDescendant"
            ObjectDescendant.Parent = GameObject
            ObjectDescendant.BackgroundColor3 = Color3.fromRGB(27, 27, 27)
            ObjectDescendant.BorderSizePixel = 0
            ObjectDescendant.Position = UDim2.new(0.0266666673, 0, 1, 0)
            ObjectDescendant.Size = UDim2.new(1, 0, 0, 25)
            ObjectDescendant.Visible = true

            ObjectDescendantName.Name = "ObjectDescendantName"
            ObjectDescendantName.Parent = ObjectDescendant
            ObjectDescendantName.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            ObjectDescendantName.BackgroundTransparency = 1.000
            ObjectDescendantName.Size = UDim2.new(1, 0, 0, 25)
            ObjectDescendantName.FontFace = Font.fromId(12187365364)
            ObjectDescendantName.Text = BName
            ObjectDescendantName.TextColor3 = Color3.fromRGB(239, 239, 239)
            ObjectDescendantName.TextSize = 15.000
            ObjectDescendantName.TextXAlignment = Enum.TextXAlignment.Left

            ObjectDescendantNamePadding.Name = "ObjectDescendantNamePadding"
            ObjectDescendantNamePadding.Parent = ObjectDescendantName
            ObjectDescendantNamePadding.PaddingLeft = UDim.new(0, 25)

            local Entered = false
            ObjectDescendantName.MouseEnter:Connect(function() Entered = true; ObjectDescendant.BackgroundColor3 = Color3.fromRGB(35, 35, 35) end)
            ObjectDescendantName.MouseLeave:Connect(function() Entered = false; ObjectDescendant.BackgroundColor3 = Color3.fromRGB(27, 27, 27) end)
            Connections.click = game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessedEvent)
                if input.UserInputType.Name == "MouseButton1" and Entered then
                    SelectedObject = game[Name][BName]
                    UpdateProperties()
                end
            end)

            ExpandSize += 25
        end

        for i, chld in pairs(ObjectChildren) do
            CreateDescendant(chld.Name)
        end

        local Entered = false
        GameObjectName.MouseEnter:Connect(function() Entered = true; GameObject.BackgroundColor3 = Color3.fromRGB(35, 35, 35) end)
        GameObjectName.MouseLeave:Connect(function() Entered = false; GameObject.BackgroundColor3 = Color3.fromRGB(27, 27, 27) end)
        Connections.click = game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessedEvent)
            if input.UserInputType.Name == "MouseButton1" and Entered then
                SelectedObject = game[Name]
                UpdateProperties()

                Expanded = not Expanded
                UpdateSize()
            end
        end)
    end

    for i, obj in pairs(Objects) do 
        if table.find(important_objects, obj.Name) then
            CreateGameObject(obj.Name)
        end
    end

    Connections.quit = game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessedEvent)
        if input.KeyCode == Enum.KeyCode.RightBracket then
            Explorer:Destroy()

            for i, c in pairs(Connections) do 
                c:Disconnect()
            end
        end
    end)
end

Explorer:InitExplorer()