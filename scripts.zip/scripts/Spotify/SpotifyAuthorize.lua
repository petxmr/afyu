local http = game:GetService("HttpService");
local request = syn.request;

local client_id = "d2bf7fff66024840881291a43d2288e7";
local client_sec = "5b63c6bd586642de9e316cf76cbdc033";

local options = {
    Url = "https://accounts.spotify.com/api/token",
    Method = "POST",
    Headers = {
        ["Authorization"] = ("Basic %s:%s"):format(client_id, client_sec),
        ["form"] = http:JSONEncode("grant_type: 'client_credentials'")
    },
}

local response = http:JSONDecode(request(options).Body)
for i, v in pairs(response) do 
    print(i, v)
end