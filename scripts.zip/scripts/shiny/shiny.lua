local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:wait()
local humanoid = character:WaitForChild("Humanoid")

local tweening = false

local function tweenToLook()
    if not character or not humanoid or not humanoid.Parent then
        return
    end
    
    local camera = workspace.CurrentCamera
    local angle = camera.CFrame:ToEulerAnglesYXZ().y
    local distance = 10
    
    local lookVector = camera.CFrame.lookVector
    local lookCFrame = CFrame.new(camera.CFrame.p, camera.CFrame.p + lookVector * distance)
    
    tweening = true
    local tween = game:GetService("TweenService"):Create(character.PrimaryPart, TweenInfo.new(0.5), {CFrame = lookCFrame})
    tween:Play()
    tween.Completed:Wait()
    tweening = false
end

game:GetService("RunService").RenderStepped:Connect(function()
    if tweening then
        humanoid:Move(Vector3.new(0, 0, 0))
    end
end)

game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.E then
        tweenToLook()
    end
end)
