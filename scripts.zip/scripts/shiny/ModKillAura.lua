-- [[ Libraries ]]
local Knit = loadstring(game:HttpGet("https://raw.githubusercontent.com/marjoriex/Knit-Framework/main/FrameworkHelper.lua", true))()
local Lib  = loadstring(game:HttpGet("https://raw.githubusercontent.com/matas3535/PoopLibrary/main/Library.lua", true))()

-- [[ Load Knit ]]
Knit:Load()

--[[ Variables ]]
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

--[[ Modules ]]
local Sword = Knit:GetController("SwordController")
local Attack = nil

--[[ Bools / Toggles ]]
local AutoAttack = false
local AutoPetAttack = false
local AutoCollectDrop = false

--[[ Ints / Ranges ]]
local AutoAttackDelay = .1
local AutoCollectDropDelay = .5

--[[ Mod ]]
local Client = {}

local function getClosestMob() 
    local mob = nil
    local distance = math.huge
    local entities = game:GetService("Workspace").RENDER.ENTITIES:GetChildren()
    for _index, entity in pairs(entities) do 
        local pos = entity:GetPivot().Position
        local mag = LocalPlayer:DistanceFromCharacter(pos)
        if mag < distance then 
            distance = mag
            mob = entity
        end
    end
    return mob
end

function Client:AutoAttack() 
    while task.wait(AutoAttackDelay) do 
        if AutoAttack then 
            local entity = getClosestMob()
        
            if not entity then 
                return
            end
    
            Sword:Hit(entity.Name, "Enemy")
            LocalPlayer.Character:PivotTo(entity:GetPivot() + entity:GetPivot().LookVector * 3.6)
        end
    end
end

function Client:AutoCollectDrop() 
    while task.wait(AutoCollectDropDelay) do 
        for _index, drop in pairs(game:GetService("Workspace").DROPS:GetChildren()) do 
            if #game:GetService("Workspace").DROPS:GetChildren() > 0 then 
                drop:PivotTo(LocalPlayer.Character.HumanoidRootPart:GetPivot())
            end
        end
    end
end

local window = Lib:New({Name = "shiny.wtf | Realms! Simulator", Accent = Color3.fromRGB(82, 25, 240)})

local main = window:Page({Name = "Main"})
local visual = window:Page({Name = "Visual"})
local Settings = window:Page({Name = "Settings"})

local autoAttackMain = main:Section({Name = "Auto Attack", Side = "Left"})
local autoCollectDropMain = main:Section({Name = "Auto Collect Drops", Side = "Right"})

autoAttackMain:Toggle({Name = "Enable", Default = AutoAttack, Pointer = "AutoAttack_Enabled"})
autoAttackMain:Slider({Name = "Delay", Minimum = 0, Maximum = 5, Default = AutoAttackDelay, Decimals = 0.1})


