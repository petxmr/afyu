local export = {}
local this   = {}

this.Name = nil
this.KeyBind = nil
this.Enabled = false

export['New'] = function(ModuleName: string, ModuleKey: Enum.KeyCode) 
    this.Name = ModuleName
    this.KeyBind = ModuleKey
    this.Enabled = this.Enabled

    local ModuleMethods = {}

    ModuleMethods.OnEnabled = nil
    ModuleMethods.OnDisabled = nil

    ModuleMethods['getName'] = function() 
        return this.Name
    end

    ModuleMethods['getKeybind'] = function() 
        return this.KeyBind
    end

    ModuleMethods['setKeybind'] = function(NewKey: Enum.KeyCode) 
        this.KeyBind = NewKey
    end

    ModuleMethods['isEnabled'] = function() 
        return this.Enabled
    end

    ModuleMethods['toggle'] = function() 
        this.Enabled = not this.Enabled

        if (this.Enabled) then
            ModuleMethods.OnEnabled();
        else
            ModuleMethods.OnDisabled();
        end 
    end

    return ModuleMethods
end

return export