local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

local function RenderOutline(parent) 
    local outline = Instance.new("Highlight")
    outline.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    outline.Enabled = false
    outline.FillColor = Color3.fromRGB(255, 255, 255)
    outline.FillTransparency = 1
    outline.Name = tostring(syn.crypt.base64.encode("outline lol"))
    outline.OutlineColor = Color3.fromRGB(103, 2, 255)
    outline.OutlineTransparency = 0
    outline.Parent = parent

    return outline
end


