local support = { }
local interface = { }
local client = game:GetService("Players").LocalPlayer

function support:SecureGuiObject(obj) 
    if syn.protect_gui then 
        obj.Parent = game:GetService("CoreGui")
        syn.protect_gui(obj)
    elseif gethui then
        obj.Parent = gethui()
    else
        obj.Parent = client.PlayerGui
        error("Gui object is unprotected!")
    end
end

function support:GetCurrentFont(font_id) 
    return Font.fromId(font_id)
end

function interface:BeginMenu(MenuOptions) 
    local MenuOptions = MenuOptions or {
        Title = MenuOptions.Title or "nekohub ui suite",
        Configuration = MenuOptions.Configuration or {
            Folder = MenuOptions.Configuration.Folder or "nekohub",
            MainFile = MenuOptions.Configuration.MainFile or "nekohub/main.json",
            SaveStates = MenuOptions.Configuration.SaveStates or false
        }
    }

    local WindowElements = { }
    local ElementObjects = { Sections = { } }
    local ElementHandler = { }
    local CFont = support:GetCurrentFont(12187365364)

    local NekohubLibrary = Instance.new("ScreenGui")
    NekohubLibrary.Name = syn.crypt.base64.encode(client.UserId)
    NekohubLibrary.ResetOnSpawn = false
    support:SecureGuiObject(NekohubLibrary)

    WindowElements.Window = Instance.new("Frame")
    WindowElements.WindowCorner = Instance.new("UICorner")
    WindowElements.WindowLayout = Instance.new("UIListLayout")
    WindowElements.WindowTopPanel = Instance.new("ImageLabel")
    WindowElements.WindowTopPanelLayout = Instance.new("UIListLayout")
    WindowElements.WindowTopPanelLeftContainer = Instance.new("Frame")
    WindowElements.WindowTitle = Instance.new("TextLabel")
    WindowElements.WindowTitlePadding = Instance.new("UIPadding")
    WindowElements.WindowTopPanelRightContainer = Instance.new("Frame")
    WindowElements.WindowTopPanelRightContainerPadding = Instance.new("UIPadding")
    WindowElements.WindowMinimise = Instance.new("Frame")
    WindowElements.WindowMinimiseIcon = Instance.new("ImageLabel")
    WindowElements.WindowClose = Instance.new("Frame")
    WindowElements.WindowCloseIcon = Instance.new("ImageLabel")
    WindowElements.WindowTopPanelRightContainerLayout = Instance.new("UIGridLayout")
    WindowElements.WindowSearch = Instance.new("Frame")
    WindowElements.WindowSearchIcon = Instance.new("ImageLabel")
    WindowElements.WindowElementContainer = Instance.new("Frame")
    WindowElements.AWindowSearchArea = Instance.new("Frame")
    WindowElements.WindowElementContainerLayout = Instance.new("UIListLayout")
    WindowElements.WindowElementsCont = Instance.new("ScrollingFrame")
    WindowElements.WindowElementsLayout = Instance.new("UIListLayout")
    WindowElements.WindowElementsPadding = Instance.new("UIPadding")
    WindowElements.SearchFrame = Instance.new("Frame")
    WindowElements.SearchFrameCorner = Instance.new("UICorner")
    WindowElements.SearchFrameBox = Instance.new("TextBox")
    WindowElements.SearchFrameBoxPadding = Instance.new("UIPadding")

    WindowElements.Window.Name = "Window"
    WindowElements.Window.Parent = NekohubLibrary
    WindowElements.Window.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
    WindowElements.Window.ClipsDescendants = true
    WindowElements.Window.Position = UDim2.new(0.308736205, 0, 0.16626212, 0)
    WindowElements.Window.Size = UDim2.new(0, 450, 0, 550)
    
    WindowElements.WindowCorner.Name = "WindowCorner"
    WindowElements.WindowCorner.Parent = WindowElements.Window
    
    WindowElements.WindowLayout.Name = "WindowLayout"
    WindowElements.WindowLayout.Parent = WindowElements.Window
    WindowElements.WindowLayout.SortOrder = Enum.SortOrder.LayoutOrder
    
    WindowElements.WindowTopPanel.Name = "WindowTopPanel"
    WindowElements.WindowTopPanel.Parent = WindowElements.Window
    WindowElements.WindowTopPanel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowTopPanel.BackgroundTransparency = 1.000
    WindowElements.WindowTopPanel.Size = UDim2.new(1, 0, 0, 55)
    WindowElements.WindowTopPanel.Image = "rbxassetid://13216846037"
    WindowElements.WindowTopPanel.ImageColor3 = Color3.fromRGB(236, 236, 236)
    
    WindowElements.WindowTopPanelLayout.Name = "WindowTopPanelLayout"
    WindowElements.WindowTopPanelLayout.Parent = WindowElements.WindowTopPanel
    WindowElements.WindowTopPanelLayout.FillDirection = Enum.FillDirection.Horizontal
    WindowElements.WindowTopPanelLayout.SortOrder = Enum.SortOrder.LayoutOrder
    
    WindowElements.WindowTopPanelLeftContainer.Name = "WindowTopPanelLeftContainer"
    WindowElements.WindowTopPanelLeftContainer.Parent = WindowElements.WindowTopPanel
    WindowElements.WindowTopPanelLeftContainer.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowTopPanelLeftContainer.BackgroundTransparency = 1.000
    WindowElements.WindowTopPanelLeftContainer.ClipsDescendants = true
    WindowElements.WindowTopPanelLeftContainer.Size = UDim2.new(0.5, 0, 1, 0)
    
    WindowElements.WindowTitle.Name = "WindowTitle"
    WindowElements.WindowTitle.Parent = WindowElements.WindowTopPanelLeftContainer
    WindowElements.WindowTitle.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowTitle.BackgroundTransparency = 1.000
    WindowElements.WindowTitle.Position = UDim2.new(0, 0, 0.309090912, 0)
    WindowElements.WindowTitle.Size = UDim2.new(1, 0, 0.379999995, 0)
    WindowElements.WindowTitle.FontFace = CFont
    WindowElements.WindowTitle.Text = "Window Title"
    WindowElements.WindowTitle.TextColor3 = Color3.fromRGB(220, 220, 220)
    WindowElements.WindowTitle.TextScaled = true
    WindowElements.WindowTitle.TextSize = 24.000
    WindowElements.WindowTitle.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowTitle.TextStrokeTransparency = 0.930
    WindowElements.WindowTitle.TextWrapped = true
    WindowElements.WindowTitle.TextXAlignment = Enum.TextXAlignment.Left
    
    WindowElements.WindowTitlePadding.Name = "WindowTitlePadding"
    WindowElements.WindowTitlePadding.Parent = WindowElements.WindowTitle
    WindowElements.WindowTitlePadding.PaddingLeft = UDim.new(0, 15)
    
    WindowElements.WindowTopPanelRightContainer.Name = "WindowTopPanelRightContainer"
    WindowElements.WindowTopPanelRightContainer.Parent = WindowElements.WindowTopPanel
    WindowElements.WindowTopPanelRightContainer.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowTopPanelRightContainer.BackgroundTransparency = 1.000
    WindowElements.WindowTopPanelRightContainer.Size = UDim2.new(0.5, 0, 1, 0)
    
    WindowElements.WindowTopPanelRightContainerPadding.Name = "WindowTopPanelRightContainerPadding"
    WindowElements.WindowTopPanelRightContainerPadding.Parent = WindowElements.WindowTopPanelRightContainer
    WindowElements.WindowTopPanelRightContainerPadding.PaddingRight = UDim.new(0, 15)
    
    WindowElements.WindowMinimise.Name = "WindowMinimise"
    WindowElements.WindowMinimise.Parent = WindowElements.WindowTopPanelRightContainer
    WindowElements.WindowMinimise.AnchorPoint = Vector2.new(0.5, 0.5)
    WindowElements.WindowMinimise.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowMinimise.BackgroundTransparency = 1.000
    WindowElements.WindowMinimise.Size = UDim2.new(0, 30, 0, 30)
    
    WindowElements.WindowMinimiseIcon.Name = "WindowMinimiseIcon"
    WindowElements.WindowMinimiseIcon.Parent = WindowElements.WindowMinimise
    WindowElements.WindowMinimiseIcon.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowMinimiseIcon.BackgroundTransparency = 1.000
    WindowElements.WindowMinimiseIcon.Size = UDim2.new(1, 0, 1, 0)
    WindowElements.WindowMinimiseIcon.Image = "rbxassetid://13217117556"
    WindowElements.WindowMinimiseIcon.ImageColor3 = Color3.fromRGB(214, 214, 214)
    WindowElements.WindowMinimiseIcon.ScaleType = Enum.ScaleType.Fit
    
    WindowElements.WindowClose.Name = "WindowClose"
    WindowElements.WindowClose.Parent = WindowElements.WindowTopPanelRightContainer
    WindowElements.WindowClose.AnchorPoint = Vector2.new(0.5, 0.5)
    WindowElements.WindowClose.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowClose.BackgroundTransparency = 1.000
    WindowElements.WindowClose.Size = UDim2.new(0, 30, 0, 30)
    
    WindowElements.WindowCloseIcon.Name = "WindowCloseIcon"
    WindowElements.WindowCloseIcon.Parent = WindowElements.WindowClose
    WindowElements.WindowCloseIcon.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowCloseIcon.BackgroundTransparency = 1.000
    WindowElements.WindowCloseIcon.Size = UDim2.new(1, 0, 1, 0)
    WindowElements.WindowCloseIcon.Image = "rbxassetid://13217132852"
    WindowElements.WindowCloseIcon.ScaleType = Enum.ScaleType.Fit
    
    WindowElements.WindowTopPanelRightContainerLayout.Name = "WindowTopPanelRightContainerLayout"
    WindowElements.WindowTopPanelRightContainerLayout.Parent = WindowElements.WindowTopPanelRightContainer
    WindowElements.WindowTopPanelRightContainerLayout.HorizontalAlignment = Enum.HorizontalAlignment.Right
    WindowElements.WindowTopPanelRightContainerLayout.VerticalAlignment = Enum.VerticalAlignment.Center
    WindowElements.WindowTopPanelRightContainerLayout.CellSize = UDim2.new(0, 30, 0, 30)
    WindowElements.WindowTopPanelRightContainerLayout.StartCorner = Enum.StartCorner.TopRight
    
    WindowElements.WindowSearch.Name = "WindowSearch"
    WindowElements.WindowSearch.Parent = WindowElements.WindowTopPanelRightContainer
    WindowElements.WindowSearch.AnchorPoint = Vector2.new(0.5, 0.5)
    WindowElements.WindowSearch.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowSearch.BackgroundTransparency = 1.000
    WindowElements.WindowSearch.Size = UDim2.new(0, 30, 0, 30)
    
    WindowElements.WindowSearchIcon.Name = "WindowSearchIcon"
    WindowElements.WindowSearchIcon.Parent = WindowElements.WindowSearch
    WindowElements.WindowSearchIcon.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowSearchIcon.BackgroundTransparency = 1.000
    WindowElements.WindowSearchIcon.Size = UDim2.new(1, 0, 1, 0)
    WindowElements.WindowSearchIcon.Image = "rbxassetid://13217353196"
    WindowElements.WindowSearchIcon.ScaleType = Enum.ScaleType.Fit
    
    WindowElements.WindowElementContainer.Name = "WindowElementContainer"
    WindowElements.WindowElementContainer.Parent = WindowElements.Window
    WindowElements.WindowElementContainer.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.WindowElementContainer.BackgroundTransparency = 1.000
    WindowElements.WindowElementContainer.Position = UDim2.new(-0.00444444455, 0, 0.423636377, 0)
    WindowElements.WindowElementContainer.Size = UDim2.new(1, 0, 1, -55)
    
    WindowElements.AWindowSearchArea.Name = "AWindowSearchArea"
    WindowElements.AWindowSearchArea.Parent = WindowElements.WindowElementContainer
    WindowElements.AWindowSearchArea.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.AWindowSearchArea.BackgroundTransparency = 1.000
    WindowElements.AWindowSearchArea.ClipsDescendants = true
    WindowElements.AWindowSearchArea.Position = UDim2.new(0, 0, 0.100000001, 0)
    WindowElements.AWindowSearchArea.Size = UDim2.new(1, 0, 0, 40)

    WindowElements.WindowElementContainerLayout.Name = "WindowElementContainerLayout"
    WindowElements.WindowElementContainerLayout.Parent = WindowElements.WindowElementContainer
    WindowElements.WindowElementContainerLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    WindowElements.WindowElementContainerLayout.Padding = UDim.new(0, 10)
    
    WindowElements.Name = "WindowElements"
    WindowElements.Parent = WindowElements.WindowElementContainer
    WindowElements.Active = true
    WindowElements.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.BackgroundTransparency = 1.000
    WindowElements.BorderSizePixel = 0
    WindowElements.Position = UDim2.new(0.0111111114, 0, 0.101010099, 0)
    WindowElements.Selectable = false
    WindowElements.Size = UDim2.new(1, -10, 1, -55)
    WindowElements.CanvasSize = UDim2.new(0, 0, 0, 30)
    WindowElements.ScrollBarThickness = 3
    
    WindowElements.WindowElementsLayout.Name = "WindowElementsLayout"
    WindowElements.WindowElementsLayout.Parent = WindowElements.WindowElementsCont
    WindowElements.WindowElementsLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    WindowElements.WindowElementsLayout.Padding = UDim.new(0, 10)
    
    WindowElements.WindowElementsPadding.Name = "WindowElementsPadding"
    WindowElements.WindowElementsPadding.Parent = WindowElements.WindowElementsCont
    WindowElements.WindowElementsPadding.PaddingTop = UDim.new(0, 5)

    WindowElements.SearchFrame.Name = "SearchFrame"
    WindowElements.SearchFrame.Parent = WindowElements.AWindowSearchArea
    WindowElements.SearchFrame.AnchorPoint = Vector2.new(0.5, 0.5)
    WindowElements.SearchFrame.BackgroundColor3 = Color3.fromRGB(31, 31, 31)
    WindowElements.SearchFrame.Position = UDim2.new(0.5, 0, 0.5, 0)
    WindowElements.SearchFrame.Size = UDim2.new(1, -10, 0, 30)

    WindowElements.SearchFrameCorner.CornerRadius = UDim.new(0, 3)
    WindowElements.SearchFrameCorner.Name = "SearchFrameCorner"
    WindowElements.SearchFrameCorner.Parent = WindowElements.SearchFrame

    WindowElements.SearchFrameBox.Name = "SearchFrameBox"
    WindowElements.SearchFrameBox.Parent = WindowElements.SearchFrame
    WindowElements.SearchFrameBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.SearchFrameBox.BackgroundTransparency = 1.000
    WindowElements.SearchFrameBox.ClipsDescendants = true
    WindowElements.SearchFrameBox.Size = UDim2.new(1, 0, 1, 0)
    WindowElements.SearchFrameBox.ClearTextOnFocus = false
    WindowElements.SearchFrameBox.FontFace = CFont
    WindowElements.SearchFrameBox.PlaceholderColor3 = Color3.fromRGB(90, 90, 90)
    WindowElements.SearchFrameBox.PlaceholderText = "Search 'aimbot'..."
    WindowElements.SearchFrameBox.Text = ""
    WindowElements.SearchFrameBox.TextColor3 = Color3.fromRGB(116, 116, 116)
    WindowElements.SearchFrameBox.TextSize = 15.000
    WindowElements.SearchFrameBox.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
    WindowElements.SearchFrameBox.TextXAlignment = Enum.TextXAlignment.Left

    WindowElements.SearchFrameBoxPadding.Name = "SearchFrameBoxPadding"
    WindowElements.SearchFrameBoxPadding.Parent = WindowElements.SearchFrameBox
    WindowElements.SearchFrameBoxPadding.PaddingLeft = UDim.new(0, 10)
    WindowElements.SearchFrameBoxPadding.PaddingRight = UDim.new(0, 10)

    function ElementHandler:CreateSection(SectionName) 
        local SectionName = SectionName or "Section Name"

        local SectionY = 35
        local SectionOpen = true
        local SectionYOffset = SectionY

        ElementObjects.Sections[SectionName] = { }
        ElementObjects.Sections[SectionName].Elements = { }
        ElementObjects.Sections[SectionName].SectionElement = Instance.new("Frame")
        ElementObjects.Sections[SectionName].SectionElementCorner = Instance.new("UICorner")
        ElementObjects.Sections[SectionName].ASectionElementText = Instance.new("TextLabel")
        ElementObjects.Sections[SectionName].SectionElementPadding = Instance.new("UIPadding")
        ElementObjects.Sections[SectionName].SectionElementIcon = Instance.new("ImageButton")
        ElementObjects.Sections[SectionName].SectionElementActivator = Instance.new("TextButton")
        ElementObjects.Sections[SectionName].SectionElementLayout = Instance.new("UIListLayout")

        ElementObjects.Sections[SectionName].SectionElement.Name = "SectionElement"
        ElementObjects.Sections[SectionName].SectionElement.Parent = WindowElements.WindowElementsCont
        ElementObjects.Sections[SectionName].SectionElement.BackgroundColor3 = Color3.fromRGB(31, 31, 31)
        ElementObjects.Sections[SectionName].SectionElement.ClipsDescendants = true
        ElementObjects.Sections[SectionName].SectionElement.Position = UDim2.new(0.0227272734, 0, 0.0113636367, 0)
        ElementObjects.Sections[SectionName].SectionElement.Size = UDim2.new(1, -20, 0, SectionY)

        local function UpdateSectionSize() 
            game:GetService("TweenService"):Create(ElementObjects.Sections[SectionName].SectionElement, TweenInfo.new(.2), {
                Size = UDim2.new(1, -20, 0, SectionYOffset)
            }):Play()
        end

        local function ToggleSectionSize() 
            if SectionOpen then
                game:GetService("TweenService"):Create(ElementObjects.Sections[SectionName].SectionElement, TweenInfo.new(.2), {
                    Size = UDim2.new(1, -20, 0, SectionYOffset)
                }):Play()
            else
                game:GetService("TweenService"):Create(ElementObjects.Sections[SectionName].SectionElement, TweenInfo.new(.2), {
                    Size = UDim2.new(1, -20, 0, SectionY)
                }):Play()
            end
        end
        
        ElementObjects.Sections[SectionName].SectionElementCorner.CornerRadius = UDim.new(0, 3)
        ElementObjects.Sections[SectionName].SectionElementCorner.Name = "SectionElementCorner"
        ElementObjects.Sections[SectionName].SectionElementCorner.Parent = ElementObjects.Sections[SectionName].SectionElement
        
        ElementObjects.Sections[SectionName].ASectionElementText.Name = "ASectionElementText"
        ElementObjects.Sections[SectionName].ASectionElementText.Parent = ElementObjects.Sections[SectionName].SectionElement
        ElementObjects.Sections[SectionName].ASectionElementText.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        ElementObjects.Sections[SectionName].ASectionElementText.BackgroundTransparency = 1.000
        ElementObjects.Sections[SectionName].ASectionElementText.Position = UDim2.new(0, 0, 0.0505050495, 0)
        ElementObjects.Sections[SectionName].ASectionElementText.Size = UDim2.new(1, 0, 0, 35)
        ElementObjects.Sections[SectionName].ASectionElementText.FontFace = CFont
        ElementObjects.Sections[SectionName].ASectionElementText.Text = "Section Name"
        ElementObjects.Sections[SectionName].ASectionElementText.TextColor3 = Color3.fromRGB(173, 173, 173)
        ElementObjects.Sections[SectionName].ASectionElementText.TextSize = 17.000
        ElementObjects.Sections[SectionName].ASectionElementText.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
        ElementObjects.Sections[SectionName].ASectionElementText.TextWrapped = true
        ElementObjects.Sections[SectionName].ASectionElementText.TextXAlignment = Enum.TextXAlignment.Left
        
        ElementObjects.Sections[SectionName].SectionElementPadding.Name = "SectionElementPadding"
        ElementObjects.Sections[SectionName].SectionElementPadding.Parent = ElementObjects.Sections[SectionName].ASectionElementText
        ElementObjects.Sections[SectionName].SectionElementPadding.PaddingLeft = UDim.new(0, 15)
        
        ElementObjects.Sections[SectionName].SectionElementIcon.Name = "SectionElementIcon"
        ElementObjects.Sections[SectionName].SectionElementIcon.Parent = ElementObjects.Sections[SectionName].ASectionElementText
        ElementObjects.Sections[SectionName].SectionElementIcon.AnchorPoint = Vector2.new(0.5, 0.5)
        ElementObjects.Sections[SectionName].SectionElementIcon.BackgroundTransparency = 1.000
        ElementObjects.Sections[SectionName].SectionElementIcon.Position = UDim2.new(1, -15, 0.5, 1)
        ElementObjects.Sections[SectionName].SectionElementIcon.Size = UDim2.new(0, 25, 0, 25)
        ElementObjects.Sections[SectionName].SectionElementIcon.ZIndex = 2
        ElementObjects.Sections[SectionName].SectionElementIcon.Image = "rbxassetid://3926305904"
        ElementObjects.Sections[SectionName].SectionElementIcon.ImageColor3 = Color3.fromRGB(94, 94, 94)
        ElementObjects.Sections[SectionName].SectionElementIcon.ImageRectOffset = Vector2.new(564, 284)
        ElementObjects.Sections[SectionName].SectionElementIcon.ImageRectSize = Vector2.new(36, 36)
        
        ElementObjects.Sections[SectionName].SectionElementActivator.Name = "SectionElementActivator"
        ElementObjects.Sections[SectionName].SectionElementActivator.Parent = ElementObjects.Sections[SectionName].ASectionElementText
        ElementObjects.Sections[SectionName].SectionElementActivator.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        ElementObjects.Sections[SectionName].SectionElementActivator.BackgroundTransparency = 1.000
        ElementObjects.Sections[SectionName].SectionElementActivator.Position = UDim2.new(-0.0314769149, 0, -0.666666687, 0)
        ElementObjects.Sections[SectionName].SectionElementActivator.Size = UDim2.new(0, 415, 0, 34)
        ElementObjects.Sections[SectionName].SectionElementActivator.FontFace = CFont
        ElementObjects.Sections[SectionName].SectionElementActivator.Text = ""
        ElementObjects.Sections[SectionName].SectionElementActivator.TextColor3 = Color3.fromRGB(0, 0, 0)
        ElementObjects.Sections[SectionName].SectionElementActivator.TextSize = 14.000
        
        ElementObjects.Sections[SectionName].SectionElementLayout.Name = "SectionElementLayout"
        ElementObjects.Sections[SectionName].SectionElementLayout.Parent = ElementObjects.Sections[SectionName].SectionElement
        ElementObjects.Sections[SectionName].SectionElementLayout.Padding = UDim.new(0, 5)

        ElementObjects.Sections[SectionName].SectionElementActivator.MouseButton2Click:Connect(function()
            if ElementObjects.Sections[SectionName].SectionElementActivator.Visible then
                SectionOpen = not SectionOpen
                local suc, req = pcall(ToggleSectionSize)
                if not suc then
                    error(("nekohub ui suite callback error: %s"):format(req))
                end
            end
        end)

        local SectionElements = { }

        function SectionElements:CreateBoolean(BooleanOptions) 
            local BooleanOptions = BooleanOptions or {
                Name = BooleanOptions.Name or "Boolean Name",
                Default = BooleanOptions.Default or { false },
                OnChanged = BooleanOptions.OnChanged or function(value) 
                    print(value)
                end
            }

            local Name = BooleanOptions.Name
            local Enabled = BooleanOptions.Default or BooleanOptions.Default[1]
            local Elements = ElementObjects.Sections[SectionName].Elements

            Elements.BooleanElement = Instance.new("Frame")
            Elements.BooleanElementFrame = Instance.new("Frame")
            Elements.BooleanElementFrameCorner = Instance.new("UICorner")
            Elements.BooleanElementFrameText = Instance.new("TextLabel")
            Elements.BooleanElementFrameTextPadding = Instance.new("UIPadding")
            Elements.BooleanElementFrameActivator = Instance.new("TextButton")
            Elements.BooleanElementFrameDisplay = Instance.new("Frame")
            Elements.BooleanElementFrameDisplayCorner = Instance.new("UICorner")

            Elements.BooleanElement.Name = "BooleanElement"
            Elements.BooleanElement.Parent = Elements.SectionElement
            Elements.BooleanElement.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Elements.BooleanElement.BackgroundTransparency = 1.000
            Elements.BooleanElement.Size = UDim2.new(1, 0, 0, 30)
            
            Elements.BooleanElementFrame.Name = "BooleanElementFrame"
            Elements.BooleanElementFrame.Parent = Elements.BooleanElement
            Elements.BooleanElementFrame.AnchorPoint = Vector2.new(0.5, 0.5)
            Elements.BooleanElementFrame.BackgroundColor3 = Color3.fromRGB(27, 27, 27)
            Elements.BooleanElementFrame.Position = UDim2.new(0.5, 0, 0.5, 0)
            Elements.BooleanElementFrame.Size = UDim2.new(1, -10, 0, 30)
            
            Elements.BooleanElementFrameCorner.CornerRadius = UDim.new(0, 3)
            Elements.BooleanElementFrameCorner.Name = "BooleanElementFrameCorner"
            Elements.BooleanElementFrameCorner.Parent = Elements.BooleanElementFrame
            
            Elements.BooleanElementFrameText.Name = "BooleanElementFrameText"
            Elements.BooleanElementFrameText.Parent = Elements.BooleanElementFrame
            Elements.BooleanElementFrameText.AnchorPoint = Vector2.new(0.5, 0.5)
            Elements.BooleanElementFrameText.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Elements.BooleanElementFrameText.BackgroundTransparency = 1.000
            Elements.BooleanElementFrameText.Position = UDim2.new(0.5, 0, 0.5, 0)
            Elements.BooleanElementFrameText.Size = UDim2.new(1, 0, 1, 0)
            Elements.BooleanElementFrameText.FontFace = CFont
            Elements.BooleanElementFrameText.Text = Name
            Elements.BooleanElementFrameText.TextColor3 = Color3.fromRGB(132, 132, 132)
            Elements.BooleanElementFrameText.TextSize = 17.000
            Elements.BooleanElementFrameText.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
            Elements.BooleanElementFrameText.TextWrapped = true
            Elements.BooleanElementFrameText.TextXAlignment = Enum.TextXAlignment.Left
            
            Elements.BooleanElementFrameTextPadding.Name = "BooleanElementFrameTextPadding"
            Elements.BooleanElementFrameTextPadding.Parent = Elements.BooleanElementFrameText
            Elements.BooleanElementFrameTextPadding.PaddingLeft = UDim.new(0, 10)
            
            Elements.BooleanElementFrameActivator.Name = "BooleanElementFrameActivator"
            Elements.BooleanElementFrameActivator.Parent = Elements.BooleanElementFrame
            Elements.BooleanElementFrameActivator.AnchorPoint = Vector2.new(0.5, 0.5)
            Elements.BooleanElementFrameActivator.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Elements.BooleanElementFrameActivator.BackgroundTransparency = 1.000
            Elements.BooleanElementFrameActivator.Position = UDim2.new(0.5, 0, 0.5, 0)
            Elements.BooleanElementFrameActivator.Size = UDim2.new(1, 0, 1, 0)
            Elements.BooleanElementFrameActivator.Font = Enum.Font.SourceSans
            Elements.BooleanElementFrameActivator.Text = ""
            Elements.BooleanElementFrameActivator.TextColor3 = Color3.fromRGB(0, 0, 0)
            Elements.BooleanElementFrameActivator.TextSize = 14.000
            
            Elements.BooleanElementFrameDisplay.Name = "BooleanElementFrameDisplay"
            Elements.BooleanElementFrameDisplay.Parent = Elements.BooleanElementFrame
            Elements.BooleanElementFrameDisplay.BackgroundColor3 = Color3.fromRGB(36, 36, 36)
            Elements.BooleanElementFrameDisplay.Position = UDim2.new(0.935000002, 0, 0.166999996, 0)
            Elements.BooleanElementFrameDisplay.Size = UDim2.new(0, 20, 0, 20)
            
            Elements.BooleanElementFrameDisplayCorner.CornerRadius = UDim.new(0, 5)
            Elements.BooleanElementFrameDisplayCorner.Name = "BooleanElementFrameDisplayCorner"
            Elements.BooleanElementFrameDisplayCorner.Parent = Elements.BooleanElementFrameDisplay

            local function UpdateBooleanDisplay() 
                if Enabled then
                    game:GetService("TweenService"):Create(Elements.BooleanElementFrameDisplay, TweenInfo.new(.2), {
                        BackgroundColor3 = Color3.fromRGB(66, 66, 66)
                    }):Play()
                else
                    game:GetService("TweenService"):Create(Elements.BooleanElementFrameDisplay, TweenInfo.new(.2), {
                        BackgroundColor3 = Color3.fromRGB(33, 33, 33)
                    }):Play()
                end
            end

            Elements.BooleanElementFrameActivator.MouseButton1Click:Connect(function()
                if Elements.BooleanElement.Visible then
                    Enabled = not Enabled
                    local suc, req = pcall(BooleanOptions.OnChanged, Enabled)
                    if not suc then
                        error(("nekohub ui suite callback error: %s"):format(req))
                    else
                        UpdateBooleanDisplay()
                    end
                end
            end)

            SectionYOffset = SectionYOffset + 40
            UpdateSectionSize()
        end

        return SectionElements
    end

    pcall(function()
        local UserInputService = game:GetService("UserInputService")
        local TweenService = game:GetService("TweenService")
        local window = WindowElements.Window

        local tweenInfo = TweenInfo.new(0.5)
        local tweenParams = {
            Position = UDim2.new(0, 0, 0, 0)
        }

        window.MouseEnter:Connect(function()
            local mousePosition = UserInputService:GetMouseLocation() - window.AbsolutePosition
            local tween = TweenService:Create(window, tweenInfo, tweenParams)
            tween:Play()
        end)
    end)

    return ElementHandler
end


local window = interface:BeginMenu({
    Title = "Nekohub Test"
})

local section1 = window:CreateSection("Walkspeed 200")

section1:CreateBoolean({
    Name = "Enable",
    Enabled = { false },
    OnChanged = function(value)
        print(value)
    end
})