export function setWalkspeed(speed) {
    return `game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = ${speed}`;
}

 