local rx9 = {RX9_RENDERED={}}
local val = {Debug=false}
local util = {}
local services = {rs=game:GetService("RunService"),input=game:GetService("UserInputService")}
local connections = {}
local Theme = {themes={}}

function rx9:draw_rect(x, y, width, height, color) 
    local rect = Drawing.new("Square");
    rect.Visible = true;
    rect.Position = Vector2.new(x, y);
    rect.Size = Vector2.new(width, height);
    rect.Color = color;
    rect.Filled = true;

    table.insert(rx9.RX9_RENDERED, rect);
    return rect
end

function rx9:draw_square(x, y, width, height, color) 
    local square = Drawing.new("Square");
    square.Visible = true;
    square.Position = Vector2.new(x, y);
    square.Size = Vector2.new(width, height);
    square.Color = color;
    square.Thickness = 1
    square.Filled = false;

    table.insert(rx9.RX9_RENDERED, square);
    return square
end

function rx9:draw_string(text, x, y, color, properties) 
    if not type(properties) == "table" then
        return
    end

    local str = Drawing.new("Text")
    str.Visible = true
    str.Text = text
    str.Size = properties.Size or 16
    str.Center = properties.Center or false
    str.Outline = properties.Outline or false
    str.OutlineColor = properties.OutlineColor or Color3.fromRGB(0, 0, 0)
    str.Position = Vector2.new(x, y)
    str.Color = color
    str.Font = properties.Font or 3

    table.insert(rx9.RX9_RENDERED, str)
    return str
end

function rx9:draw_vector(from, to, thickness, color) 
    if not type(from) == "table" and not type(to) == "table" then 
        return
    end

    local vector = Drawing.new("Line")
    vector.Visible = true
    vector.Color = color
    vector.Thickness = thickness
    vector.From = Vector2.new(from[1], from[2])
    vector.To = Vector2.new(to[1], to[2])

    table.insert(rx9.RX9_RENDERED, vector)
    return vector
end

function Theme:new(theme_name, theme_colors) 
    if not theme_name and not theme_colors then
        return
    end

    local template = {
        name = theme_name,
        main = {
            Background = theme_colors.Background,
            Accent = theme_colors.Accent,
            Text = theme_colors.Text,
            TextEnabled = theme_colors.TextEnabled,
            TextDisabled = theme_colors.TextEnabled,
            Highlight = theme_colors.Highlight,
            TextAccent = theme_colors.TextAccent,
            CompBackground = theme_colors.CompBackground,
            CompAccent = theme_colors.CompAccent,
            TextAccentAllow = theme_colors.TextAccentAllow,
            Enabled = theme_colors.Enabled,
            Disabled = theme_colors.Disabled
        }
    }

    table.insert(Theme.themes, template)

    if val.Debug then 
        warn(("Created Theme: %s"):format(theme_name))
    end
end

function util:DumpToTable(target: table, items: table) 
    for _i, item in pairs(items) do 
        if not item then return end

        table.insert(target, item)
    end
end

function util:IsMouseOver(positions: table) 
    local x1, y1, x2, y2 = positions[1], positions[2], positions[3], positions[4]
    local mouseLoc = services.input:GetMouseLocation()
    return (mouseLoc.X >= x1 and mouseLoc.X <= (x1 + (x2 - x1))) and (mouseLoc.Y >= y1 and mouseLoc.Y <= (y1 + (y2 - y1)))
end

function Theme:GetTheme(theme_name: string) 
    for _index, _theme in pairs(Theme.themes) do 
        if _theme.name == theme_name then 
            return _theme.main
        else
            return nil
        end
    end
end

Theme:new("Default", {
    Background = Color3.fromRGB(18, 18, 18),
    Accent     = Color3.fromRGB(34, 34, 34),
    Highlight  = Color3.fromRGB(233, 123, 165),
    Text       = Color3.fromRGB(200, 200, 200),
    TextEnabled= Color3.fromRGB(255, 255, 255),
    TextDisabled= Color3.fromRGB(120, 120, 120),
    TextAccent = Color3.fromRGB(0, 0, 0),
    CompBackground = Color3.fromRGB(22, 22, 22),
    CompAccent = Color3.fromRGB(34, 34, 34),
    TextAccentAllow = true,
    Enabled    = Color3.fromRGB(72, 26, 255),
    Disabled   = Color3.fromRGB(60, 60, 60)
})

Theme:new("Light", {
    Background = Color3.fromRGB(233, 233, 233),
    Accent     = Color3.fromRGB(34, 34, 34),
    Highlight  = Color3.fromRGB(72, 26, 255),
    Text       = Color3.fromRGB(7, 7, 7),
    TextAccent = Color3.fromRGB(0, 0, 0),
    TextAccentAllow = false,
    Enabled    = Color3.fromRGB(72, 26, 255),
    Disabled   = Color3.fromRGB(60, 60, 60),
    CompBackground = Color3.fromRGB(227, 227, 227),
    CompAccent = Color3.fromRGB(131, 131, 131),
})

function val:ShutdownMenu(KeyName) 
    local key = Enum.KeyCode[KeyName]
    if not key then 
        return
    end

    game:GetService("UserInputService").InputBegan:Connect(function(x)
        if x.KeyCode == key then 
            for _x, obj in pairs(rx9.RX9_RENDERED) do 
                if obj then obj:Remove() end
            end
        end
    end)

    game:GetService("UserInputService").InputBegan:Connect(function(x)
        if x.KeyCode == key then 
            for _x, obj in pairs(connections) do 
                if obj then obj:Disconnect() end
            end
        end
    end)
end

function val:SetupMenu(menu_name, theme_name)
    if val.Debug then 
        print("loading valentino")
    end

    local theme = Theme:GetTheme(theme_name)
    local PanelManager = {panels={}}

    local menuX = 100
    local menuY = 100
    local menuOffset = 0
    local mPanelWidth = 170
    local mPanelBarY  = 30

    function PanelManager:AddPanel(panel_name) 
        local panel = rx9:draw_rect(menuX + menuOffset, menuY, mPanelWidth, mPanelBarY, theme.Background);
        local panel_title = rx9:draw_string(panel_name, (panel.Position.X) + 10, (panel.Position.Y) + 5, theme.Text, {Size=16,Font=3,Outline=theme.TextAccentAllow,OutlineColor=theme.TextAccent})

        local subCompOffset = 0
        local subWidth = mPanelWidth
        local subHeight = 25
        local SubComp = {}

        function SubComp:AddBool(bool_name, bool_state) 
            if not bool_name then 
                return bool_name
            end

            if not bool_state then 
                return bool_state
            end

            local bool_frame = rx9:draw_rect(menuX + menuOffset, (menuY + mPanelBarY) + subCompOffset, subWidth, subHeight, theme.Background)
            local bool_text  = rx9:draw_string(bool_name, (bool_frame.Position.X + 35), (bool_frame.Position.Y + 5), theme.Text, {Size=15,Font=3,Outline=false})

            local BoolClass = {}

            BoolClass.Enabled = bool_state

            if not bool_frame and bool_text then 
                return
            end

            function BoolClass:Connect(Function) 
                if not Function then 
                    return
                end

                if not BoolClass.Function then 
                    BoolClass.Function = Function
                end
            end 

            function BoolClass:Update(...) 
                local args = {...}
                local updated = nil

                for i, v in pairs(args) do 
                    if (type(v) == "boolean") then
                        updated = v
                        break
                    end
                end

                BoolClass.Enabled = updated
            end

            function BoolClass:Disconnect() 
                if not BoolClass.Function then 
                    return
                end

                BoolClass.Function = nil
            end

            return BoolClass
        end

        return SubComp
    end

    return PanelManager
end