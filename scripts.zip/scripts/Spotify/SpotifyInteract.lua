local http = game:GetService("HttpService")
local request = syn.request
local protect = syn.protect_gui or gethui()

local gui = {}
gui.main = {}
gui.drag_c = {}
gui.running = false

gui.protect = function(v) 
    if protect == syn.protect_gui then
        syn.protect_gui(v)
        v.Parent = game:GetService("CoreGui")
    elseif protect == gethui then
        v.Parent = gethui()
    else
        v.Parent = game:GetService("Players").LocalPlayer.PlayerGui
        error("Cannot protect ScreenGui!")
    end
end

gui.start_drag = function(frame) 
    local dragging
    local dragStartPos

    gui.drag_c.began = game:GetService("UserInputService").InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = true
            dragStartPos = game:GetService("UserInputService"):GetMouseLocation() - Vector2.new(frame.AbsolutePosition.X, frame.AbsolutePosition.Y)
        end
    end)

    gui.drag_c.endd = game:GetService("UserInputService").InputEnded:Connect(function(input, gameProcessedEvent)
        if dragging and input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = false
        end
    end)

    gui.drag_c.change = game:GetService("UserInputService").InputChanged:Connect(function(input)
        if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
            frame.Position = UDim2.new(0, game:GetService("UserInputService"):GetMouseLocation().X - dragStartPos.X, 0, game:GetService("UserInputService"):GetMouseLocation().Y - dragStartPos.Y)
        end
    end)
end

gui.setup = function()
    gui.running = true
    gui.main.SpotifyInteract = Instance.new("ScreenGui")
    gui.main.Window = Instance.new("Frame")
    gui.main.SongImage = Drawing.new("Image")
    gui.main.TextLabel = Instance.new("TextLabel")

    gui.main.SpotifyInteract.Name = "SpotifyInteract"
    gui.protect(gui.main.SpotifyInteract)
    gui.main.SpotifyInteract.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

    gui.main.Window.Name = "Window"
    gui.main.Window.Parent = gui.main.SpotifyInteract
    gui.main.Window.BackgroundColor3 = Color3.fromRGB(27, 27, 27)
    gui.main.Window.Position = UDim2.new(0.130841121, 0, 0.214805827, 0)
    gui.main.Window.Size = UDim2.new(0, 350, 0, 100)
    gui.main.Window.Draggable = true

    gui.main.SongImage.Visible = true
    gui.main.SongImage.Size = Vector2.new(100, 100)
    gui.main.SongImage.Position = Vector2.new(gui.main.Window.AbsolutePosition.X, gui.main.Window.AbsolutePosition.Y + 35)
    gui.main.SongImage.Rounding = 3

    gui.main.TextLabel.Parent = gui.main.Window
    gui.main.TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    gui.main.TextLabel.BackgroundTransparency = 1.000
    gui.main.TextLabel.Position = UDim2.new(0.314285725, 0, 0.389999986, 0)
    gui.main.TextLabel.Size = UDim2.new(0, 200, 0, 22)
    gui.main.TextLabel.Font = Enum.Font.SourceSans
    gui.main.TextLabel.Text = ""
    gui.main.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    gui.main.TextLabel.TextScaled = true
    gui.main.TextLabel.TextSize = 23.000
    gui.main.TextLabel.TextWrapped = true
    gui.main.TextLabel.TextXAlignment = Enum.TextXAlignment.Left

    gui.start_drag(gui.main.Window)

    local updateImage
    updateImage = game:GetService("RunService").Heartbeat:Connect(function()
        if gui.running then
            gui.main.SongImage.Position = Vector2.new(gui.main.Window.AbsolutePosition.X, gui.main.Window.AbsolutePosition.Y + 35)
        end
    end)

    local destroy
    destroy = game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessedEvent)
        if input.KeyCode.Name == "RightBracket" and gui.running then
            for i, v in pairs(gui.main.SpotifyInteract:GetChildren()) do 
                if v then
                    v:Destroy()
                end
            end

            for i, v in pairs(gui.drag_c) do 
                if v then
                    v:Disconnect()
                end
            end

            gui.main.SongImage:Remove()

            gui.running = false
            updateImage:Disconnect()
            destroy:Disconnect()
        end
    end)
end

gui.update_title = function(text) 
    repeat task.wait() until gui.running
    
    gui.main.TextLabel.Text = text
end

gui.update_image = function(image) 
    repeat task.wait() until gui.running
    
    gui.main.SongImage.Data = game:HttpGet(image)
end

gui.setup()

--> Main code

local function post_type(s_type, type_id) 
    local url = ("https://api.spotify.com/v1/%s/%s"):format(s_type, type_id)

    if not url then return end

    local response = syn.request({
        Url = url,
        Method = "GET",
        Headers = {
            ["Authorization"] = "Bearer BQByWBGJxidcYiTeF7KCKoUAGT6p3lpKR5lnTjvuonTOLQ0feysu-aF7pdtuqR9yrX__IpjSzSKf9wiKPUu3KJZcloGB38XfqNx8WxTJMSdoSF0hBB27",
            ["market"] = "GB"
        }
    })

    return response
end

local response = post_type("tracks", "33yAEqzKXexYM3WlOYtTfQ")
local rest = http:JSONDecode(response.Body)

--> Get atrist name and profile
-- for i, v in pairs(rest) do 
--     if tostring(i) == "name" then
--         gui.update_title(v)
--     end

--     if tostring(i) == "images" then 
--         for k, z in pairs(v) do
--             if k == 1 then
--                 for l, m in pairs(z) do 
--                     if tostring(l) == "url" then
--                         gui.update_image(m)
--                     end
--                 end
--             end
--         end
--     end
-- end

--> Get song name and profile

for i, v in pairs(rest) do 
    print(i, v)

    if i == "images" then
        print("ok")
    else
        print"nah"
    end

    if i == "name" then
        gui.update_title(v)
    end
end