local Lighting = game:GetService("Lighting")
local Players = game:GetService("Players")
local Util = {}
local String = {}
local Library = {}
local Icons = {
    Self = "rbxassetid://12865744195",
    Players = "rbxassetid://12865753897",
    Teleports = "rbxassetid://12865775481",
    Weapon = "rbxassetid://12865801691",
    Misc = "rbxassetid://12865814996",
    Aimbot = "rbxassetid://12865911541",
    Bypasses = "rbxassetid://12865918865",
    Money = "rbxassetid://12865933189",
    Visuals = "rbxassetid://12865944169",
    World = "rbxassetid://12865953515",
    Check = "rbxassetid://12866139060"
}
local Colors = {
    Enabled = Color3.fromRGB(85, 182, 224),
    Disabled = Color3.fromRGB(34, 41, 47),
    Accent = Color3.fromRGB(85, 182, 224)
}

function Util:OnMouseClick(Parent, Callback)
    if not Parent and not Callback then
        return
    end

    local Entered = false
    Parent.MouseEnter:Connect(function()
        Entered = true
    end)
    Parent.MouseLeave:Connect(function()
        Entered = false
    end)
    game:GetService("UserInputService").InputBegan:Connect(function(inputObject)
        if Entered and inputObject.UserInputType.Name == "MouseButton1" then pcall(Callback) end
    end)
end

local function ProtectGui(gui_instance) 
    if syn.protect_gui then
        syn.protect_gui(gui_instance);
    else
        messagebox("Security Error: GUI is vulnerable to any detections", "Continue?", 4);
    end
end

local FontManager = {Fonts={}}

function FontManager:GetFontFromID(Font_ID) 
    if Font_ID and Font.fromId(Font_ID) then
        return Font.fromId(Font_ID)
    end
end

function FontManager:SaveFont(Font_Name, Font_ID) 
    if Font_Name and Font_ID and Font.fromId(Font_ID) then 
        table.insert(FontManager.Fonts, {Name=Font_Name,ID=Font_ID});
    end
end

function FontManager:GetFontFromName(Font_Name) 
    if Font_Name then
        for _, font in next, FontManager.Fonts do 
            if font.Name == Font_Name then 
                return FontManager:GetFontFromID(font.ID);
            end
        end
    end
end

function Library:SetupPanel(MenuProperties)
    if not MenuProperties then return end

    local MenuName = syn.crypt.encrypt(MenuProperties.Name, "tencious_on_top");

    for i, v in next, game:GetService("CoreGui"):GetChildren() do 
        if v.Name == MenuName then
            v:Destroy()
        end
    end

    for i, v in next, Lighting:GetChildren() do 
        if v.Name == MenuName then
            v:Destroy()
        end
    end

    task.wait()

    warn("Loading Tencious Library v1.0");

    local MenuProperties = MenuProperties or {
        Name = MenuProperties.Name or nil,
        Open = MenuProperties.Open or true,
        Blur = MenuProperties.Blur or false,
        ToggleKey = MenuProperties.ToggleKey or "RightShift",
        ShutdownKey = MenuProperties.ShutdownKey or 'RightBracket'
    };

    local Flags = {
        FLAG_LIST = {}
    };

    function Flags:new(Name, Callback) 
        local new = {
            name = Name,
            callback = Callback
        }

        function new:set(callback) 
            if new.callback ~= callback then 
                new.callback = callback
            else
                new.callback()
            end
        end

        function new:fire() 
            if new.callback then
                new.callback()
            end
        end

        table.insert(Flags.FLAG_LIST, new)

        return new
    end

    function Flags:fire(name) 
        for i, v in next, Flags.FLAG_LIST do 
            if v.name == name then 
                v:fire()
                break
            end
        end
    end

    FontManager:SaveFont("Mulish", 12187372629);

    local Tenacious = Instance.new("ScreenGui");
    local Panel = Instance.new("Frame");
    local PanelLayout = Instance.new("UIListLayout");
    local PanelName = Instance.new("TextLabel");
    local PanelNamePadding = Instance.new("UIPadding");
    local Font = FontManager:GetFontFromName("Mulish");
    local PanelCorner = Instance.new("UICorner");
    local PanelPadding = Instance.new("UIPadding");
    
    local Blur = Instance.new("BlurEffect", Lighting); Blur.Enabled = MenuProperties.Blur; Blur.Name = MenuName; Blur.Size = 13;

    local function UpdateVisualState()
        if not Tenacious and not Blur then return end

        for _, obj in next, Tenacious:GetDescendants() do 
            if obj:IsA("Frame") or obj:IsA("TextLabel") or obj:IsA("TextButton") or obj:IsA("ImageLabel") or obj:IsA("ImageButton") or obj:IsA("GuiObject") then
                obj.Visible = MenuProperties.Open;
            end
        end

        local sizeTrue = 19
        local sizeFalse = 0

        if MenuProperties.Open then
            game:GetService("TweenService"):Create(
            Lighting[MenuName], TweenInfo.new(.2), {
                Size = sizeTrue
            }
        ):Play()
        else
            game:GetService("TweenService"):Create(
            Lighting[MenuName], TweenInfo.new(.2), {
                Size = sizeFalse
            }
        ):Play()
        end
        
    end

    Tenacious.Name = MenuName;
    ProtectGui(Tenacious);
    Tenacious.ZIndexBehavior = Enum.ZIndexBehavior.Sibling;
    Tenacious.Parent = game:GetService("CoreGui");

    Panel.Name = "Panel"
    Panel.Parent = Tenacious
    Panel.BackgroundColor3 = Color3.fromRGB(26, 26, 28)
    Panel.Position = UDim2.new(0.0301204827, 0, 0.0388349518, 0)
    Panel.Size = UDim2.new(0, 220, 0, 246)
    Panel.ClipsDescendants =  true

    PanelLayout.Name = "PanelLayout"
    PanelLayout.Parent = Panel
    PanelLayout.SortOrder = Enum.SortOrder.LayoutOrder

    PanelName.Name = "PanelName"
    PanelName.Parent = Panel
    PanelName.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    PanelName.BackgroundTransparency = 1.000
    PanelName.Size = UDim2.new(0, 220, 0, 30)
    PanelName.FontFace = Font
    PanelName.Text = MenuProperties.Name
    PanelName.TextColor3 = Color3.fromRGB(175, 175, 175)
    PanelName.TextSize = 22.000
    PanelName.TextXAlignment = Enum.TextXAlignment.Left

    PanelNamePadding.Name = "PanelNamePadding"
    PanelNamePadding.Parent = PanelName
    PanelNamePadding.PaddingLeft = UDim.new(0, 12)
    PanelNamePadding.PaddingTop = UDim.new(0, 2)

    PanelCorner.Name = "PanelCorner"
    PanelCorner.Parent = Panel

    PanelPadding.Name = "PanelPadding"
    PanelPadding.Parent = Panel
    PanelPadding.PaddingBottom = UDim.new(0, 5)
    
    local PanelSizeOffset = 0;
    
    local function UpdatePanelSize() 
        game:GetService("TweenService"):Create(
            Panel, TweenInfo.new(.1), {
                Size = UDim2.new(0, 220, 0, (31 + PanelSizeOffset))
            }
        ):Play()
    end

    local function UpdateNewPanelSize(New) 
        game:GetService("TweenService"):Create(
            Panel, TweenInfo.new(.1), {
                Size = UDim2.new(0, 220, 0, (New))
            }
        ):Play()
    end

    local Element = {}

    function Element:AddBoolean(BooleanName: string, BooleanState: boolean) 
        if not BooleanName then 
            return
        end

        local BooleanClass = {
            Name = BooleanName,
            State = BooleanState,
            Function = nil
        }

        local Hovered = false
        local Enabled = BooleanState
        local BooleanElement = Instance.new("Frame")
        local BooleanElementLayout = Instance.new("UIListLayout")
        local BooleanElementPadding = Instance.new("UIPadding")
        local BooleanElementFill = Instance.new("Frame")
        local BooleanElementFillCorner = Instance.new("UICorner")
        local BooleanElementName = Instance.new("TextLabel")

        local function UpdateBooleanVisual()
            if Enabled then 
                game:GetService("TweenService"):Create(
                    BooleanElementFill,
                    TweenInfo.new(.1),{
                        BackgroundColor3 = Color3.fromRGB(129, 129, 130)
                    }
                ):Play()
            else
                game:GetService("TweenService"):Create(
                    BooleanElementFill,
                    TweenInfo.new(.1),{
                        BackgroundColor3 = Color3.fromRGB(42, 42, 45)
                    }
                ):Play()
            end
        end

        local function UpdateBooleanState() 
            Enabled = not Enabled

            UpdateBooleanVisual()
        end

        local function UpdateHoveredVisual() 
            if Hovered and not Enabled then
                game:GetService("TweenService"):Create(
                    BooleanElementFill,
                    TweenInfo.new(.1),{
                        BackgroundColor3 = Color3.fromRGB(49, 49, 49)
                    }
                ):Play()
            elseif not Hovered and not Enabled then
                game:GetService("TweenService"):Create(
                    BooleanElementFill,
                    TweenInfo.new(.1),{
                        BackgroundColor3 = Color3.fromRGB(42, 42, 42)
                    }
                ):Play()
            end
        end

        BooleanElement.Name = "BooleanElement"
        BooleanElement.Parent = Panel
        BooleanElement.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        BooleanElement.BackgroundTransparency = 1.000
        BooleanElement.Position = UDim2.new(0, 0, 0.508474588, 0)
        BooleanElement.Size = UDim2.new(0, 220, 0, 30)
        
        BooleanElementLayout.Name = "BooleanElementLayout"
        BooleanElementLayout.Parent = BooleanElement
        BooleanElementLayout.FillDirection = Enum.FillDirection.Horizontal
        BooleanElementLayout.SortOrder = Enum.SortOrder.LayoutOrder
        BooleanElementLayout.VerticalAlignment = Enum.VerticalAlignment.Center
        BooleanElementLayout.Padding = UDim.new(0, 8)
        
        BooleanElementPadding.Name = "BooleanElementPadding"
        BooleanElementPadding.Parent = BooleanElement
        BooleanElementPadding.PaddingLeft = UDim.new(0, 10)
        
        BooleanElementFill.Name = "BooleanElementFill"
        BooleanElementFill.Parent = BooleanElement
        BooleanElementFill.BackgroundColor3 = Color3.fromRGB(42, 42, 45)
        BooleanElementFill.Size = UDim2.new(0, 20, 0, 20)
        
        BooleanElementFillCorner.CornerRadius = UDim.new(0, 5)
        BooleanElementFillCorner.Name = "BooleanElementFillCorner"
        BooleanElementFillCorner.Parent = BooleanElementFill
        
        BooleanElementName.Name = "BooleanElementName"
        BooleanElementName.Parent = BooleanElement
        BooleanElementName.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        BooleanElementName.BackgroundTransparency = 1.000
        BooleanElementName.Position = UDim2.new(0.095238097, 0, 0, 0)
        BooleanElementName.Size = UDim2.new(0, 190, 0, 30)
        BooleanElementName.FontFace = Font
        BooleanElementName.Text = BooleanName
        BooleanElementName.TextColor3 = Color3.fromRGB(150, 150, 150)
        BooleanElementName.TextSize = 18.000
        BooleanElementName.TextXAlignment = Enum.TextXAlignment.Left

        UpdateBooleanVisual()

        BooleanElementFill.MouseEnter:Connect(function() 
            Hovered = true
            UpdateHoveredVisual()
        end)

        BooleanElementFill.MouseLeave:Connect(function() 
            Hovered = false
            UpdateHoveredVisual()
        end)

        function BooleanClass:Connect(Function)
            local Attr = {}
            if BooleanClass.Function == nil and type(Function) == "function" then 
                BooleanClass.Function = Function
            end

            function Attr:SetEnabled(State) 
                Enabled = State

                UpdateBooleanVisual()
                BooleanClass:Fire()
            end

            function Attr:IsEnabled() 
                return Enabled
            end

            return Attr
        end

        function BooleanClass:Fire() 
            if not BooleanClass.Function then
                return
            end

            pcall(BooleanClass.Function, Enabled)
        end

        function BooleanClass:SetEnabled(State) 
            Enabled = State

            UpdateBooleanVisual()
            BooleanClass:Fire()
        end

        function BooleanClass:IsEnabled() 
            return Enabled
        end

        local function OnClick()
            UpdateBooleanState()
            BooleanClass:Fire()
        end

        Util:OnMouseClick(BooleanElementFill, OnClick)

        PanelSizeOffset = PanelSizeOffset + 30
        UpdatePanelSize();

        return BooleanClass
    end

    function Element:AddAction(ActionName: string, ActionFlag: string) 
        if not ActionName and not ActionFlag then 
            return
        end

        local ActionClass = {
            Name = ActionName,
            Flag = ActionFlag,
            Callback = nil
        }

        local Hovered = false
        local Click = false
        local ActionElement = Instance.new("Frame")
        local ActionElementLayout = Instance.new("UIListLayout")
        local ActionElementPadding = Instance.new("UIPadding")
        local ActionElementButton = Instance.new("Frame")
        local ActionElementButtonCorner = Instance.new("UICorner")
        local ActionElementName = Instance.new("TextLabel")

        local function UpdateHoveredVisual() 
            if Hovered then
                game:GetService("TweenService"):Create(
                    ActionElementButton,
                    TweenInfo.new(.1),{
                        BackgroundColor3 = Color3.fromRGB(49, 49, 49)
                    }
                ):Play()
            else
                game:GetService("TweenService"):Create(
                    ActionElementButton,
                    TweenInfo.new(.1),{
                        BackgroundColor3 = Color3.fromRGB(42, 42, 42)
                    }
                ):Play()
            end
        end

        local function UpdateOnClick()
            Hovered = false
            UpdateVisualState()
            Click = true

            if Click then
                game:GetService("TweenService"):Create(
                ActionElementButton,
                    TweenInfo.new(.1),{
                        BackgroundColor3 = Color3.fromRGB(49, 49, 49)
                    }
                ):Play()
                game:GetService("TweenService"):Create(
                    ActionElementButton,
                        TweenInfo.new(.3),{
                            BackgroundColor3 = Color3.fromRGB(42, 42, 42)
                        }
                    ):Play()
                game:GetService("TweenService"):Create(
                    ActionElementButton,
                        TweenInfo.new(.1),{
                            BackgroundColor3 = Color3.fromRGB(49, 49, 49)
                        }
                    ):Play()
            end
        end

        ActionElement.Name = "ActionElement"
        ActionElement.Parent = Panel
        ActionElement.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        ActionElement.BackgroundTransparency = 1.000
        ActionElement.Position = UDim2.new(0, 0, 0.508474588, 0)
        ActionElement.Size = UDim2.new(0, 220, 0, 35)

        ActionElementLayout.Name = "ActionElementLayout"
        ActionElementLayout.Parent = ActionElement
        ActionElementLayout.FillDirection = Enum.FillDirection.Horizontal
        ActionElementLayout.SortOrder = Enum.SortOrder.LayoutOrder
        ActionElementLayout.VerticalAlignment = Enum.VerticalAlignment.Center
        ActionElementLayout.Padding = UDim.new(0, 8)

        ActionElementPadding.Name = "ActionElementPadding"
        ActionElementPadding.Parent = ActionElement
        ActionElementPadding.PaddingLeft = UDim.new(0, 10)

        ActionElementButton.Name = "ActionElementButton"
        ActionElementButton.Parent = ActionElement
        ActionElementButton.BackgroundColor3 = Color3.fromRGB(42, 42, 45)
        ActionElementButton.Position = UDim2.new(0, 0, 0.142857149, 0)
        ActionElementButton.Size = UDim2.new(0, 198, 0, 25)

        ActionElementButtonCorner.CornerRadius = UDim.new(0, 5)
        ActionElementButtonCorner.Name = "ActionElementButtonCorner"
        ActionElementButtonCorner.Parent = ActionElementButton

        ActionElementName.Name = "ActionElementName"
        ActionElementName.Parent = ActionElementButton
        ActionElementName.AnchorPoint = Vector2.new(0.5, 0.5)
        ActionElementName.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        ActionElementName.BackgroundTransparency = 1.000
        ActionElementName.Position = UDim2.new(0.505102038, 0, 0.5, 0)
        ActionElementName.Size = UDim2.new(1.01020408, 0, 1, 0)
        ActionElementName.FontFace = Font
        ActionElementName.Text = ActionClass.Name
        ActionElementName.TextColor3 = Color3.fromRGB(150, 150, 150)
        ActionElementName.TextSize = 18.000

        ActionElementButton.MouseEnter:Connect(function() 
            Hovered = true;
            UpdateHoveredVisual()
        end)

        ActionElementButton.MouseLeave:Connect(function() 
            Hovered = false;
            UpdateHoveredVisual()
        end)

        function ActionClass:Connect(callback)
            if not ActionClass.Callback then
                ActionClass.Callback = callback
            end
        end

        local function OnClick() 
            if ActionClass.Callback then
                UpdateOnClick() 
                pcall(ActionClass.Callback)
                Click = false;
            end
        end

        Util:OnMouseClick(ActionElementButton, OnClick)

        PanelSizeOffset = PanelSizeOffset + 37
        UpdatePanelSize();

        Flags:new(ActionFlag, ActionClass.Callback)

        return ActionClass
    end

    function Element:AddInput(PlaceholderText, MaxLength) 
        if not PlaceholderText and not MaxLength then
            return
        end

        local InputElement = Instance.new("Frame")
        local InputElementLayout = Instance.new("UIListLayout")
        local InputElementPadding = Instance.new("UIPadding")
        local InputElementInput = Instance.new("Frame")
        local InputElementInputCorner = Instance.new("UICorner")
        local InputElementInputTextBox = Instance.new("TextBox")
        local InputElementTextBoxPadding = Instance.new("UIPadding")
        local InputElementApply = Instance.new("Frame")
        local InputElementApplyCorner = Instance.new("UICorner")
        local InputElementApplyImage = Instance.new("ImageLabel")

        InputElement.Name = "InputElement"
        InputElement.Parent = Panel
        InputElement.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        InputElement.BackgroundTransparency = 1.000
        InputElement.Position = UDim2.new(0, 0, 0.508474588, 0)
        InputElement.Size = UDim2.new(0, 220, 0, 36)

        InputElementLayout.Name = "InputElementLayout"
        InputElementLayout.Parent = InputElement
        InputElementLayout.FillDirection = Enum.FillDirection.Horizontal
        InputElementLayout.SortOrder = Enum.SortOrder.LayoutOrder
        InputElementLayout.VerticalAlignment = Enum.VerticalAlignment.Center
        InputElementLayout.Padding = UDim.new(0, 8)

        InputElementPadding.Name = "InputElementPadding"
        InputElementPadding.Parent = InputElement
        InputElementPadding.PaddingLeft = UDim.new(0, 10)

        InputElementInput.Name = "InputElementInput"
        InputElementInput.Parent = InputElement
        InputElementInput.BackgroundColor3 = Color3.fromRGB(42, 42, 45)
        InputElementInput.Position = UDim2.new(0, 0, 0.142857149, 0)
        InputElementInput.Size = UDim2.new(0, 165, 0, 25)

        InputElementInputCorner.CornerRadius = UDim.new(0, 5)
        InputElementInputCorner.Name = "InputElementInputCorner"
        InputElementInputCorner.Parent = InputElementInput

        InputElementInputTextBox.Name = "InputElementInputTextBox"
        InputElementInputTextBox.Parent = InputElementInput
        InputElementInputTextBox.AnchorPoint = Vector2.new(0.5, 0.5)
        InputElementInputTextBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        InputElementInputTextBox.BackgroundTransparency = 1.000
        InputElementInputTextBox.BorderColor3 = Color3.fromRGB(27, 42, 53)
        InputElementInputTextBox.Position = UDim2.new(0.5, 0, 0.5, 0)
        InputElementInputTextBox.Size = UDim2.new(1, 0, 1, 0)
        InputElementInputTextBox.FontFace = Font
        InputElementInputTextBox.PlaceholderColor3 = Color3.fromRGB(115, 115, 115)
        InputElementInputTextBox.PlaceholderText = PlaceholderText
        InputElementInputTextBox.Text = ""
        InputElementInputTextBox.TextColor3 = Color3.fromRGB(150, 150, 150)
        InputElementInputTextBox.TextSize = 18.000
        InputElementInputTextBox.TextXAlignment = Enum.TextXAlignment.Left
        InputElementInputTextBox.TextTruncate = Enum.TextTruncate.AtEnd
        InputElementInputTextBox.ClearTextOnFocus = false

        InputElementTextBoxPadding.Name = "InputElementTextBoxPadding"
        InputElementTextBoxPadding.Parent = InputElementInputTextBox
        InputElementTextBoxPadding.PaddingLeft = UDim.new(0, 10)

        InputElementApply.Name = "InputElementApply"
        InputElementApply.Parent = InputElement
        InputElementApply.BackgroundColor3 = Color3.fromRGB(42, 42, 45)
        InputElementApply.Position = UDim2.new(0.800000012, 0, 0.142857149, 0)
        InputElementApply.Size = UDim2.new(0, 25, 0, 25)

        InputElementApplyCorner.CornerRadius = UDim.new(0, 5)
        InputElementApplyCorner.Name = "InputElementApplyCorner"
        InputElementApplyCorner.Parent = InputElementApply

        InputElementApplyImage.Name = "InputElementApplyImage"
        InputElementApplyImage.Parent = InputElementApply
        InputElementApplyImage.AnchorPoint = Vector2.new(0.5, 0.5)
        InputElementApplyImage.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
        InputElementApplyImage.BackgroundTransparency = 1.000
        InputElementApplyImage.Position = UDim2.new(0.5, 0, 0.550000012, 0)
        InputElementApplyImage.Size = UDim2.new(0, 16, 0, 16)
        InputElementApplyImage.Image = "rbxassetid://12873582450"
        InputElementApplyImage.ImageColor3 = Color3.fromRGB(75, 75, 75)

        InputElementInputTextBox:GetPropertyChangedSignal("Text"):Connect(function() 
            if #InputElementInputTextBox.Text >= MaxLength then 
                InputElementInputTextBox.TextEditable = false;

                local c
                c = InputElementInputTextBox.FocusLost:Connect(function()
                    if #InputElementInputTextBox.Text < MaxLength then
                        InputElementInputTextBox.TextEditable = true;

                        c:Disconnect();
                    end
                end)
            else
                InputElementInputTextBox.TextEditable = true;
            end
        end)

        PanelSizeOffset = PanelSizeOffset + 38
        UpdatePanelSize()
    end

    game:GetService("UserInputService").InputBegan:Connect(function(i)
        if Tenacious then 
            syn.unprotect_gui(Tenacious)
            if i.KeyCode == Enum.KeyCode[MenuProperties.ShutdownKey] then
                Tenacious:Destroy();
                Blur:Destroy();   -- Destroy blur
            end
        end
    end)

    game:GetService("UserInputService").InputBegan:Connect(function(i)
        if Tenacious then
            if i.KeyCode == Enum.KeyCode[MenuProperties.ToggleKey] then
                MenuProperties.Open = not MenuProperties.Open;
                UpdateVisualState();
            end
        end
    end)

    UpdateVisualState();

    return Element
end

local Tencious = Library:SetupPanel({
    Name = "Tenacious",
    Open = true,
    Blur = true,
    ShutdownKey = 'RightBracket',
    ToggleKey = 'RightShift'
})

local Godmode = Tencious:AddBoolean("Godmode", true):Connect(function(x) print(x) end)
local InfStamina = Tencious:AddBoolean("Inf stamina", false):Connect(function(x) print(x) end)
local WalkSpeed = Tencious:AddAction("WalkSpeed", "WalkSpeed_1"):Connect(function() print("hello") end)
local WalkSpeedAmount = Tencious:AddInput("walkspeed amount", 10)
