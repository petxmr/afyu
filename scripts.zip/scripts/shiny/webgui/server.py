import asyncio
import websockets

async def handle_connection(websocket, path):
    await websocket.send("Welcome to the WebSocket server!")
    while True:
        message = await websocket.recv()
        msg = str(message)
        # response = f"You said: {message}"
        if msg.startswith("log "):
            l_msg = msg.split(" ")
            await websocket.send(f"print('{l_msg}')")
        await websocket.send("yo")

async def main():
    async with websockets.serve(handle_connection, "localhost", 8765):
        print("Websocket server started")

        await asyncio.Future()


asyncio.run(main())