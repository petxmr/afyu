const { setWalkspeed } = require("../public/cheats/Walkspeed");

const socket = new WebSocket('ws://192.168.1.140:3000');

const messageForm = document.getElementById('message-form');
const messageInput = document.querySelector('#message-input');
const messageList = document.querySelector('#messages');
const chatMessageInput = document.querySelector('#chat-message-input');

messageForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const message = messageInput.value;
  if (message) {
    socket.send(message);
    messageInput.value = '';
  }
});

messageForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const message = chatMessageInput.value;
  if (message) {
    socket.send(`game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(("[floware/msg]: %s"):format("${message}"), "All")`);
    chatMessageInput.value = '';
  } 
});

// Walkspeed cheat;
const slider = document.querySelector('.slider-input');
const value = document.querySelector('.input');
const button = document.querySelector('.slider-button');
const output = document.querySelector('.slider-output');

slider.addEventListener('input', () => {
  value.value = slider.value || output.textContent;
});

button.addEventListener('click', () => {
  const walkSpeed = parseInt(slider.value);
  output.textContent = walkSpeed;
  socket.send(setWalkspeed(walkSpeed));
});

socket.onmessage = (event) => {
  const fileReader = new FileReader();
  fileReader.onload = () => {
    const message = fileReader.result;
    const li = document.createElement('li');
    li.textContent = message;
    messageList.insertBefore(li, messageList.firstChild);
  };
  fileReader.readAsText(event.data);
};
