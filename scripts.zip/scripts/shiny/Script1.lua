local RemoteHandler = {}

function RemoteHandler:Fire(Type, Service, Path, Args) 
    if not type(Type) == "string" then
        return
    end

    if not Type then 
        return
    end

    if Type == "Server" then
        game:GetService(Service)[Path]:FireServer(table.unpack(Args));
    end

    if Type == "Client" then
        game:GetService(Service)[Path]:FireRemote(table.unpack(Args));
    end
end


RemoteHandler:Fire("Server", "ReplicatedStorage", "Remote", {"Roll2"});

