local Players = game:GetService("Players")
local TS      = game:GetService("TweenService")
local Self    = Players.LocalPlayer
local HRP     = Self.Character.HumanoidRootPart
local Islands = {}

local function GetIslandPosition(IslandName) 
    local IslandFolder = game:GetService("Workspace").Portals

    for _index, portal in pairs(IslandFolder:GetChildren()) do 
        if portal:IsA("Model") and not portal.Name:find("To") then
            table.insert(Islands, portal.Name)
            if portal.Name == IslandName or portal.Name:find(IslandName) then
                return CFrame.new(portal.Base.Position.X - 50, portal.Base.Position.Y, portal.Base.Position.Z);
            end
        end
    end
end

local function TweenToIsland(IslandPosition) 
    if not type(IslandPosition) == "vector" then 
        return
    end

    local Position, ScaleFactor = CFrame.new(IslandPosition.X, IslandPosition.Y, IslandPosition.Z), Vector3.new(IslandPosition.X, IslandPosition.Y, IslandPosition.Z)

    TS:Create(HRP, 
        TweenInfo.new(ScaleFactor.Magnitude / 1000, Enum.EasingStyle.Quart, Enum.EasingDirection.In),
        {CFrame = Position}
    ):Play()
end

local IslandPos = GetIslandPosition("Lobby")
local TweenTo   = TweenToIsland(IslandPos)

table.foreach(Islands, print)