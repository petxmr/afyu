local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local RX9 = {}
local util = {}
local interface = {}
local interpolation = {}
local Timer = {}

RX9.__index = RX9
RX9.RX9_RENDERED = {}

function util:mouse_over(table_positions)
    local x1, y1, x2, y2 = table_positions[1], table_positions[2], table_positions[3], table_positions[4]
    local mouseLoc = game:GetService('UserInputService'):GetMouseLocation()
    return (mouseLoc.X >= x1 and mouseLoc.X <= (x1 + (x2 - x1))) and (mouseLoc.Y >= y1 and mouseLoc.Y <= (y1 + (y2 - y1)))
end;

function RX9:draw_rect(int_x, int_y, int_width, int_height, color3_color) 
    local RX9_RECT = Drawing.new("Square")
    RX9_RECT.Visible = true
    RX9_RECT.Filled = true
    RX9_RECT.Color = color3_color
    RX9_RECT.Size = Vector2.new(int_width, int_height)
    RX9_RECT.Position = Vector2.new(int_x, int_y)

    table.insert(RX9.RX9_RENDERED, RX9_RECT)
    return RX9_RECT
end

function RX9:draw_square(int_x, int_y, int_width, int_height, color3_color) 
    local RX9_SQUARE = Drawing.new("Square")
    RX9_SQUARE.Visible = true
    RX9_SQUARE.Filled = false
    RX9_SQUARE.Thickness = 1
    RX9_SQUARE.Color = color3_color
    RX9_SQUARE.Size = Vector2.new(int_width, int_height)
    RX9_SQUARE.Position = Vector2.new(int_x, int_y)

    table.insert(RX9.RX9_RENDERED, RX9_SQUARE)
    return RX9_SQUARE
end

function RX9:draw_string(string_content, int_x, int_y, color3_color) 
    local RX9_STRING = Drawing.new("Text")
    RX9_STRING.Visible = true
    RX9_STRING.Center = false
    RX9_STRING.Outline = false
    RX9_STRING.Size = 19
    RX9_STRING.Font = 0
    RX9_STRING.Text = string_content
    RX9_STRING.Position = Vector2.new(int_x, int_y)
    RX9_STRING.Color = color3_color

    table.insert(RX9.RX9_RENDERED, RX9_STRING)
    return RX9_STRING
end

function RX9:draw_string_outline(string_content, int_x, int_y, color3_color, color3_outline_color) 
    local RX9_STRING_OUTLINE = Drawing.new("Text")
    RX9_STRING_OUTLINE.Visible = true
    RX9_STRING_OUTLINE.Center = false
    RX9_STRING_OUTLINE.Outline = true
    RX9_STRING_OUTLINE.Size = 19
    RX9_STRING_OUTLINE.Font = 0
    RX9_STRING_OUTLINE.Text = string_content
    RX9_STRING_OUTLINE.OutlineColor = color3_outline_color
    RX9_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    RX9_STRING_OUTLINE.Color = color3_color

    table.insert(RX9.RX9_RENDERED, RX9_STRING_OUTLINE)
    return RX9_STRING_OUTLINE
end

function RX9:draw_string_custom(string_content, int_x, int_y, int_font, int_size, bool_center, bool_visible, bool_outline, color3_color, color3_outline_color) 
    local RX9_STRING_OUTLINE = Drawing.new("Text")
    RX9_STRING_OUTLINE.Visible = bool_visible
    RX9_STRING_OUTLINE.Center = bool_center
    RX9_STRING_OUTLINE.Size = int_size
    RX9_STRING_OUTLINE.Font = int_font
    RX9_STRING_OUTLINE.Text = string_content
    RX9_STRING_OUTLINE.Outline = bool_outline
    RX9_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    RX9_STRING_OUTLINE.Color = color3_color

    table.insert(RX9.RX9_RENDERED, RX9_STRING_OUTLINE)
    return RX9_STRING_OUTLINE
end

function RX9:draw_string_custom_font(string_content, int_x, int_y, int_font, color3_color, color3_outline_color) 
    local RX9_STRING_OUTLINE = Drawing.new("Text")
    RX9_STRING_OUTLINE.Visible = true
    RX9_STRING_OUTLINE.Center = false
    RX9_STRING_OUTLINE.Size = 19
    RX9_STRING_OUTLINE.Font = int_font
    RX9_STRING_OUTLINE.Text = string_content
    RX9_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    RX9_STRING_OUTLINE.Color = color3_color

    table.insert(RX9.RX9_RENDERED, RX9_STRING_OUTLINE)
    return RX9_STRING_OUTLINE
end

function RX9:draw_string_custom_font_outline(string_content, int_x, int_y, int_font, color3_color, color3_outline_color) 
    local RX9_STRING_OUTLINE = Drawing.new("Text")
    RX9_STRING_OUTLINE.Visible = true
    RX9_STRING_OUTLINE.Center = false
    RX9_STRING_OUTLINE.Outline = true
    RX9_STRING_OUTLINE.Size = 19
    RX9_STRING_OUTLINE.Font = int_font
    RX9_STRING_OUTLINE.Text = string_content
    RX9_STRING_OUTLINE.OutlineColor = color3_outline_color
    RX9_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    RX9_STRING_OUTLINE.Color = color3_color

    table.insert(RX9.RX9_RENDERED, RX9_STRING_OUTLINE)
    return RX9_STRING_OUTLINE
end

function RX9:draw_string_centered(string_content, int_x, int_y, color3_color) 
    local RX9_STRING_CENTERED = Drawing.new("Text")
    RX9_STRING_CENTERED.Visible = true
    RX9_STRING_CENTERED.Center = true
    RX9_STRING_CENTERED.Outline = false
    RX9_STRING_CENTERED.Size = 19
    RX9_STRING_CENTERED.Font = 0
    RX9_STRING_CENTERED.Text = string_content
    RX9_STRING_CENTERED.Position = Vector2.new(int_x, int_y)
    RX9_STRING_CENTERED.Color = color3_color

    table.insert(RX9.RX9_RENDERED, RX9_STRING_CENTERED)
    return RX9_STRING_CENTERED
end

function RX9:draw_vector(vector2_from, vector2_to, number_thickness, color3_color) 
    local RX9_VECTOR = Drawing.new("Line")
    RX9_VECTOR.Visible = true
    RX9_VECTOR.Color = color3_color
    RX9_VECTOR.From = vector2_from
    RX9_VECTOR.To = vector2_to
    RX9_VECTOR.Transparency = 1
    
    table.insert(RX9.RX9_RENDERED, RX9_VECTOR)
    return RX9_VECTOR
end

function interpolation:new(animation_type, start, goal, alpha) 
    local t = math.clamp(alpha, 0, 1)

    if animation_type == "ease-in" then
        t = math.sin(t * math.pi / 2)
    elseif animation_type == "bounce" then
        local period = 1.2
        t = 1 - math.abs(math.cos(t * math.pi / period)) * (1 - t)
        t = t * t * (3 - 2 * t)
    elseif animation_type == "elastic-in" then
        local period = 0.3
        local amplitude = 1.5
        t = 1 - math.cos(t * math.pi * 2.5) * math.exp(-t * period * 3)
        t = t * (1 + amplitude * (1 - math.cos(t * math.pi * 2.5)))
    end

    return start + (goal - start) * t
end

function interpolation:linear(start, goal, alpha) 
    local t = math.clamp(alpha, 0, 1)

    return start + (goal - start) * t
end

function Timer:new() 
    local timer = {}
    setmetatable(timer, self)
    self.__index = self
    timer.lastMS = os.time() * 1000
    return timer
end

function Timer:reset() 
    self.lastMS = os.time() * 1000
end

function Timer:hasTimeElapsed(ms, reset) 
    if os.time() * 1000 - self.lastMS > ms then
        if reset then
            self:reset()
        end
        return true
    end

    return false
end

function Timer:getTime()
    return os.time() * 1000 - self.lastMS
end
  
function Timer:setTime(time)
    self.lastMS = os.time() * 1000 - time
end

function interface:BeginMenu(MenuOptions) 
    local connections = {}
    local comp = {}
    local dragX = 0
    local dragY = 0
    local dragging = false

    local function add_comp(options) 
        table.insert(comp, { X = options.X, Y = options.Y, Object = options.Object });
    end

    local function draw_string(text, x, y, size, font, color) 
        return RX9:draw_string_custom(text,
            x, y, font, size, false, true, true, color, Color3.new(0, 0, 0))
    end

    local background = Color3.fromRGB(20, 20, 20)
    local text_color = Color3.fromRGB(200, 200, 200)
    local accent = Color3.fromRGB(91, 40, 231)
    local comp_background = Color3.fromRGB(45, 45, 45)
    local button_background = Color3.fromRGB(25, 25, 25)

    local startX = 100
    local startY = 100

    local frame = RX9:draw_rect(startX, startY, 500, 650, background); 
    local text  = draw_string(MenuOptions.Name, startX + 10, startY + 6, 16, 3, text_color)
    local border = RX9:draw_square(startX+1, startY+1, 498, 648, accent);

    local page_container = RX9:draw_square(startX+6, startY+25, frame.Size.X - 12, frame.Size.Y - 30, comp_background);
    local page_button_container = RX9:draw_square(startX+6, startY+25, frame.Size.X - 12, 22, comp_background);

    add_comp{ X = 0, Y = 0, Object = frame };
    add_comp{ X = 10, Y = 6, Object = text };
    add_comp{ X = 1, Y = 1, Object = border };
    add_comp{ X = 6, Y = 25, Object = page_container };
    add_comp{ X = 6, Y = 25, Object = page_button_container };

    local function create_button(text, x2, y2, width, height) 
        local events = { enabled = true, Function = nil }
        local x, y = startX + x2, startY + y2;

        local buttonFrame = RX9:draw_rect(x, y, width, height, button_background)
        local buttonText  = draw_string(text, x + (100 / 2), y + 3, 16, 3, text_color); buttonText.Center = true;

        buttonText.Position = Vector2.new(x + buttonFrame.Size.X / 2, y + (buttonFrame.Size.Y / 2 - 8));

        if ((buttonText.TextBounds.X + 15) > width ) then
            buttonFrame.Size = Vector2.new(buttonText.TextBounds.X + 15, height);
            buttonText.Position = Vector2.new(x + buttonFrame.Size.X / 2, y + (buttonFrame.Size.Y / 2 - 8));
        end

        add_comp{ X = x2, Y = y2, Object = buttonFrame }
        add_comp{ X = x2 + buttonFrame.Size.X / 2, Y = y2 + (buttonFrame.Size.Y / 2 - 8), Object = buttonText }

        function events:Connect(Function) 
            if not events.Function then
                events.Function = Function
            end
        end

        function events:Set(bool) 
            events.enabled = bool
        end

        function events:IsActive() 
            return events.enabled
        end

        function events:GetComp() 
            return { buttonFrame, buttonText }
        end

        local function UpdateButtonOnHover(bool) 
            if bool then
                buttonFrame.Color = Color3.fromRGB(30, 30, 30)
            else
                buttonFrame.Color = button_background
            end
        end

        connections.button_begin = UserInputService.InputBegan:Connect(function(input, gameProcessedEvent)
            if input.UserInputType.Name == "MouseButton1" and events.enabled then
                if util:mouse_over({
                    buttonFrame.Position.X, buttonFrame.Position.Y,
                    buttonFrame.Position.X + buttonFrame.Size.X,
                    buttonFrame.Position.Y + buttonFrame.Size.Y
                }) then
                    local suc, req = pcall(events.Function)
                    if not suc then
                        error(req)
                    end
                end
            end
        end)

        connections.button_hover = UserInputService.InputChanged:Connect(function(input, gameProcessedEvent)
            if input.UserInputType.Name == "MouseMovement" and events.enabled and buttonFrame then
                if util:mouse_over({
                    buttonFrame.Position.X, buttonFrame.Position.Y,
                    buttonFrame.Position.X + buttonFrame.Size.X,
                    buttonFrame.Position.Y + buttonFrame.Size.Y
                }) then
                    UpdateButtonOnHover(true);
                else
                    UpdateButtonOnHover(false);
                end
            end
        end)

        return events
    end

    local page_handler = { }
    local pages = { }

    local page_button_x = 7
    local page_button_y = 26
    local page_button_offset = 0

    function page_handler:BeginPage(PageName) 
        local page_class = {
            Name = PageName,
            Showing = false,
            Button = nil,
            Actions = { }
        }

        local pButton = create_button(PageName, page_button_x+page_button_offset, page_button_y, 70, 20);

        page_class.Button = pButton

        local action_handler = {}
        local action_offset = {["left"]=0, ["right"]=0}
        local action_y = 65
        local action_x = startX
        local action_layouts = {["left"]=34, ["right"]=260}

        function action_handler:CreateSection(SectionName, SectionLayout, SectionActions) 
            local layout = string.lower(SectionLayout)
            local section_class = {
                Name = SectionName,
                CompEnabled = true,
                Comp = {},
            }

            local DROPDOWN_ACTIVE = false

            local function section_link(object) 
                table.insert(section_class.Comp, object)
            end

            local section_offset = 0
            local section_y = 13
            local currentY = action_y + action_offset[layout] + 10
            local sFrame = RX9:draw_square(action_x + action_layouts[layout], startY + currentY, 210, section_y + section_offset, comp_background);
            local sTFrame = RX9:draw_rect(action_x + action_layouts[layout] + 12, startY + currentY, 30, 12, Color3.fromRGB(20, 20, 20));
            local sTitle = draw_string(SectionName, action_x + action_layouts[layout] + 14, startY + currentY - 8, 15, 3, Color3.fromRGB(200, 200, 200))
            sTFrame.Size = Vector2.new(sTitle.TextBounds.X + 6, 8)

            local function UpdateSectionY()
                if not section_offset then
                    return
                end 

                sFrame.Size = Vector2.new(sFrame.Size.X, section_y + section_offset)

                action_offset[layout] = action_offset[layout] + (section_y + section_offset) + 10
            end

            section_link(sFrame); 
            section_link(sTFrame); 
            section_link(sTitle);

            add_comp({ X = action_layouts[layout], Y = currentY, Object = sFrame});
            add_comp({ X = action_layouts[layout] + 12, Y = currentY, Object = sTFrame});
            add_comp({ X = action_layouts[layout] + 14, Y = currentY - 8, Object = sTitle});

            local section_action_handler = {}
            local section_action_offset = 0
            local section_action_y = startY + currentY + 12
            local section_action_x = startX + action_layouts[layout] + 5

            local function CreateBoolean(Properties) 
                local Properties = Properties or {
                    Name = Properties.Name or "boolean",
                    Default = Properties.Default or false,
                    X = Properties.X,
                    Y = Properties.Y,
                    OnChanged = Properties.OnChanged or function(value) 
                        print(value)
                    end
                }

                local x, y = Properties.X, Properties.Y
                local name, enabled = Properties.Name, Properties.Default

                local bFrame = RX9:draw_rect(x, y, 13, 13, Color3.fromRGB(45, 45, 45))
                local bFill = RX9:draw_rect(x + 1, y + 1, 11, 11, Color3.fromRGB(91, 40, 231))
                local bText = draw_string(name, (x + 15) + 5, (bFrame.Position.Y - 2), 16, 3, Color3.fromRGB(200, 200, 200))

                section_link(bFrame)
                section_link(bFill)
                section_link(bText)

                add_comp({ X = bFrame.Position.X - startX, Y = bFrame.Position.Y - startY, Object = bFrame });
                add_comp({ X = bFill.Position.X - startX, Y = bFill.Position.Y - startY, Object = bFill });
                add_comp({ X = bText.Position.X - startX, Y = bText.Position.Y - startY, Object = bText });

                local function CompleteBoolean()
                    if not section_class.CompEnabled then
                        return
                    end

                    if enabled then
                        bFill.Visible = true
                    else
                        bFill.Visible = false
                    end
                end

                pcall(CompleteBoolean)

                local FUNCTION = nil

                local boolean_handler = {}

                boolean_handler.Active = true

                function boolean_handler:Connect(Function) 
                    if not FUNCTION then
                        FUNCTION = Function
                    end
                end

                function boolean_handler:Disconnect() 
                    if FUNCTION then
                        FUNCTION = nil
                    else
                        warn("Cannot disconnect function! already nil!")
                    end
                end

                boolean_handler:Connect(Properties.OnChanged)

                connections.boolean_click = UserInputService.InputBegan:Connect(function(input, gameProcessedEvent)
                    if input.UserInputType.Name == "MouseButton1" and boolean_handler.Active and (not DROPDOWN_ACTIVE) and util:mouse_over({
                        bFrame.Position.X, bFrame.Position.Y, bFrame.Position.X + bFrame.Size.X,
                        bFrame.Position.Y + bFrame.Size.Y
                    }) then
                        enabled = not enabled
                        local success, err = pcall(Properties.OnChanged, enabled)
                        if not success then
                            error(("nekoware callback error: %s"):format(err))
                        else
                            CompleteBoolean()
                        end
                    end
                end)

                section_action_offset = section_action_offset + 16
                section_offset = section_offset + 17
                -- UpdateSectionY()
                return boolean_handler
            end

            local function CreateTitle(Properties) 
                local Properties = Properties or {
                    Text = Properties.Text or "text",
                    X = Properties.X,
                    Y = Properties.Y,
                }

                local x, y = Properties.X, Properties.Y
                local text = Properties.Text

                local lText = draw_string(text, x, y, 16, 3, Color3.fromRGB(200, 200, 200))

                section_link(lText)
                add_comp({ X = lText.Position.X - startX, Y = lText.Position.Y - startY, Object = lText });

                section_action_offset = section_action_offset + 18
                section_offset = section_offset + 18
            end 

            local function CreateSlider(Properties) 
                local Properties = Properties or {
                    Name = Properties.Name or "Slider",
                    Range = Properties.Range or { 1, 100},
                    Default = Properties.Default or { 50 },
                    OnChanged = Properties.OnChanged or function(value)
                        print(value)
                    end,
                    X = Properties.X,
                    Y = Properties.Y
                }
            
                local x, y = Properties.X, Properties.Y
                local Min, Max = Properties.Range[1], Properties.Range[2]
                local Default = Properties.Default[1]
                local Value = Default
                local s_dragging = false
            
                local sFrame = RX9:draw_rect(x, y, 200, 15, Color3.fromRGB(25, 25, 25))
                local sBorder = RX9:draw_square(x+1,y+1, 198, 13, Color3.fromRGB(50, 50, 50))
                local sFill = RX9:draw_rect(x+2,y+2, 15, 11, Color3.fromRGB(91, 40, 231))
                local sDisplay = draw_string(("%s: %s/%s"):format(Properties.Name, Value, Max), x + (sFrame.Size.X / 2), y, 15, 3, Color3.fromRGB(200, 200, 200))
                sDisplay.Center = true
            
                section_link(sFrame)
                section_link(sBorder)
                section_link(sFill)
                section_link(sDisplay)
            
                add_comp({ X = sFrame.Position.X - startX, Y = sFrame.Position.Y - startY, Object = sFrame });
                add_comp({ X = sBorder.Position.X - startX, Y = sBorder.Position.Y - startY, Object = sBorder });
                add_comp({ X = sFill.Position.X - startX, Y = sFill.Position.Y - startY, Object = sFill });
                add_comp({ X = sDisplay.Position.X - startX, Y = sDisplay.Position.Y - startY, Object = sDisplay });
            
                if (sDisplay.TextBounds.X > sFrame.Size.X) then
                    sDisplay.Size = 13
                    sDisplay.Position = Vector2.new(x + (sFrame.Size.X / 2), y)
                end
                
                local function UpdateValue()
                    Value = math.floor(Min + (Max - Min) * (sFill.Size.X / (sFrame.Size.X - 4)))
                    sDisplay.Text = ("%s: %s/%s"):format(Properties.Name, Value, Max)
                    local suc, req = pcall(Properties.OnChanged, Value)
                    if not suc then
                        error(("nekoware callback error: %s"):format(req))
                    end
                end
                
                connections.s_begin = UserInputService.InputBegan:Connect(function(input, gameProcessedEvent)
                    if input.UserInputType == Enum.UserInputType.MouseButton1 and (not DROPDOWN_ACTIVE) and not s_dragging and sFrame.Position and section_class.CompEnabled and sFrame.Size then
                        local frame_pos = sFrame.Position
                        local frame_size = sFrame.Size
                        local mouse_pos = input.Position
                        local is_over_frame = util:mouse_over({frame_pos.X, frame_pos.Y, frame_pos.X + frame_size.X, frame_pos.Y + frame_size.Y})
                        if is_over_frame then
                            s_dragging = true
                            local delta_x = mouse_pos.X - frame_pos.X - 2
                            local new_fill_width = math.clamp(delta_x, 1, frame_size.X - 4)
                            sFill.Size = Vector2.new(new_fill_width, sFill.Size.Y)
                            UpdateValue()
                        end
                    end
                end)
                
                connections.s_drag = UserInputService.InputChanged:Connect(function(input, gameProcessedEvent)
                    if input.UserInputType == Enum.UserInputType.MouseMovement and section_class.CompEnabled and (not DROPDOWN_ACTIVE) and s_dragging then
                        local mouse_pos = input.Position
                        local frame_pos = sFrame.Position
                        local frame_size = sFrame.Size
                        local delta_x = mouse_pos.X - frame_pos.X - 2
                        local new_fill_width = math.clamp(delta_x, 1, frame_size.X - 4)
                        sFill.Size = Vector2.new(new_fill_width, sFill.Size.Y)
                        UpdateValue()
                    end
                end)
                
                connections.s_end = UserInputService.InputEnded:Connect(function(input, gameProcessedEvent)
                    if input.UserInputType == Enum.UserInputType.MouseButton1 and s_dragging and (not DROPDOWN_ACTIVE) and section_class.CompEnabled then
                        s_dragging = false
                    end
                end)

                section_action_offset = section_action_offset + 17
                section_offset = section_offset + 17
            end

            local function CreateDropdown(Properties)
                local Properties = Properties or {
                    Name = Properties.Name,
                    Items = Properties.Items or { },
                    Default = Properties.Default or { },
                    OnSelected = Properties.OnSelected or function(option) 
                        print(("Option chosen: %s"):format(option))
                    end,
                    X = Properties.X,
                    Y = Properties.Y
                }

                local x, y, items, default = Properties.X, Properties.Y, Properties.Items, Properties.Default[1]
                local current = default
                local offset = 16

                local function getDefaultValue() 
                    for i, option in pairs(items) do 
                        if default == option then
                            return true
                        else
                            return false
                        end
                    end
                end

                if not (getDefaultValue()) then
                    return
                end 

                local dName = draw_string(Properties.Name, x, y, 16, 3, Color3.fromRGB(200, 200, 200))
                local dFrame = RX9:draw_rect(x, y + 16, 200, 15, Color3.fromRGB(25, 25, 25))
                local dBorder = RX9:draw_square(x+1,y+17, 198, 13, Color3.fromRGB(50, 50, 50))
                local dOpenS = draw_string("+", (x + 200) - 7, y + 16, 14, 3, Color3.fromRGB(150, 150, 150)); dOpenS.Center = true;
                local dChosenO = draw_string(current, x + 5, y + 16, 14, 3, Color3.fromRGB(150, 150, 150));

                section_link(dName)
                section_link(dFrame)
                section_link(dBorder)
                section_link(dOpenS)
                section_link(dChosenO)

                add_comp({ X = dName.Position.X - startX, Y = dName.Position.Y - startY, Object = dName })
                add_comp({ X = dFrame.Position.X - startX, Y = dFrame.Position.Y - startY, Object = dFrame })
                add_comp({ X = dBorder.Position.X - startX, Y = dBorder.Position.Y - startY, Object = dBorder })
                add_comp({ X = dOpenS.Position.X - startX, Y = dOpenS.Position.Y - startY, Object = dOpenS })
                add_comp({ X = dChosenO.Position.X - startX, Y = dChosenO.Position.Y - startY, Object = dChosenO })

                local itemButtons = { }
                local itemObjects = { }

                local function toggleButtonComp(button, bool) 
                    for i, v in pairs(button:GetComp()) do
                        button:Set(bool)
                        if v then
                            v.Visible = bool
                            v.ZIndex = 9
                        else
                            v.ZIndex = 1
                        end
                    end
                end

                --> Draw items
                pcall(function() 
                    for i, v in pairs(items) do 
                        local item_button = create_button(v, x - startX + 1, (y - startY + 17) + offset, 200, 14);
                        local ib_comp = item_button:GetComp()
                        ib_comp[2].Size = 14
                        ib_comp[2].Color = Color3.fromRGB(150, 150, 150)

                        section_link(ib_comp[1])
                        section_link(ib_comp[2])

                        item_button:Connect(function()
                            current = v
                            dChosenO.Text = current

                            local suc, req = pcall(Properties.OnSelected, current)
                            if not suc then
                                error(("nekoware callback error: %s"):format(req))
                            end
                        end)

                        table.insert(itemButtons, item_button)

                        offset = offset + 14
                    end
                end)

                local dropdownOpen = false

                for i, button in pairs(itemButtons) do 
                    toggleButtonComp(button, dropdownOpen)
                end

                local function updateDropdown() 
                    if dropdownOpen then
                        dOpenS.Text = "-"
                        for i, button in pairs(itemButtons) do 
                            toggleButtonComp(button, true)
                        end
                    else
                        dOpenS.Text = "+"
                        for i, button in pairs(itemButtons) do 
                            toggleButtonComp(button, false)
                        end
                    end
                end

                connections.dropdown_begin = UserInputService.InputBegan:Connect(function(input, gameProcessedEvent)
                    if input.UserInputType.Name == "MouseButton1" and section_class.CompEnabled then
                        if util:mouse_over({
                            dFrame.Position.X, dFrame.Position.Y, dFrame.Position.X + dFrame.Size.X,
                            dFrame.Position.Y + dFrame.Size.Y
                        }) then
                            if not DROPDOWN_ACTIVE then
                                dropdownOpen = true
                                DROPDOWN_ACTIVE = true

                                updateDropdown()
                            else
                                if util:mouse_over({
                                    dFrame.Position.X, dFrame.Position.Y, dFrame.Position.X + dFrame.Size.X,
                                    dFrame.Position.Y + dFrame.Size.Y
                                }) then
                                    DROPDOWN_ACTIVE = false
                                    dropdownOpen = false

                                    updateDropdown()
                                end
                            end
                        end
                    end
                end)

                section_action_offset = section_action_offset + 32
                section_offset = section_offset + 32
            end

            --> Handle action creation
            pcall(function() 
                for a_type, action in pairs(SectionActions) do 
                    if (type(action) == "table") then
                        -- print(action["Name"]) 
                        if (string.lower(action.Type) == "boolean" or string.lower(action.Type) == "toggle") then
                            CreateBoolean({
                                Name = action["Name"],
                                Default = action["Default"] or false,
                                X = section_action_x,
                                Y = section_action_y + section_action_offset,
                                OnChanged = action["OnChanged"]
                            })
                        end
                        
                        if (string.lower(action.Type) == "label" or string.lower(action.Type) == "title") then
                            CreateTitle({
                                Text = action["Text"],
                                X = section_action_x,
                                Y = section_action_y + section_action_offset
                            })
                        end

                        if (string.lower(action.Type) == "slider" or string.lower(action.Type) == "number") then
                            CreateSlider({
                                Name = action.Name,
                                Range = action.Range,
                                Default = action.Default,
                                OnChanged = action.OnChanged,
                                X = section_action_x,
                                Y = section_action_y + section_action_offset
                            })
                        end

                        if (string.lower(action.Type) == "dropdown" or string.lower(action.Type) == "list") then
                            CreateDropdown({
                                Name = action.Name,
                                Items = action.Items,
                                Default = action.Default,
                                OnSelected = action.OnSelected,
                                X = section_action_x,
                                Y = section_action_y + section_action_offset
                            })
                        end
                    end
                end
            end)

            UpdateSectionY()

            table.insert(page_class.Actions, section_class)

            return section_action_handler
        end

        table.insert(pages, page_class);

        pButton:Connect(function()
            -- Handle switching pages here
            if page_class.Showing then
                return
            end

            for i, page in ipairs(pages) do 
                if page.Showing then
                    page.Showing = false
                    for j, section in ipairs(page.Actions) do 
                        section.CompEnabled = false
                        for k, comp in ipairs(section.Comp) do 
                            comp.Visible = false
                        end
                    end
                end
            end

            page_class.Showing = true
            for i, section in ipairs(page_class.Actions) do 
                section.CompEnabled = true
                for j, comp in ipairs(section.Comp) do 
                    comp.Visible = true
                end
            end
        end)

        local function initialize_pages()
            for i, page in ipairs(pages) do 
                if i == 1 then
                    page.Showing = true
                else
                    page.Showing = false
                    for j, section in ipairs(page.Actions) do 
                        section.CompEnabled = false
                        for k, comp in ipairs(section.Comp) do 
                            comp.Visible = false
                        end
                    end
                end
            end
        end

        task.spawn(initialize_pages)

        page_button_offset = page_button_offset + pButton:GetComp()[1].Size.X
        return action_handler
    end

    connections.dragBegin = UserInputService.InputBegan:Connect(function(input, gameProcessedEvent)
        if input.UserInputType.Name == "MouseButton1" then 
            if util:mouse_over({frame.Position.X, frame.Position.Y,
                frame.Position.X + frame.Size.X, frame.Position.Y + 30}) 
            then
                dragging = true
                dragX = UserInputService:GetMouseLocation().X - frame.Position.X
                dragY = UserInputService:GetMouseLocation().Y - frame.Position.Y   
            end
        end
    end)

    connections.dragChanged = UserInputService.InputChanged:Connect(function(input, gameProcessedEvent)
        if dragging then
            local newX = UserInputService:GetMouseLocation().X  - dragX
            local newY = UserInputService:GetMouseLocation().Y  - dragY
            startX, startY = newX, newY

            for i, v in pairs(comp) do
                v.Object.Position = Vector2.new(startX + v.X, startY + v.Y)
            end
        end
    end)

    connections.dragEnded = UserInputService.InputEnded:Connect(function(input, gameProcessedEvent)
        if input.UserInputType.Name == "MouseButton1" then
            if dragging then 
                dragging = false
            end
        end
    end)

    connections.destroyMenu = UserInputService.InputBegan:Connect(function(input, gameProcessedEvent)
        if input.KeyCode.Name == "RightBracket" then 
            for i, v in pairs(RX9.RX9_RENDERED) do 
                v:Remove()
            end

            for i, v in pairs(connections) do 
                v:Disconnect()
            end
        end
    end)

    task.defer(function() 
        local update_menu_bool = false


        local ui_settings = page_handler:BeginPage("Settings")

        ui_settings:CreateSection("UI", "Left", {
            {
                Type = "toggle",
                Name = "Custom Theme",
                Default = false,
                OnChanged = function(x) 
                    
                end
            }
        })

        ui_settings:CreateSection("Configuration", "Right", {

        })

        connections.update_menu = RunService.Heartbeat:Connect(function()
            if (update_menu_bool) then
                
            end    
        end)
        
        for i, page in ipairs(pages) do 
            if i == 1 then
                page.Showing = true
            else
                page.Showing = false
                for j, section in ipairs(page.Actions) do 
                    section.CompEnabled = false
                    for k, comp in ipairs(section.Comp) do 
                        comp.Visible = false
                    end
                end
            end
        end
    end)
    
    return page_handler
end

local menu = interface:BeginMenu({
    Name = "nekoware"
})

local p_1 = menu:BeginPage("Page 1")
local p_2 = menu:BeginPage("Page 2")

p_1:CreateSection("Test", "Left", {
    {
        Type = "toggle",
        Name = "Test 1",
        Default = false,
        OnChanged = function(x) 
            print(x)
        end
    },
    {
        Type = "toggle",
        Name = "Test 2",
        Default = true,
        OnChanged = function(x) 
            print(x)
        end
    },
    {
        Type = "label",
        Text = "Aimbot"
    },
    {
        Type = "toggle",
        Name = "Test 2",
        Default = true,
        OnChanged = function(x) 
            print(x)
        end
    },
    {
        Type = "slider",
        Name = "walkspeed",
        Range = { 16, 100 },
        Default = { 19 },
        OnChanged = function(x) 
            print(x)
        end
    },
    {
        Type = "slider",
        Name = "walkspeed",
        Range = { 16, 100 },
        Default = { 19 },
        OnChanged = function(x) 
            print(x)
        end
    },
    {
        Type = "dropdown",
        Name = "Type",
        Items = { "RootPart", "Head", "Torso" },
        Default = { "RootPart" },
        OnSelected = function(option) 
            print(("Option chosen: %s"):format(option))
        end
    },
    {
        Type = "dropdown",
        Name = "Type",
        Items = { "RootPart", "Head", "Torso" },
        Default = { "RootPart" },
        OnSelected = function(option) 
            print(("Option chosen: %s"):format(option))
        end
    }
})

p_2:CreateSection("Test 222", "Left", {
    {
        Type = "toggle",
        Name = "Test 1",
        Default = false,
        OnChanged = function(x) 
            print(x)
        end
    },
    {
        Type = "toggle",
        Name = "Test 2",
        Default = true,
        OnChanged = function(x) 
            print(x)
        end
    },
})