local NAME = "neko.lua"
local AUTHOR = "cdy"
local CONNECTION = nil

local PLAYERS = game:GetService("Players")
local CLIENT = PLAYERS.LocalPlayer

local function SendMessage(MessageOptions) 
    local event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest
    local MessageOptions = MessageOptions or {
        Type = MessageOptions.Type or "None",
        Message = MessageOptions.Message or ":3"
    }

    if MessageOptions.Type == "None" then
        event:FireServer(string.format("%s -> %s", NAME, MessageOptions.Message), "All");
    elseif MessageOptions.Type == "Warn" then
        event:FireServer(string.format("%s -> %s: %s", NAME, "⚠️", MessageOptions.Message), "All");
    elseif MessageOptions.Type == "Error" then
        event:FireServer(string.format("%s -> %s: %s", NAME, "🚨", MessageOptions.Message), "All");
    elseif MessageOptions.Type == "Logic" then
        event:FireServer(string.format("%s -> %s: %s", NAME, "🧠", MessageOptions.Message), "All");
    end
end

do
    local namespaces = {
        logs = {
            error = function(message) 
                SendMessage({
                    Type = "Error",
                    Message = message
                })
            end,
            warn = function(message) 
                SendMessage({
                    Type = "Warn",
                    Message = message
                })
            end,
            logic = function(message) 
                SendMessage({
                    Type = "Logic",
                    Message = message
                })
            end
        },
        sys = {
            cmd = function(command) 
                if command == "stop" then
                    CONNECTION:Disconnect()
                    SendMessage({
                        Type = "Error",
                        Message = "stopped"
                    })
                elseif command == "reset" then
                    CLIENT.Character:BreakJoints() 
                end
            end,
            env = function() 
                SendMessage({
                    Type = "Error",
                    Message = script.Name
                })
            end
        },
    }
    local function handle_string(input_string)
        local class, method, args = input_string:match("(%w+)::(%w+)%((.*)%)")
    
        if namespaces[class] then
            local func = namespaces[class][method]
            if func then
                local arg_table = {}
                if args ~= "" then
                    for arg in args:gmatch("[^,%s]+") do
                        arg = arg:gsub("^%s*(.-)%s*$", "%1") -- trim whitespace
                        table.insert(arg_table, arg)
                    end
                elseif input_string:match("%w+::%w+%(%s*%)") then
                    task.wait(.05)
                    func()
                else
                    SendMessage({
                        Type = "Error",
                        Message = string.format("Invalid syntax '%s'", input_string)
                    })
                    return
                end
                task.wait(.05)
                func(unpack(arg_table))
            else
                SendMessage({
                    Type = "Error",
                    Message = string.format("Method '%s' not found in namespace '%s'", method, namespaces[class])
                })
            end
        else
            SendMessage({
                Type = "Error",
                Message = string.format("Class '%s' not found", class)
            })
        end
    end
    
    
    
    CONNECTION = CLIENT.Chatted:Connect(function(message, recipient)
        if recipient then
            return
        end

        handle_string(message)
    end)
end
