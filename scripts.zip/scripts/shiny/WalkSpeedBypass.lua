local oldremotecall
oldremotecall = hookmetamethod(game, "__namecall", newcclosure(function(self, ...)
    local nc_method = getnamecallmethod()
    local nc_check = checkcaller()
    local args = {...}

    if (nc_method == "FireServer" and type(args[1]) == "number") then 
        return 16
    end

    return oldremotecall(self, args)
end))