local engine = loadstring(game:HttpGet("https://raw.githubusercontent.com/wiIlow/neko-ui-suite/main/main.lua", true))()

local menu = engine:BeginMenu({
    Name = "nekoware - beta !!"
});