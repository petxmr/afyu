local sent = 1
local status = 0

if status == sent then
    print("sent")
end