console.log("MarGPT v.1.0.0");

const { Configuration, OpenAIApi } = require("openai");

const express = require("express");
const WebSocket = require("ws");
const SocketServer = require("ws").Server;
const server = express().listen(3000);

const wss = new SocketServer({server});

function decodeBase64String(encodedString) {
    const buffer = Buffer.from(encodedString, 'base64');
    return buffer.toString('utf-8');
}
  

wss.on('connection', (ws) => {
    console.log('new connection');
    ws.on('close', () => {
        console.log('a connection has been closed');
    });

    ws.on('message', async (message) => {
        console.log("Message recieved: %s", message);

        wss.clients.forEach(async function each(client) {
            const msg = message.toString('utf-8');
            if (msg.startsWith(">")) {
                const configuration = new Configuration({
                    organization: "org-l7wGTktvsR7JDfZv60sqXbAu",
                    apiKey: "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",
                });
    
                console.log(msg);
    
                const openai = new OpenAIApi(configuration);
                const completion = await openai.createChatCompletion({
                    model: "gpt-3.5-turbo",
                    messages: [{role: "user", content: msg}],
                    max_tokens: 50
                });
    
                const reponse = completion.data.choices[0].message.content
    
                client.send(JSON.stringify(reponse));
                console.log(JSON.stringify(reponse));
            }
        });        
    });
});
