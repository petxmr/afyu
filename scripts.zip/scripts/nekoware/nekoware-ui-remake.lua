local Gui = { GUI_RENDERED = { } }
local util = { }
local interface = { }
local services = { UIS=game:GetService("UserInputService"), RS=game:GetService("RunService"), Client=game:GetService("Players").LocalPlayer }
local connections = { }
local themes = { theme_list = { } }
local event = { events = { } }
local interpolate = { }

function interpolate:new(start, goal, alpha) 
    return start + (goal - start) * alpha
end

function event:newEvent(Name, Value, OnChange) 
    if not Name and not OnChange then
        return
    end    
    
    local object = {
        Name = Name,
        Value = Value
    }
    
    local prox = newproxy(true)
    local meta = getmetatable(prox)
    setmetatable(meta, {
        __index = object,
        __newindex = function(_, key, value) 
            if key == "Value" then
                pcall(OnChange, object.Name, value)
            end    
            object[key] = value
        end
    })
    table.insert(event.events, meta)
    return meta
end

function Gui:draw_rect(int_x, int_y, int_width, int_height, color3_color) 
    local GUI_RECT = Drawing.new("Square")
    GUI_RECT.Visible = true
    GUI_RECT.Filled = true
    GUI_RECT.Color = color3_color
    GUI_RECT.Size = Vector2.new(int_width, int_height)
    GUI_RECT.Position = Vector2.new(int_x, int_y)

    table.insert(Gui.GUI_RENDERED, GUI_RECT)
    return GUI_RECT
end

function Gui:draw_square(int_x, int_y, int_width, int_height, color3_color) 
    local GUI_SQUARE = Drawing.new("Square")
    GUI_SQUARE.Visible = true
    GUI_SQUARE.Filled = false
    GUI_SQUARE.Thickness = 1
    GUI_SQUARE.Color = color3_color
    GUI_SQUARE.Size = Vector2.new(int_width, int_height)
    GUI_SQUARE.Position = Vector2.new(int_x, int_y)

    table.insert(Gui.GUI_RENDERED, GUI_SQUARE)
    return GUI_SQUARE
end

function Gui:draw_string(string_content, int_x, int_y, color3_color) 
    local GUI_STRING = Drawing.new("Text")
    GUI_STRING.Visible = true
    GUI_STRING.Center = false
    GUI_STRING.Outline = false
    GUI_STRING.Size = 19
    GUI_STRING.Font = 0
    GUI_STRING.Text = string_content
    GUI_STRING.Position = Vector2.new(int_x, int_y)
    GUI_STRING.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING)
    return GUI_STRING
end

function Gui:draw_string_outline(string_content, int_x, int_y, color3_color, color3_outline_color) 
    local GUI_STRING_OUTLINE = Drawing.new("Text")
    GUI_STRING_OUTLINE.Visible = true
    GUI_STRING_OUTLINE.Center = false
    GUI_STRING_OUTLINE.Outline = true
    GUI_STRING_OUTLINE.Size = 19
    GUI_STRING_OUTLINE.Font = 0
    GUI_STRING_OUTLINE.Text = string_content
    GUI_STRING_OUTLINE.OutlineColor = color3_outline_color
    GUI_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    GUI_STRING_OUTLINE.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_OUTLINE)
    return GUI_STRING_OUTLINE
end

function Gui:draw_string_custom(string_content, int_x, int_y, int_font, int_size, bool_center, bool_visible, bool_outline, color3_color, color3_outline_color) 
    local GUI_STRING_OUTLINE = Drawing.new("Text")
    GUI_STRING_OUTLINE.Visible = bool_visible
    GUI_STRING_OUTLINE.Center = bool_center
    GUI_STRING_OUTLINE.Size = int_size
    GUI_STRING_OUTLINE.Font = int_font
    GUI_STRING_OUTLINE.Text = string_content
    GUI_STRING_OUTLINE.Outline = bool_outline
    GUI_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    GUI_STRING_OUTLINE.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_OUTLINE)
    return GUI_STRING_OUTLINE
end

function Gui:draw_string_custom_font(string_content, int_x, int_y, int_font, color3_color, color3_outline_color) 
    local GUI_STRING_OUTLINE = Drawing.new("Text")
    GUI_STRING_OUTLINE.Visible = true
    GUI_STRING_OUTLINE.Center = false
    GUI_STRING_OUTLINE.Size = 19
    GUI_STRING_OUTLINE.Font = int_font
    GUI_STRING_OUTLINE.Text = string_content
    GUI_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    GUI_STRING_OUTLINE.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_OUTLINE)
    return GUI_STRING_OUTLINE
end

function Gui:draw_string_custom_font_outline(string_content, int_x, int_y, int_font, int_size, color3_color, color3_outline_color) 
    local GUI_STRING_OUTLINE = Drawing.new("Text")
    GUI_STRING_OUTLINE.Visible = true
    GUI_STRING_OUTLINE.Center = false
    GUI_STRING_OUTLINE.Outline = true
    GUI_STRING_OUTLINE.Size = int_size
    GUI_STRING_OUTLINE.Font = int_font
    GUI_STRING_OUTLINE.Text = string_content
    GUI_STRING_OUTLINE.OutlineColor = color3_outline_color
    GUI_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    GUI_STRING_OUTLINE.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_OUTLINE)
    return GUI_STRING_OUTLINE
end

function Gui:draw_string_centered(string_content, int_x, int_y, color3_color) 
    local GUI_STRING_CENTERED = Drawing.new("Text")
    GUI_STRING_CENTERED.Visible = true
    GUI_STRING_CENTERED.Center = true
    GUI_STRING_CENTERED.Outline = false
    GUI_STRING_CENTERED.Size = 19
    GUI_STRING_CENTERED.Font = 0
    GUI_STRING_CENTERED.Text = string_content
    GUI_STRING_CENTERED.Position = Vector2.new(int_x, int_y)
    GUI_STRING_CENTERED.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_CENTERED)
    return GUI_STRING_CENTERED
end

function Gui:draw_vector(vector2_from, vector2_to, number_thickness, color3_color) 
    local GUI_VECTOR = Drawing.new("Line")
    GUI_VECTOR.Visible = true
    GUI_VECTOR.Color = color3_color
    GUI_VECTOR.From = vector2_from
    GUI_VECTOR.To = vector2_to
    GUI_VECTOR.Thickness = number_thickness
    GUI_VECTOR.Transparency = 1
    
    table.insert(Gui.GUI_RENDERED, GUI_VECTOR)
    return GUI_VECTOR
end

function Gui:draw_circle(x, y, radius, color3_color) 
    local GUI_CIRCLE = Drawing.new("Circle")
    GUI_CIRCLE.Visible = true
    GUI_CIRCLE.Color = color3_color
    GUI_CIRCLE.Position = Vector2.new(x, y)
    GUI_CIRCLE.Radius = radius
    GUI_CIRCLE.Filled = true
    GUI_CIRCLE.NumSides = 360
    GUI_CIRCLE.Transparency = 1
    
    table.insert(Gui.GUI_RENDERED, GUI_CIRCLE)
    return GUI_CIRCLE
end

function Gui:draw_image(image, x, y, width, height, rounding) 
    local GUI_IMAGE = Drawing.new("Image")
    GUI_IMAGE.Visible = true
    GUI_IMAGE.Data = game:HttpGet(image)
    GUI_IMAGE.Position = Vector2.new(x, y)
    GUI_IMAGE.Size = Vector2.new(x, y)
    
    table.insert(Gui.GUI_RENDERED, GUI_IMAGE)
    return GUI_IMAGE
end

function Gui:is_mouse_over(positions: table) 
    local x, y, x2, y2 = positions[1], positions[2], positions[3], positions[4]
    local mouseLoc = services.UIS:GetMouseLocation()
    return (mouseLoc.X >= x and mouseLoc.X <= (x + (x2 - x))) and (mouseLoc.Y >= y and mouseLoc.Y <= (y + (y2 - y)))
end

function themes:BeginTheme(ThemeOptions) 
    local themeTemplate = ThemeOptions or {
        Name = ThemeOptions.Name,
        Colors = ThemeOptions.Colors or {
            Primary = ThemeOptions.Colors.Primary,
            Secondary = ThemeOptions.Colors.Secondary,
            ButtonPrimary = ThemeOptions.Colors.ButtonPrimary,
            Accent = ThemeOptions.Colors.Accent,
            Success = ThemeOptions.Colors.Success,
            Error = ThemeOptions.Colors.Error,
            Warning = ThemeOptions.Colors.Warning,
            Info = ThemeOptions.Colors.Info,
            Highlight = ThemeOptions.Colors.Highlight,
            Text = ThemeOptions.Colors.Text,
            TextOutline = ThemeOptions.Colors.TextOutline
        },
        Components = {
            Primary = ThemeOptions.Components.Primary,
            PrimaryLight = ThemeOptions.Components.PrimaryLight,
            Secondary = ThemeOptions.Components.Secondary,
            SecondaryLight = ThemeOptions.Components.SecondaryLight,
            Text = ThemeOptions.Components.Text
        }
    }

    table.insert(themes.theme_list, themeTemplate)
end

function themes:GetTheme(ThemeName) 
    for _, theme in pairs(themes.theme_list) do 
        if theme.Name == ThemeName then
            return theme
        end
    end
end

function interface:BeginMenu(MenuOptions) 
    for _, object in pairs(Gui.GUI_RENDERED) do 
        object[_] = nil
    end
    
    local MenuOptions = MenuOptions or {
        Name = MenuOptions.Name or "nekoware ui suite",
        Animated = MenuOptions.Animated or false,
        Theme = MenuOptions.Theme or "Default"
    }

    themes:BeginTheme({
        Name = "Default",
        Colors = {
            Primary = Color3.fromRGB(21, 21, 21),
            PrimaryLight = Color3.fromRGB(33, 33, 33),
            Secondary = Color3.fromRGB(180, 180, 180),
            ButtonPrimary = Color3.fromRGB(49, 49, 49),
            Accent = Color3.fromRGB(255, 118, 55),
            Success = Color3.fromRGB(70, 255, 135),
            Error = Color3.fromRGB(255, 22, 22),
            Warning = Color3.fromRGB(255, 76, 32),
            Info = Color3.fromRGB(54, 158, 255),
            Highlight = Color3.fromRGB(101, 55, 255),
            Text = Color3.fromRGB(255, 255, 255),
            TextOutline = Color3.fromRGB(0, 0, 0)
        },
        Components = {
            Primary = Color3.fromRGB(37, 38, 42),
            PrimaryLight = Color3.fromRGB(45, 46, 49),
            Secondary = Color3.fromRGB(113, 127, 176),
            SecondaryLight = Color3.fromRGB(137, 154, 213),
            Text = Color3.fromRGB(180, 180, 180),
            Enabled = Color3.fromRGB(64, 180, 252),
            EnabledLight = Color3.fromRGB(116, 202, 255),
        }
    })

    local theme = themes:GetTheme(MenuOptions.Theme)
    local panelX, panelY, panelOffset = 200, 30, 0
    
    local panels = {}
    local panel_handler = {}
    
    function panel_handler:BeginPanel(PanelName)
        local components = { }
        local dragging, panelDragX, panelDragY = false, 0, 0
        local startX, startY = 100 + panelOffset, 100

        local function add_comp(comp_options) 
            table.insert(components, { X = comp_options.X, Y = comp_options.Y, Object = comp_options.Object });
        end
        
        local function draw_string(text, x, y, size, font) 
            local stringg = Gui:draw_string_custom(text, x, y, font, size, false, true,
                true, theme.Colors.Text, theme.Colors.TextOutline)

            return stringg
        end

        local panel_class = {
            Name = PanelName,
            Open = true,
            ElementOffset = 0,
            Elements = {}
        }

        local function add_element(object) 
            table.insert(panel_class.Elements, object)
        end

        local panel_size = panelY
        local panel = Gui:draw_rect(startX, startY, panelX, panel_size, theme.Colors.Primary);
        local panel_title = draw_string(string.lower(PanelName), startX + panelX / 2, startY + panelY / 2 - 12, 20, 1); panel_title.Center = true;

        components["panel"] = { X = 0, Y = 0, Object = panel };
        components["panel_title"] = { X = panelX / 2, Y = panelY / 2 - 12, Object = panel_title }

        if (panel_title.TextBounds.X > panel.Size.X) then
            for i = 0, 50 do 
                local alpha = i / 50
                panel.Size = Vector2.new(interpolate:new(panel.Size.X, panel_title.TextBounds.X + 20, alpha), panel_size)
                panel_title.Position = Vector2.new(startX + panel.Size.X / 2, startY + panel.Size.Y / 2 - 12)
                components[panel_title].X =  panel.Size.X / 2
                task.wait()
            end
        end

        local function updateSize() 
            if not panel then
                return
            end

            panel.Size = Vector2.new(panel.Size.X, panel_size)
        end

        local function updateOnOpen()
            if not panel then
                return
            end

            if panel_class.Open then
                for _, element in pairs(panel_class.Elements) do 
                    element.Visible = true
                end

                updateSize()
            else
                for _, element in pairs(panel_class.Elements) do 
                    element.Visible = false
                end

                panel.Size = Vector2.new(panel.Size.X, panelY)
            end
        end

        local element_handler = {}
        local element_y = panelY
        local element_x = 8
        local element_offset = 0

        function element_handler:CreateBoolean(BooleanOptions) 
            local BooleanOptions = BooleanOptions or {
                Name = BooleanOptions.Name,
                Enabled = BooleanOptions.Enabled or false,
                KeyBind = BooleanOptions.KeyBind or nil,
                OnChanged = BooleanOptions.OnChanged or function(value)
                    print(value)
                end
            }

            local enabled = BooleanOptions.Enabled
            local boolFrame = Gui:draw_rect(startX + element_x, startY + (element_y + element_offset), 15, 15, theme.Components.Primary);
            local boolText  = draw_string(BooleanOptions.Name, startX + (element_x + 23), startY + (element_y + element_offset) - 4, 20, 1);
            local boolBind = {
                frame = nil,
                text = nil
            }

            add_comp({ X = element_x, Y = (element_y + element_offset), Object = boolFrame });
            add_comp({ X = element_x + 23, Y = (element_y + element_offset) - 4, Object = boolText });

            add_element(boolFrame)
            add_element(boolText)

            if (BooleanOptions.KeyBind) then
                boolBind.frame = Gui:draw_rect(startX + ( panelX ), startY + (element_y + element_offset), 40, 15, theme.Components.Primary);
                boolBind.text = draw_string(Enum.KeyCode[BooleanOptions.KeyBind].Name, boolBind.frame.Position.X + (-boolBind.frame.Size.X + 10), startY + (element_y + element_offset), 16, 1);
                boolBind.text.Center = true;
                boolBind.text.Position = Vector2.new(boolBind.frame.Position.X + (-boolBind.frame.Size.X + 10), startY + (element_y + element_offset) - 1);
                boolBind.frame.Size = Vector2.new(boolBind.text.TextBounds.X + 15, 15);
                boolBind.frame.Position = Vector2.new(startX + ( panelX - (boolBind.frame.Size.X) - 10), startY + (element_y + element_offset));
                boolBind.text.Position = Vector2.new(boolBind.frame.Position.X - (-boolBind.frame.Size.X + 10), startY + (element_y + element_offset) - 1);

                add_comp({ X = ( panelX - (boolBind.frame.Size.X) - 10), Y = (element_y + element_offset), Object = boolBind.frame });
                add_comp({ X = ( panelX - (boolBind.frame.Size.X) - 10) + (boolBind.frame.Size.X / 2), Y = (element_y + element_offset) - 1, Object = boolBind.text });

                add_element(boolBind.frame);
                add_element(boolBind.text);
            end

            local function updateBool() 
                if enabled then
                    boolFrame.Color = theme.Components.Enabled
                else
                    boolFrame.Color = theme.Components.Primary
                end
            end

            local function updateOnHover(bool) 
                if bool then
                    if enabled then
                        boolFrame.Color = theme.Components.EnabledLight
                    else
                        boolFrame.Color = theme.Components.PrimaryLight
                    end
                else
                    if enabled then
                        boolFrame.Color = theme.Components.Enabled
                    else
                        boolFrame.Color = theme.Components.Primary
                    end
                end
            end

            pcall(updateBool)

            local suc, err = pcall(BooleanOptions.OnChanged, enabled)
            if not suc then
                error(string.format("nekoware callback error: %s", err))
            else
                updateBool()
            end

            local debounce = false
            connections.bool_bind_apply = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
                if not BooleanOptions.KeyBind then
                    return
                end
                
                if Gui:is_mouse_over({
                    boolBind.frame.Position.X, boolBind.frame.Position.Y,
                    boolBind.frame.Position.X + boolBind.frame.Size.X,
                    boolBind.frame.Position.Y + boolBind.frame.Size.Y
                }) and not debounce then
                    debounce = true
                    boolBind.text.Text = "..."
                end
            end)

            connections.bool_bind_get = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
                if debounce and input.UserInputType == Enum.UserInputType.Keyboard then
                    
                    local keycode = input.KeyCode

                    if keycode.Name == "Escape" or keycode.Name == "Backspace" then
                        boolBind.text.Text = ""
                        BooleanOptions.KeyBind = ""
                    else
                        boolBind.text.Text = keycode.Name
                        boolBind.frame.Size = Vector2.new(boolBind.text.TextBounds.X + 15, 15);
                        boolBind.frame.Position = Vector2.new(startX + ( panelX - (boolBind.frame.Size.X) - 10), boolBind.frame.Position.Y);
                        boolBind.text.Position = Vector2.new(boolBind.frame.Position.X + (boolBind.frame.Size.X / 2), boolBind.frame.Position.Y - 1);
                        BooleanOptions.KeyBind = keycode.Name
                    end

                    debounce = false
                end
            end)

            connections.bool_bind = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
                if not BooleanOptions.KeyBind then return end
                if input.KeyCode == Enum.KeyCode[BooleanOptions.KeyBind] and boolFrame then
                    enabled = not enabled
                    local suc, err = pcall(BooleanOptions.OnChanged, enabled)
                    if not suc then
                        error(string.format("nekoware callback error: %s", err))
                    else
                        updateBool()
                    end 
                end
            end)

            connections.bool_click = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
                if input.UserInputType.Name == "MouseButton1" and boolFrame then
                    if Gui:is_mouse_over({
                        boolFrame.Position.X, boolFrame.Position.Y,
                        boolFrame.Position.X + boolFrame.Size.X,
                        boolFrame.Position.Y + boolFrame.Size.Y
                    }) then
                        enabled = not enabled
                        local suc, err = pcall(BooleanOptions.OnChanged, enabled)
                        if not suc then
                            error(string.format("nekoware callback error: %s", err))
                        else
                            updateBool()
                        end
                    end
                end
            end)

            connections.bool_hover = services.UIS.InputChanged:Connect(function(input, gameProcessedEvent)
                if input.UserInputType.Name == "MouseMovement" and boolFrame then
                    if Gui:is_mouse_over({
                        boolFrame.Position.X, boolFrame.Position.Y,
                        boolFrame.Position.X + boolFrame.Size.X,
                        boolFrame.Position.Y + boolFrame.Size.Y
                    }) then
                        updateOnHover(true)
                    else
                        updateOnHover(false)
                    end
                end
            end)

            panel_size = panel_size + 23
            element_offset = element_offset + 23
            updateSize()
        end

        function element_handler:CreateMode(ModeOptions) 
            local ModeOptions = ModeOptions or {
                Name = ModeOptions.Name,
                Modes = ModeOptions.Modes or {"1", "2", "3", "3"},
                Default = ModeOptions.Default or {"1"},
                OnChanged = ModeOptions.OnChanged or function(mode) 
                    print(mode)
                end
            }

            local modeIndex = 1 or table.find(ModeOptions.Modes, ModeOptions.Default[1])
            local currentMode = ""

            local function cycleModes() 
                if modeIndex < #ModeOptions.Modes + 1 then
                    modeIndex = modeIndex + 1
                    currentMode = ModeOptions.Modes[modeIndex]
                    if modeIndex == #ModeOptions.Modes + 1 then
                        modeIndex = 1
                        currentMode = ModeOptions.Modes[modeIndex]
                    end
                end
            end

            local modeFrame = Gui:draw_rect(startX, startY + (element_y + element_offset), panel.Size.X, 17, theme.Colors.Secondary); modeFrame.Transparency = 0;
            local modeDisplay = draw_string(string.format("%s: %s", ModeOptions.Name, ModeOptions.Modes[modeIndex]), startX + element_x, startY + (element_y + element_offset) - 3, 20, 1);

            add_comp({ X = 0, Y = (element_y + element_offset), Object = modeFrame });
            add_comp({ X = element_x, Y = (element_y + element_offset) - 3, Object = modeDisplay });

            add_element(modeFrame)
            add_element(modeDisplay)

            connections.mode_click = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
                if input.UserInputType.Name == "MouseButton1" and modeFrame and modeDisplay then
                    if Gui:is_mouse_over({
                        modeFrame.Position.X, modeFrame.Position.Y,
                        modeFrame.Position.X + modeFrame.Size.X,
                        modeFrame.Position.Y + modeFrame.Size.Y 
                    }) then
                        cycleModes()
                        modeDisplay.Text = string.format("%s: %s", ModeOptions.Name, currentMode)
                        local suc, req = pcall(ModeOptions.OnChanged, currentMode)
                        if not suc then
                            error(req)
                        end
                    end
                end
            end)

            panel_size = panel_size + 20
            element_offset = element_offset + 20
            updateSize()
        end

        function element_handler:CreateSlider(SliderOptions) 
            local SliderOptions = SliderOptions or {
                Name = SliderOptions.Name,
                Range = SliderOptions.Range or { 0, 100 },
                Default = SliderOptions.Default or { 50 },
                OnChanged = SliderOptions.OnChanged or function(value)
                    print(value)
                end
            }

            local Min, Max = SliderOptions.Range[1], SliderOptions.Range[2]
            local Default = SliderOptions.Default[1]
            local s_dragging = false

            local sliderFrame = Gui:draw_rect(startX, startY + (element_y + element_offset), panelX, 27, theme.Colors.Primary);
            local sliderFill  = Gui:draw_rect(startX, startY + (element_y + element_offset) + 24, 10, 3, theme.Components.Enabled);
            local sliderDisplay = draw_string(string.format("%s: %s", SliderOptions.Name, tostring(Default)), startX + element_x, startY + (element_y + element_offset), 20, 1);

            add_comp({ X = 0, Y = (element_y + element_offset), Object = sliderFrame });
            add_comp({ X = 0, Y = (element_y + element_offset) + 24, Object = sliderFill });
            add_comp({ X = element_x, Y = (element_y + element_offset), Object = sliderDisplay });
            
            add_element (sliderFrame);
            add_element (sliderFill);
            add_element (sliderDisplay);

            local function UpdateFill() 
                --> Update the sliderFill.Size.X size due to the value.
                local relative_position = Vector2.new((Default - Min) / (Max - Min) * sliderFrame.Size.X, 0)
                local slider_width = sliderFrame.Size.X
                relative_position = Vector2.new(math.clamp(relative_position.X, 0, slider_width), relative_position.Y)
                sliderFill.Size = Vector2.new(relative_position.X, 3)
                local range = Max - Min
                local value = (Default < Min) and math.ceil((Default - Min) / range * slider_width) + Min or
                            (Default > Max) and Max or Default
                sliderDisplay.Text = string.format("%s: %s", SliderOptions.Name, tostring(value))
                local success, result = pcall(SliderOptions.OnChanged, value)
                if not success then
                    warn("Error in OnChanged function:", result)
                end
            end

            pcall(UpdateFill)

            connections.slider_begin = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
                --> Begin the drag here
                if input.UserInputType.Name == "MouseButton1" and Gui:is_mouse_over({
                    sliderFrame.Position.X, sliderFrame.Position.Y, sliderFrame.Position.X + sliderFrame.Size.X,
                    sliderFrame.Position.Y + sliderFrame.Size.Y
                }) then
                    s_dragging = true
                    local mouse_position = Vector2.new(input.Position.X, input.Position.Y)
                    local relative_position = mouse_position - sliderFrame.Position
                    local slider_width = sliderFrame.Size.X
                    relative_position = Vector2.new(math.clamp(relative_position.X, 0, slider_width), relative_position.Y)
                    sliderFill.Size = Vector2.new(relative_position.X, 3)
                    local range = Max - Min
                    local value = math.floor((relative_position.X / slider_width) * range + Min)
                    sliderDisplay.Text = string.format("%s: %s", SliderOptions.Name, tostring(value))
                    local success, result = pcall(SliderOptions.OnChanged, value)
                    if not success then
                        warn("Error in OnChanged function:", result)
                    end
                end
            end)

            connections.slider_update = services.UIS.InputChanged:Connect(function(input, gameProcessedEvent)
                if s_dragging then
                    local mouse_position = Vector2.new(input.Position.X, input.Position.Y)
                    local relative_position = mouse_position - sliderFrame.Position
                    local slider_width = sliderFrame.Size.X
                    relative_position = Vector2.new(math.clamp(relative_position.X, 0, slider_width), relative_position.Y)
                    sliderFill.Size = Vector2.new(relative_position.X, 3)
                    local range = Max - Min
                    local value = math.floor((relative_position.X / slider_width) * range + Min)

                    sliderDisplay.Text = string.format("%s: %s", SliderOptions.Name, tostring(value))
                    local success, result = pcall(SliderOptions.OnChanged, value)
                    if not success then
                        warn("Error in OnChanged function:", result)
                    end
                end
            end)            

            connections.slider_end = services.UIS.InputEnded:Connect(function(input, gameProcessedEvent)
                if input.UserInputType.Name == "MouseButton1" then
                    if s_dragging then
                        s_dragging = false
                    end
                end
            end)

            panel_size = panel_size + 27
            element_offset = element_offset + 27
            updateSize()
        end

        function element_handler:Set(First, Second, NewColor) 
            theme[First][Second] = NewColor
        end

        connections.open_panel = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
            if input.UserInputType.Name == "MouseButton2" then
                if Gui:is_mouse_over({
                    panel.Position.X, panel.Position.Y,
                    panel.Position.X + panel.Size.X,
                    panel.Position.Y + panelY
                }) then
                    panel_class.Open = not panel_class.Open
                    updateOnOpen()
                end
            end
        end)

        connections.drag_begin = services.UIS.InputBegan:Connect(function(input)
            if input.UserInputType.Name == "MouseButton1" then
                if Gui:is_mouse_over({
                    panel.Position.X, panel.Position.Y,
                    panel.Position.X + panel.Size.X,
                    panel.Position.Y + panelY
                }) then
                    dragging = true
                    panelDragX = services.UIS:GetMouseLocation().X - panel.Position.X
                    panelDragY = services.UIS:GetMouseLocation().Y - panel.Position.Y
                end
            end
        end)
    
        connections.drag_move = services.UIS.InputChanged:Connect(function(input)
            if input.UserInputType.Name == "MouseMovement" and dragging then
                local newX = services.UIS:GetMouseLocation().X - panelDragX
                local newY = services.UIS:GetMouseLocation().Y - panelDragY
                startX = newX
                startY = newY
    
                for _, comp in pairs(components) do
                    comp.Object.Position = Vector2.new(startX + comp.X, startY + comp.Y)
                end
            end
        end)
    
        connections.drag_ended = services.UIS.InputEnded:Connect(function(input)
            if input.UserInputType.Name == "MouseButton1" then
                if dragging then 
                    dragging = false
                end
            end
        end)

        panelOffset = panelOffset + (15 + panel.Size.X)
        return element_handler
    end

    connections.destroy_menu = services.UIS.InputBegan:Connect(function(input)
        if input.KeyCode.Name == "RightBracket" then 
            for i, v in pairs(Gui.GUI_RENDERED) do 
                v:Remove()
            end

            for i, v in pairs(connections) do 
                if v then
                    v:Disconnect()
                end
            end
        end
    end)

    return panel_handler
end

local menu = interface:BeginMenu({
    Theme = "Default"
})

local combat = menu:BeginPanel("Combat")
local movement = menu:BeginPanel("Movement")
local visual = menu:BeginPanel("Visual")

combat:CreateBoolean({
    Name = "Aimbot",
    Enabled = false,
    OnChanged = function(value)
        print(value)
    end
})

combat:CreateBoolean({
    Name = "FOV",
    Enabled = false,
    OnChanged = function(value) 
        print(value)
    end
})

combat:CreateSlider({
    Name = "Smoothness",
    Range = { 0.01, 1 },
    Default = { 0.01 },
    OnChanged = function(value) 
        print(value)
    end
})

combat:CreateSlider({
    Name = "FOV Scale",
    Range = { 10, 300 },
    Default = { 10 },
    OnChanged = function(value) 
        print(value)
    end
})
