local Gui = { GUI_RENDERED = { } }
local util = { }
local interface = { }
local services = { UIS=game:GetService("UserInputService"), RS=game:GetService("RunService"), Client=game:GetService("Players").LocalPlayer, CAS = game:GetService("ContextActionService") }
local connections = { }
local event = { events = { } }
local interpolation = { }

function interpolation:linear(start, goal, t) 
    if typeof(start) == "Vector2" and typeof(goal) == "Vector2" then
        local x = start.X + (goal.X - start.X) * t
        local y = start.Y + (goal.Y - start.Y) * t
        return Vector2.new(x, y)
    elseif typeof(start) == "Color3" and typeof(goal) == "Color3" then
        local r = start.R + (goal.R - start.R) * t
        local g = start.G + (goal.G - start.G) * t
        local b = start.B + (goal.B - start.B) * t
        return Color3.fromRGB(r, g, b)
    else
        return start + (goal - start) * t
    end
end

function interpolation:new(animation_type, start, goal, alpha) 
    local t = math.clamp(alpha, 0, 1)

    if animation_type == "ease-in" then
        t = math.sin(t * math.pi / 2)
    elseif animation_type == "bounce" then
        local period = 1.2
        t = 1 - math.abs(math.cos(t * math.pi / period)) * (1 - t)
        t = t * t * (3 - 2 * t)
    elseif animation_type == "elastic-in" then
        local period = 0.3
        local amplitude = 1.5
        t = 1 - math.cos(t * math.pi * 2.5) * math.exp(-t * period * 3)
        t = t * (1 + amplitude * (1 - math.cos(t * math.pi * 2.5)))
    end

    if typeof(start) == "Vector2" and typeof(goal) == "Vector2" then
        local x = interpolation:linear(start.X, goal.X, t)
        local y = interpolation:linear(start.Y, goal.Y, t)
        return Vector2.new(x, y)
    elseif typeof(start) == "Color3" and typeof(goal) == "Color3" then
        local r = interpolation:linear(start.R, goal.R, t)
        local g = interpolation:linear(start.G, goal.G, t)
        local b = interpolation:linear(start.B, goal.B, t)
        return Color3.fromRGB(r, g, b)
    else
        return start + (goal - start) * t
    end
end

function Gui:draw_rect(int_x, int_y, int_width, int_height, color3_color) 
    local GUI_RECT = Drawing.new("Square")
    GUI_RECT.Visible = true
    GUI_RECT.Filled = true
    GUI_RECT.Color = color3_color
    GUI_RECT.Size = Vector2.new(int_width, int_height)
    GUI_RECT.Position = Vector2.new(int_x, int_y)

    table.insert(Gui.GUI_RENDERED, GUI_RECT)
    return GUI_RECT
end

function Gui:draw_square(int_x, int_y, int_width, int_height, color3_color) 
    local GUI_SQUARE = Drawing.new("Square")
    GUI_SQUARE.Visible = true
    GUI_SQUARE.Filled = false
    GUI_SQUARE.Thickness = 1
    GUI_SQUARE.Color = color3_color
    GUI_SQUARE.Size = Vector2.new(int_width, int_height)
    GUI_SQUARE.Position = Vector2.new(int_x, int_y)

    table.insert(Gui.GUI_RENDERED, GUI_SQUARE)
    return GUI_SQUARE
end

function Gui:draw_string(string_content, int_x, int_y, color3_color) 
    local GUI_STRING = Drawing.new("Text")
    GUI_STRING.Visible = true
    GUI_STRING.Center = false
    GUI_STRING.Outline = false
    GUI_STRING.Size = 19
    GUI_STRING.Font = 0
    GUI_STRING.Text = string_content
    GUI_STRING.Position = Vector2.new(int_x, int_y)
    GUI_STRING.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING)
    return GUI_STRING
end

function Gui:draw_string_outline(string_content, int_x, int_y, color3_color, color3_outline_color) 
    local GUI_STRING_OUTLINE = Drawing.new("Text")
    GUI_STRING_OUTLINE.Visible = true
    GUI_STRING_OUTLINE.Center = false
    GUI_STRING_OUTLINE.Outline = true
    GUI_STRING_OUTLINE.Size = 19
    GUI_STRING_OUTLINE.Font = 0
    GUI_STRING_OUTLINE.Text = string_content
    GUI_STRING_OUTLINE.OutlineColor = color3_outline_color
    GUI_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    GUI_STRING_OUTLINE.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_OUTLINE)
    return GUI_STRING_OUTLINE
end

function Gui:draw_string_custom(string_content, int_x, int_y, int_font, int_size, bool_center, bool_visible, bool_outline, color3_color, color3_outline_color) 
    local GUI_STRING_OUTLINE = Drawing.new("Text")
    GUI_STRING_OUTLINE.Visible = bool_visible
    GUI_STRING_OUTLINE.Center = bool_center
    GUI_STRING_OUTLINE.Size = int_size
    GUI_STRING_OUTLINE.Font = int_font
    GUI_STRING_OUTLINE.Text = string_content
    GUI_STRING_OUTLINE.Outline = bool_outline
    GUI_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    GUI_STRING_OUTLINE.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_OUTLINE)
    return GUI_STRING_OUTLINE
end

function Gui:draw_string_custom_font(string_content, int_x, int_y, int_font, color3_color, color3_outline_color) 
    local GUI_STRING_OUTLINE = Drawing.new("Text")
    GUI_STRING_OUTLINE.Visible = true
    GUI_STRING_OUTLINE.Center = false
    GUI_STRING_OUTLINE.Size = 19
    GUI_STRING_OUTLINE.Font = int_font
    GUI_STRING_OUTLINE.Text = string_content
    GUI_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    GUI_STRING_OUTLINE.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_OUTLINE)
    return GUI_STRING_OUTLINE
end

function Gui:draw_string_custom_font_outline(string_content, int_x, int_y, int_font, int_size, color3_color, color3_outline_color) 
    local GUI_STRING_OUTLINE = Drawing.new("Text")
    GUI_STRING_OUTLINE.Visible = true
    GUI_STRING_OUTLINE.Center = false
    GUI_STRING_OUTLINE.Outline = true
    GUI_STRING_OUTLINE.Size = int_size
    GUI_STRING_OUTLINE.Font = int_font
    GUI_STRING_OUTLINE.Text = string_content
    GUI_STRING_OUTLINE.OutlineColor = color3_outline_color
    GUI_STRING_OUTLINE.Position = Vector2.new(int_x, int_y)
    GUI_STRING_OUTLINE.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_OUTLINE)
    return GUI_STRING_OUTLINE
end

function Gui:draw_string_centered(string_content, int_x, int_y, color3_color) 
    local GUI_STRING_CENTERED = Drawing.new("Text")
    GUI_STRING_CENTERED.Visible = true
    GUI_STRING_CENTERED.Center = true
    GUI_STRING_CENTERED.Outline = false
    GUI_STRING_CENTERED.Size = 19
    GUI_STRING_CENTERED.Font = 0
    GUI_STRING_CENTERED.Text = string_content
    GUI_STRING_CENTERED.Position = Vector2.new(int_x, int_y)
    GUI_STRING_CENTERED.Color = color3_color

    table.insert(Gui.GUI_RENDERED, GUI_STRING_CENTERED)
    return GUI_STRING_CENTERED
end

function Gui:draw_vector(vector2_from, vector2_to, number_thickness, color3_color) 
    local GUI_VECTOR = Drawing.new("Line")
    GUI_VECTOR.Visible = true
    GUI_VECTOR.Color = color3_color
    GUI_VECTOR.From = vector2_from
    GUI_VECTOR.To = vector2_to
    GUI_VECTOR.Thickness = number_thickness
    GUI_VECTOR.Transparency = 1
    
    table.insert(Gui.GUI_RENDERED, GUI_VECTOR)
    return GUI_VECTOR
end

function Gui:draw_circle(x, y, radius, color3_color) 
    local GUI_CIRCLE = Drawing.new("Circle")
    GUI_CIRCLE.Visible = true
    GUI_CIRCLE.Color = color3_color
    GUI_CIRCLE.Position = Vector2.new(x, y)
    GUI_CIRCLE.Radius = radius
    GUI_CIRCLE.Filled = true
    GUI_CIRCLE.NumSides = 360
    GUI_CIRCLE.Transparency = 1
    
    table.insert(Gui.GUI_RENDERED, GUI_CIRCLE)
    return GUI_CIRCLE
end

function Gui:draw_image(image, x, y, width, height, rounding) 
    local GUI_IMAGE = Drawing.new("Image")
    GUI_IMAGE.Visible = true
    GUI_IMAGE.Data = game:HttpGet(image)
    GUI_IMAGE.Position = Vector2.new(x, y)
    GUI_IMAGE.Size = Vector2.new(width, height)
    GUI_IMAGE.Rounding = rounding
    
    table.insert(Gui.GUI_RENDERED, GUI_IMAGE)
    return GUI_IMAGE
end

function Gui:on_object_click(parent, mouse_button, callback) 
    local button = function() 
        if (mouse_button == "left" or "Left" or "1" or 1) then
            return Enum.UserInputType.MouseButton1
        end

        if (mouse_button == "right" or "Right" or "2" or 2) then
            return Enum.UserInputType.MouseButton2
        end

        return nil
    end

    connections.on_object_click = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
        if input.UserInputType == button and (callback) then 
            local x, y, x2, y2 = parent.Position.X, parent.Position.Y, parent.Position.X + parent.Size.X, parent.Position.Y + parent.Size.Y
            local mouseLoc = services.UIS:GetMouseLocation()
            if ((mouseLoc.X >= x and mouseLoc.X <= (x + (x2 - x))) and (mouseLoc.Y >= y and mouseLoc.Y <= (y + (y2 - y)))) then
                local suc, req = pcall(callback)
                if not suc then
                    error(script.Name, req)
                end
            end
        end
    end)
end

function interface:BeginMenu(MenuOptions) 
    local MenuOptions = MenuOptions or {
        StartPos = MenuOptions.StartPos or { 100, 100 },
        Saves = MenuOptions.Saves or false
    }

    if not (getgenv().GLOBAL_ACTIONS and not getgenv().CONFIGURATIONS and not getgenv().RUNNING) then 
        getgenv().GLOBAL_ACTIONS = { }
        getgenv().CONFIGURATIONS = { }
        getgenv().RUNNING = true
    end

    if not (getgenv().RUNNING) then
        return
    end

    local MenuFunctions = { }

    local dir = "mystic/saved/"
    local s_dir = "mystic/scripts"
        
    if not (isfolder(dir)) then
        makefolder(dir)
        MenuFunctions.Folder = true

        if not (isfile(("%sdefault.lua"):format(dir))) then
            writefile(("%sdefault.lua"):format(dir), "return nil")
            MenuFunctions.File = true
        end
    end

    local function GetFileData(file) 
        if (isfile(("%s%s.lua"):format(dir, file))) and MenuFunctions.Folder and MenuFunctions.File then
            return readfile(file)
        end
    end

    MenuFunctions.Save = function(name) 
        if not (name) then
            return
        end

        if not (isfile(("%s%s.lua"):format(dir, name))) then
            local get_data = function()
                local current_config = {}
                
                for i, action in pairs(getgenv().GLOBAL_ACTIONS) do
                    if action.Type == "checkbox" then
                        table.insert(current_config, string.format("{Name=%q,Value=%q}", action.Name, action.Value))
                    elseif action.Type == "slider" then
                        table.insert(current_config, string.format("{Name=%q,Step=%q,Value=%q}", action.Name, action.Step, action.Value))
                    elseif action.Type == "modes" then
                        table.insert(current_config, string.format("{Name=%q,Index=%q,Modes={%s}}", action.Name, action.Index, table.concat(action.Modes, ",")))
                    end
                end
                
                local data = string.format("return {%s}", table.concat(current_config, ","))
                
                return data
            end

            writefile(("%s%s.lua"):format(dir, name), get_data())
        end
    end

    MenuFunctions.Load = function(timeout, file)
        if (timeout) then
            task.wait(timeout)
        end

        local data = GetFileData(file)

        print(data[1][1].Name)

        print("Sucessfully Loaded Configuration File.")
    end

    local movables = { }

    local function init_m(options) 
        table.insert(movables, { X = options.X, Y = options.Y, Object = options.Object });
    end

    local frames = { }
    local submenus = { }
    local submenu_handler = { }

    local function init_f(options) 
        table.insert(frames, { X = options.X, Y = options.U, Width = options.Width, Object = options.Object })
    end

    local menu_width = 370
    local menu_height = 30
    local menu_bg = Color3.fromRGB(17, 17, 17)
    local menu_bg_selected = Color3.fromRGB(255, 255, 255)
    local menu_transparency = 0.7
    local menu_x = MenuOptions.StartPos[1]
    local menu_y = MenuOptions.StartPos[2]
    local menu_offset = 0
    local menu_text_size = 17
    local submenu_index = 1

    local current_menu = "menus"

    local function draw_string(text, x, y) 
        local stringg = Gui:draw_string_custom(text, x, y, 0, menu_text_size, false, true, false, Color3.fromRGB(255, 255 , 255), Color3.fromRGB(255, 255 , 255))
    
        return stringg
    end

    local values = {
        slider_delay = 1
    }

    local flags = {
        editing = false,
        moving = false,
        updating = false,
        in_menus = false,
        just_entered = false,
        allow_action_control = false,
        actions_locked = false,
        modal = false,
    }

    local context_frame = Gui:draw_rect(menu_x, menu_y - menu_height, menu_width, menu_height, Color3.fromRGB(28, 28, 28));
    local context_title = draw_string(string.upper(current_menu), menu_x + 7, menu_y - menu_height + 5);
    local context_menu_index = draw_string(string.format("%d/%d", submenu_index, #submenus), menu_x + menu_width - 22, menu_y - menu_height + 5); context_menu_index.Center = true

    init_f({ X = 0, Y = -menu_height, Width = menu_width, Object = context_frame });

    init_m({ X = 0, Y = -menu_height, Object = context_frame });
    init_m({ X = 7, Y = -menu_height + 5, Object = context_title });
    init_m({ X = menu_width - 22, Y = -menu_height + 5, Object = context_menu_index });

    local function removeFTB(containerTable, targetTable)
        local index = table.find(containerTable, targetTable)
        if index then
          table.remove(containerTable, index)
        end
    end      

    getgenv().API = nil

    function Gui:create_text_modal(callback)
        flags.modal = true

        local function draw_new_string(text, x, y, size) 
            local stringg = Gui:draw_string_custom(text, x, y, 0, size, false, true, false, Color3.fromRGB(255, 255 , 255), Color3.fromRGB(255, 255 , 255))
        
            return stringg
        end

        local vp = workspace.CurrentCamera.ViewportSize
        local text_cover = Gui:draw_rect(0, 0, vp.X, vp.Y, Color3.fromRGB(0, 0, 0)); text_cover.Transparency = 0.75;
        local text_area = Gui:draw_rect(40, vp.Y / 2 - 10, vp.X - 80, 30, Color3.fromRGB(20, 20, 20));
        local text_box = draw_new_string("", 45, vp.Y / 2 - 10 + 4, 21);

        services.CAS:BindActionAtPriority("DisableMovement", function() 
            return Enum.ContextActionResult.Sink;
        end, false, Enum.ContextActionPriority.High.Value,
            Enum.KeyCode.W, Enum.KeyCode.A, Enum.KeyCode.S, 
            Enum.KeyCode.D, Enum.KeyCode.Space, Enum.KeyCode.LeftShift, 
            Enum.KeyCode.RightShift, Enum.KeyCode.Escape, Enum.KeyCode.I, 
            Enum.KeyCode.O, Enum.KeyCode.Quote, Enum.KeyCode.Backquote, Enum.KeyCode.Tab, Enum.KeyCode.Slash,
            Enum.KeyCode.Period);

        local keyModifiers = {
            Enum.KeyCode.LeftShift,
            Enum.KeyCode.RightShift,
            Enum.KeyCode.LeftControl,
            Enum.KeyCode.RightControl,
            Enum.KeyCode.LeftAlt,
            Enum.KeyCode.RightAlt,
            Enum.KeyCode.CapsLock,
            Enum.KeyCode.Tab,
            Enum.KeyCode.Period
        }

        local bools = {
            capsLock = false,
        }
        
        connections.capture_keys = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
            if input.UserInputType == Enum.UserInputType.Keyboard and flags.modal then
                if input.KeyCode.Name == "Return" or input.KeyCode.Name == "Escape" then
                    text_cover:Remove()
                    text_area:Remove()
                    text_box:Remove()

                    local suc, req = pcall(callback, text_box.Text)
                    if not suc then
                        error(req)
                    end
                    
                    task.wait(.1)
                    flags.modal = false
                    services.CAS:UnbindAction("DisableMovement")
                    connections.capture_keys:Disconnect()
                elseif input.KeyCode.Name == "Space" then
                    text_box.Text = text_box.Text .. " "
                elseif input.KeyCode.Name == "Comma" then
                    text_box.Text = text_box.Text .. ","
                elseif input.KeyCode == Enum.KeyCode.Backquote then
                    text_box.Text = text_box.Text .. "`"
                elseif input.KeyCode == Enum.KeyCode.BackSlash then
                    text_box.Text = text_box.Text .. "\\"
                elseif input.KeyCode.Name == "Slash" then
                    text_box.Text = text_box.Text .. "/"
                elseif input.KeyCode == Enum.KeyCode.Quote then
                    text_box.Text = text_box.Text .. "'"
                elseif input.KeyCode == Enum.KeyCode.Minus then
                    text_box.Text = text_box.Text .. "-"
                elseif input.KeyCode == Enum.KeyCode.Equals then
                    text_box.Text = text_box.Text .. "="
                elseif input.KeyCode == Enum.KeyCode.One then
                    text_box.Text = text_box.Text .. "1"
                elseif input.KeyCode == Enum.KeyCode.Two then
                    text_box.Text = text_box.Text .. "2"
                elseif input.KeyCode == Enum.KeyCode.Three then
                    text_box.Text = text_box.Text .. "3"
                elseif input.KeyCode == Enum.KeyCode.Four then
                    text_box.Text = text_box.Text .. "4"
                elseif input.KeyCode == Enum.KeyCode.Five then
                    text_box.Text = text_box.Text .. "5"
                elseif input.KeyCode == Enum.KeyCode.Six then
                    text_box.Text = text_box.Text .. "6"
                elseif input.KeyCode == Enum.KeyCode.Seven then
                    text_box.Text = text_box.Text .. "7"
                elseif input.KeyCode == Enum.KeyCode.Eight then
                    text_box.Text = text_box.Text .. "8"
                elseif input.KeyCode == Enum.KeyCode.Nine then
                    text_box.Text = text_box.Text .. "9"
                elseif input.KeyCode == Enum.KeyCode.Zero then
                    text_box.Text = text_box.Text .. "0"
                elseif input.KeyCode == Enum.KeyCode.LeftBracket then
                    text_box.Text = text_box.Text .. "["
                elseif input.KeyCode == Enum.KeyCode.RightBracket then
                    text_box.Text = text_box.Text .. "]"
                elseif input.KeyCode == Enum.KeyCode.Semicolon then
                    text_box.Text = text_box.Text .. ";"
                elseif input.KeyCode == Enum.KeyCode.Period then
                    text_box.Text = text_box.Text .. "."
                elseif input.KeyCode == Enum.KeyCode.Menu then
                    text_box.Text = text_box.Text .. ""
                elseif input.KeyCode == Enum.KeyCode.Delete then
                    text_box.Text = ""
                elseif input.KeyCode == Enum.KeyCode.Tab then
                    text_box.Text = text_box.Text .. "  "
                elseif input.KeyCode == Enum.KeyCode.CapsLock then
                    bools.capsLock = not bools.capsLock
                elseif bools.capsLock then
                    text_box.Text = text_box.Text .. string.upper(input.KeyCode.Name)
                elseif input.KeyCode.Name == "Backspace" then
                    local function remove() 
                        local text = text_box.Text
                        if #text > 0 then
                            text_box.Text = text:sub(1, #text - 1)
                        end
                    end
        
                    repeat
                        remove()
                        task.wait(.18)
                    until not services.UIS:IsKeyDown(Enum.KeyCode.Backspace)
                else
                    local isKeyModifier = false
                    for _, modifier in ipairs(keyModifiers) do
                        if input.KeyCode == modifier then
                            isKeyModifier = true
                            break
                        end
                    end
                    
                    if not isKeyModifier then
                        if services.UIS:IsKeyDown(Enum.KeyCode.LeftShift) then
                            text_box.Text = text_box.Text .. string.upper(input.KeyCode.Name)
                        else
                            text_box.Text = text_box.Text .. string.lower(input.KeyCode.Name)
                        end

                        if input.KeyCode == Enum.KeyCode.CapsLock then
                            bools.capsLock = not bools.capsLock
                        end
                    end
                end
            end
        end)              

        connections.update_comp = services.RS.Heartbeat:Connect(function()
            if not (flags.modal) then
                connections.update_comp:Disconnect()
            end

            text_cover.Size = vp
            text_area.Size = Vector2.new(vp.X - 80, 30)
            text_area.Position = Vector2.new(40, vp.Y / 2 - 10)
            task.wait()
        end)
    end

    function submenu_handler:add_submenu(name)
        local submenu_class = {
            Name = name,
            Comp = { },
            Y = 0,
            ActionOffset = 0,
            ActionIndex = 1,
            Actions = { },
            Manager = { }
        }

        local function initialize_comp(object) 
            table.insert(submenu_class.Comp, object)
        end

        local frame = Gui:draw_rect(menu_x, menu_y + menu_offset, menu_width, menu_height, menu_bg); frame.Transparency = menu_transparency;
        local text = draw_string(name, menu_x + 7, menu_y + menu_offset + 5);
        local arrow = draw_string(">", menu_x + menu_width - 20, frame.Position.Y + 6);

        init_f({ X = 0, Y = menu_offset, Width = menu_width, Object = frame });

        initialize_comp(frame)
        initialize_comp(text)
        initialize_comp(arrow)

        init_m({ X = 0, Y = menu_offset, Object = frame });
        init_m({ X = 7, Y = menu_offset + 5, Object = text });
        init_m({ X = menu_width - 20, Y = frame.Position.Y + 6 - menu_y, Object = arrow });

        local action_handler = {}

        function action_handler:add_checkbox(name, default, callback)
            local manager = {}
            local action_class = {
                Type = "checkbox",
                Name = name,
                Selectable = true,
                Value = default,
                Comp = { },
                UpdateComp = nil,
                Function = callback,
            }

            local function initialize_action_comp( object ) 
                table.insert( action_class.Comp, object )
            end

            local bFrame = Gui:draw_rect(menu_x, menu_y + submenu_class.ActionOffset, menu_width, menu_height, menu_bg); bFrame.Transparency = menu_transparency; bFrame.Visible = false;
            local bText = draw_string(name, menu_x + 28, menu_y + submenu_class.ActionOffset + 5); bText.Visible = false;
            local bDisplay = Gui:draw_rect(menu_x + 7, menu_y + submenu_class.ActionOffset + 7, 16, 16, Color3.fromRGB(255, 255, 255)); bDisplay.Visible = false;

            init_f({ X = 0, Y = submenu_class.ActionOffset, Width = menu_width, Object = bFrame });

            initialize_action_comp( bFrame );
            initialize_action_comp( bText );
            initialize_action_comp( bDisplay );

            init_m({ X = 0, Y = submenu_class.ActionOffset, Object = bFrame });
            init_m({ X = 28, Y = submenu_class.ActionOffset + 5, Object = bText });  
            init_m({ X = 7, Y = bDisplay.Position.Y - menu_y, Object = bDisplay });

            action_class.UpdateComp = function() 
                bDisplay.Filled = action_class.Value
            end

            pcall(action_class.UpdateComp)

            function manager:Set(val) 
                action_class.Value = val
                pcall(action_class.UpdateComp)
                local suc, req = pcall(action_class.Function, action_class.Value)
                if not suc then
                    error(req)
                end
            end

            function action_class:Set(val) 
                action_class.Value = val
                pcall(action_class.UpdateComp)
                local suc, req = pcall(action_class.Function, action_class.Value)
                if not suc then
                    error(req)
                end
            end

            table.insert(submenu_class.Actions, action_class)
            submenu_class.ActionOffset += menu_height
            return manager
        end

        function action_handler:add_slider(name, default, min, max, step, callback)
            local manager = {} 
            local action_class = {
                Type = "slider",
                Name = name,
                Selectable = true,
                Range = {min, max},
                Step = step,
                Value = default,
                Comp = { },
                UpdateComp = nil,
                Function = callback,
            }

            local function initialize_action_comp(object) 
                table.insert(action_class.Comp, object)
            end

            local format_type = nil

            if (step < 1) then
                format_type = tostring(step):match("%.(%d+)") or "0"
            else
                format_type = "0"
            end

            local currentY = submenu_class.ActionOffset

            local sFrame = Gui:draw_rect(menu_x, menu_y + currentY, menu_width, menu_height, menu_bg)
            sFrame.Transparency = menu_transparency
            sFrame.Visible = false

            local sText = draw_string(name, menu_x + 7, menu_y + currentY + 6)
            sText.Visible = false

            local sDisplay = draw_string(string.format("%." .. format_type .. "f", action_class.Value), sFrame.Position.X + sFrame.Size.X - 30, sFrame.Position.Y + 6); sDisplay.Visible = false
            sDisplay.Position = Vector2.new(sFrame.Position.X + sFrame.Size.X - sDisplay.TextBounds.X - 10, sFrame.Position.Y + 6);

            init_f({ X = 0, Y = currentY, Width = menu_width, Object = sFrame })

            initialize_action_comp(sFrame)
            initialize_action_comp(sText)
            initialize_action_comp(sDisplay)

            init_m({ X = 0, Y = currentY, Object = sFrame })
            init_m({ X = 7, Y = currentY + 6, Object = sText })
            init_m({ X = sDisplay.Position.X - menu_x, Y = sDisplay.Position.Y - menu_y, Object = sDisplay })

            action_class.UpdateComp = function() 
                sDisplay.Text = string.format("%." .. format_type .. "f", action_class.Value)
                sDisplay.Position = Vector2.new(sFrame.Position.X + sFrame.Size.X - sDisplay.TextBounds.X - 10, sFrame.Position.Y + 6)
            end

            pcall(action_class.UpdateComp)
            
            function action_class:Set(val) 
                action_class.Value = val
                pcall(action_class.UpdateComp)
                local suc, req = pcall(action_class.Function, action_class.Value)
                if not suc then
                    error(req)
                end
            end

            function manager:Set(val)
                action_class.Value = val
                pcall(action_class.UpdateComp)
                local suc, req = pcall(action_class.Function, action_class.Value)
                if not suc then
                    error(req)
                end
            end

            table.insert(submenu_class.Actions, action_class)
            submenu_class.ActionOffset += menu_height
            return manager
        end

        function action_handler:add_label(name) 
            local action_class = {
                Type = "label",
                Selectable = false,
                Name = name,
                Comp = { },
            }

            local function initialize_action_comp(object) 
                table.insert(action_class.Comp, object)
            end

            local lFrame = Gui:draw_rect(menu_x, menu_y + submenu_class.ActionOffset, menu_width, menu_height, menu_bg); lFrame.Transparency = menu_transparency; lFrame.Visible = false;
            local lText = draw_string(name, menu_x + menu_width / 2, menu_y + submenu_class.ActionOffset + 6); lText.Visible = false; lText.Center = true

            init_f({ X = 0, Y = submenu_class.ActionOffset, Width = menu_width, Object = lFrame });

            initialize_action_comp(lFrame);
            initialize_action_comp(lText);

            init_m({ X = 0, Y = submenu_class.ActionOffset, Object = lFrame });
            init_m({ X = menu_width / 2, Y = submenu_class.ActionOffset + 6, Object = lText });

            table.insert(submenu_class.Actions, action_class)
            submenu_class.ActionOffset += menu_height
        end

        function action_handler:add_button(name, callback) 
            local action_class = {
                Type = "button",
                Name = name,
                Selectable = true,
                Comp = { },
                Function = callback
            }

            local function initialize_action_comp(object) 
                table.insert(action_class.Comp, object)
            end

            local lFrame = Gui:draw_rect(menu_x, menu_y + submenu_class.ActionOffset, menu_width, menu_height, menu_bg); lFrame.Transparency = menu_transparency; lFrame.Visible = false;
            local lText = draw_string(name, menu_x + 7, menu_y + submenu_class.ActionOffset + 6); lText.Visible = false;

            init_f({ X = 0, Y = submenu_class.ActionOffset, Width = menu_width, Object = lFrame });

            initialize_action_comp(lFrame);
            initialize_action_comp(lText);

            init_m({ X = 0, Y = submenu_class.ActionOffset, Object = lFrame });
            init_m({ X = 7, Y = submenu_class.ActionOffset + 6, Object = lText });

            function action_class:Remove() 
                if (table.find(submenu_class.Actions, action_class)) then 
                    removeFTB(submenu_class.Actions, action_class)

                    lFrame:Remove()
                    lText:Remove()

                    submenu_class.ActionOffset -= menu_height
                end
            end

            table.insert(submenu_class.Actions, action_class)
            submenu_class.ActionOffset += menu_height
        end

        function action_handler:add_modal(name, callback) 
            local action_class = {
                Type = "modal",
                Name = name,
                Selectable = true,
                Comp = { },
                Function = callback,
                UpdateComp = nil
            }

            local function initialize_action_comp(object) 
                table.insert(action_class.Comp, object)
            end

            local lFrame = Gui:draw_rect(menu_x, menu_y + submenu_class.ActionOffset, menu_width, menu_height, menu_bg); lFrame.Transparency = menu_transparency; lFrame.Visible = false;
            local lText = draw_string(name, menu_x + 7, menu_y + submenu_class.ActionOffset + 6); lText.Visible = false;

            init_f({ X = 0, Y = submenu_class.ActionOffset, Width = menu_width, Object = lFrame });

            initialize_action_comp(lFrame);
            initialize_action_comp(lText);

            init_m({ X = 0, Y = submenu_class.ActionOffset, Object = lFrame });
            init_m({ X = 7, Y = submenu_class.ActionOffset + 6, Object = lText });

            action_class.StartModal = function() 
                Gui:create_text_modal(callback)
            end

            table.insert(submenu_class.Actions, action_class)
            submenu_class.ActionOffset += menu_height
        end

        function action_handler:add_mode(name, default, modes, callback)
            local manager = {}
            local action_class = {
                Type = "modes",
                Name = name,
                Selectable = true,
                Index = default, Modes = modes,
                Comp = { },
                Function = callback,
                UpdateComp = nil
            }

            local function initialize_action_comp(object) 
                table.insert(action_class.Comp, object)
            end

            local default = default

            if (action_class.Modes[default]) then
                default = default
            end

            local currentY = submenu_class.ActionOffset

            local mFrame = Gui:draw_rect(menu_x, menu_y + currentY, menu_width, menu_height, menu_bg); mFrame.Transparency = menu_transparency; mFrame.Visible = false;
            local mText = draw_string(name, menu_x + 7, menu_y + currentY + 6); mText.Visible = false;

            local mDisplay = draw_string(string.format("%s [%d/%d]", action_class.Modes[default], default, #action_class.Modes), menu_x + menu_width, mFrame.Position.Y + 6); mDisplay.Visible = false;
            mDisplay.Position = Vector2.new(mFrame.Position.X + mFrame.Size.X - mDisplay.TextBounds.X - 10, mFrame.Position.Y + 6);

            initialize_action_comp(mFrame)
            initialize_action_comp(mText)
            initialize_action_comp(mDisplay)

            init_f({ X = 0, Y = submenu_class.ActionOffset, Width = menu_width, Object = mFrame });

            init_m({ X = 0, Y = submenu_class.ActionOffset, Object = mFrame });
            init_m({ X = 7, Y = submenu_class.ActionOffset + 6, Object = mText });
            init_m({ X = mDisplay.Position.X - menu_x, Y = mDisplay.Position.Y - menu_y, Object = mDisplay });

            action_class.UpdateComp = function()
                mDisplay.Text = string.format("%s [%d/%d]", action_class.Modes[action_class.Index], action_class.Index, #action_class.Modes)
                mDisplay.Position = Vector2.new(mFrame.Position.X + mFrame.Size.X - mDisplay.TextBounds.X - 10, mFrame.Position.Y + 6)

                local suc, req = pcall(action_class.Function, action_class.Modes[action_class.Index])
                if not suc then
                    error(req)
                end
            end

            function manager:Set(val) 
                action_class.Index = table.find(action_class.Modes, val)
                pcall(action_class.UpdateComp)
                local suc, req = pcall(action_class.Function, action_class.Value)
                if not suc then
                    error(req)
                end
            end

            table.insert(submenu_class.Actions, action_class)
            submenu_class.ActionOffset += menu_height
            return manager
        end

        submenu_class.Y = menu_y + menu_offset

        table.insert(submenus, submenu_class)

        menu_offset += menu_height
        return action_handler
    end

    local function UpdateMenus() 
        for i, menu in pairs(submenus) do
            if table.find(submenus, menu) == submenu_index then
                menu.Comp[1].Color = Color3.fromRGB(255, 255, 255) 
                menu.Comp[2].Color = Color3.fromRGB(0, 0, 0)
                menu.Comp[3].Color = Color3.fromRGB(0, 0, 0)
                menu.Comp[1].Transparency = 1
            else
                menu.Comp[1].Color = menu_bg 
                menu.Comp[2].Color = Color3.fromRGB(255, 255, 255)
                menu.Comp[3].Color = Color3.fromRGB(255, 255, 255)
                menu.Comp[1].Transparency = menu_transparency
            end
        end
    end

    local function GetSelectedMenu() 
        local menu = nil
        for i, m in pairs(submenus) do
            if table.find(submenus, m) == submenu_index then
                menu = m
            end
        end

        return menu
    end
    
    local function UpdateSelectedMenu(menu) 
        for i, action in pairs(menu.Actions) do 
            if table.find(menu.Actions, action) == menu.ActionIndex then
                action.Comp[1].Transparency = 1
                action.Comp[1].Color = Color3.fromRGB(255, 255, 255)
                action.Comp[2].Color = Color3.fromRGB(0, 0, 0)

                if (action.Type == "checkbox") then
                    action.Comp[3].Color = Color3.fromRGB(0, 0, 0)
                end

                if (action.Type == "slider") then
                    action.Comp[3].Color = Color3.fromRGB(0, 0, 0)
                end

                if (action.Type == "modes") then
                    action.Comp[3].Color = Color3.fromRGB(0, 0, 0)
                end

                if (action.Type == "section") then
                    action.Comp[3].Color = Color3.fromRGB(0, 0, 0)
                end
            else
                action.Comp[1].Transparency = menu_transparency
                action.Comp[1].Color = menu_bg
                action.Comp[2].Color = Color3.fromRGB(255, 255 ,255)

                if (action.Type == "checkbox") then
                    action.Comp[3].Color = Color3.fromRGB(255, 255 ,255)
                end

                if (action.Type == "slider") then
                    action.Comp[3].Color = Color3.fromRGB(255, 255 ,255)
                end

                if (action.Type == "modes") then
                    action.Comp[3].Color = Color3.fromRGB(255, 255 ,255)
                end

                if (action.Type == "section") then
                    action.Comp[3].Color = Color3.fromRGB(255, 255 ,255)
                end
            end
        end
    end

    local function GetSelectedAction(menu) 
        local action = nil
        for i, a in pairs(menu.Actions) do 
            if table.find(menu.Actions, a) == menu.ActionIndex then
                action = a
            end
        end

        return action
    end

    pcall(UpdateMenus)

    connections.navigate_menus = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
        if (input.KeyCode == Enum.KeyCode.Down and not (flags.in_menus)) and not flags.modal then
            submenu_index += 1
            UpdateMenus()
            if (submenu_index == #submenus + 1) then
                submenu_index = 1
                UpdateMenus()
            end
        end

        if (input.KeyCode == Enum.KeyCode.Up and not (flags.in_menus)) and not flags.modal then
            submenu_index -= 1
            UpdateMenus()
            if (submenu_index == 0) then
                submenu_index = #submenus
                UpdateMenus()
            end
        end

        if (input.KeyCode == Enum.KeyCode.Return) and not (flags.in_menus)and not flags.modal then
            if not (flags.in_menus) then
                local menu = GetSelectedMenu()
                if (#menu.Actions > 0) then
                    local firstSelectableIndex = 1
                    while firstSelectableIndex <= #menu.Actions and not menu.Actions[firstSelectableIndex].Selectable do
                        firstSelectableIndex = firstSelectableIndex + 1
                    end
                    if firstSelectableIndex <= #menu.Actions then
                        for i, action in pairs(menu.Actions) do 
                            for _, comp in pairs(action.Comp) do 
                                comp.Visible = true
                            end
                        end

                        for i, submenu in pairs(submenus) do 
                            for _, comp in pairs(submenu.Comp) do 
                                comp.Visible = false
                            end
                        end

                        menu.ActionIndex = firstSelectableIndex
                        UpdateSelectedMenu(menu)
                        flags.in_menus = true
                        task.wait(.1)
                        flags.allow_action_control = true
                    else
                        flags.in_menus = false
                        flags.allow_action_control = false
                    end
                else
                    flags.in_menus = false
                    flags.allow_action_control = false
                end
            end
        end            
        
        if (input.KeyCode == Enum.KeyCode.Backspace and (flags.in_menus) and not (flags.actions_locked)) and not flags.modal then
            flags.in_menus = false
            flags.allow_action_control = false
            if not (flags.in_menus) and not (flags.allow_action_control) then
                local menu = GetSelectedMenu()
                if (#menu.Actions > 0) then
                    for i, action in pairs(menu.Actions) do 
                        for _, comp in pairs(action.Comp) do 
                            comp.Visible = false
                        end
                    end

                    for i, menu in pairs(submenus) do 
                        for _, comp in pairs(menu.Comp) do 
                            comp.Visible = true
                        end
                    end

                    UpdateSelectedMenu(menu)
                else
                    flags.in_menus = false
                    flags.allow_action_control = false
                end
            end
        end
    end)

    connections.navigate_actions = services.UIS.InputBegan:Connect(function(input, gameProcessedEvent)
        if not (flags.allow_action_control) and not flags.modal then
            return
        end

        if (input.KeyCode == Enum.KeyCode.Down and (flags.in_menus and flags.allow_action_control)) and not (flags.actions_locked) and not flags.modal then
            local menu = GetSelectedMenu()
            local actions = menu.Actions
            
            if (flags.in_menus) then
                local nextIndex = menu.ActionIndex + 1
                while nextIndex <= #actions and not actions[nextIndex].Selectable do
                    nextIndex = nextIndex + 1
                end
                if nextIndex <= #actions then
                    menu.ActionIndex = nextIndex
                    UpdateSelectedMenu(menu)
                else
                    nextIndex = 1
                    while nextIndex <= #actions and not actions[nextIndex].Selectable do
                        nextIndex = nextIndex + 1
                    end
                    if nextIndex <= #actions then
                        menu.ActionIndex = nextIndex
                        UpdateSelectedMenu(menu)
                    end
                end
            end
        end
        
        if (input.KeyCode == Enum.KeyCode.Up and (flags.in_menus and flags.allow_action_control)) and not (flags.actions_locked) and not flags.modal then
            local menu = GetSelectedMenu()
            local actions = menu.Actions
            
            if (flags.in_menus) then
                local nextIndex = menu.ActionIndex - 1
                while nextIndex >= 1 and not actions[nextIndex].Selectable do
                    nextIndex = nextIndex - 1
                end
                if nextIndex >= 1 then
                    menu.ActionIndex = nextIndex
                    UpdateSelectedMenu(menu)
                else
                    nextIndex = #actions
                    while nextIndex >= 1 and not actions[nextIndex].Selectable do
                        nextIndex = nextIndex - 1
                    end
                    if nextIndex >= 1 then
                        menu.ActionIndex = nextIndex
                        UpdateSelectedMenu(menu)
                    end
                end
            end
        end              

        if (input.KeyCode == Enum.KeyCode.Return and (flags.in_menus and flags.allow_action_control)) and not flags.modal then
            local menu = GetSelectedMenu()
            local action = GetSelectedAction(menu)

            if (action) then
                --> Handle action types

                if (action.Type == "checkbox") then
                    action.Value = not action.Value
                    local suc, req = pcall(action.UpdateComp); if not suc then error(req) end
                    local suc2, req2 = pcall(action.Function, action.Value); if not suc2 then error(req2) end
                end

                if (action.Type == "button") then
                    local suc, req = pcall(action.Function)
                    if not suc then
                        error(req)
                    end
                end

                if (action.Type == "modal") then
                    action.StartModal()
                end

                if (action.Type == "slider") then 
                    Gui:create_text_modal(function(val)
                        task.wait(.2) 
                        action:Set(tonumber(val))
                    end)
                end
            end
        end

        if (input.KeyCode == Enum.KeyCode.Right and not flags.modal) then
            local menu = GetSelectedMenu()
            local current = GetSelectedAction(menu)

            if (current.Type == "modes") then
                current.Index += 1
                pcall(current.UpdateComp)
                if (current.Index == #current.Modes + 1) then
                    current.Index = 1
                    pcall(current.UpdateComp)
                end
            end
        
            if (current.Type == "slider") then
                local s, r = pcall(current.UpdateComp); if not s then error(r) end
                local c, j = pcall(current.Function, current.Value); if not c then error(j) end
        
                repeat
                    task.wait(values.slider_delay / 100)
                    current.Value += current.Step
                    local s, r = pcall(current.UpdateComp); if not s then error(r) end
                    local c, j = pcall(current.Function, current.Value); if not c then error(j) end
        
                    if current.Value > current.Range[2] then
                        current.Value = current.Range[1]
                        local x, y = pcall(current.UpdateComp); if not s then error(r) end
                        local l, z = pcall(current.Function, current.Value); if not c then error(j) end
                    end
                until not services.UIS:IsKeyDown(Enum.KeyCode.Right)
            end
        end
        
        if (input.KeyCode == Enum.KeyCode.Left and not flags.modal) then
            local menu = GetSelectedMenu()
            local current = GetSelectedAction(menu)
        
            if (current.Type == "modes") then
                current.Index -= 1
                pcall(current.UpdateComp)
                if (current.Index == 0) then
                    current.Index = #current.Modes
                    pcall(current.UpdateComp)
                end
            end

            if (current.Type == "slider") then
                local s, r = pcall(current.UpdateComp); if not s then error(r) end
                local c, j = pcall(current.Function, current.Value); if not c then error(j) end
        
                repeat
                    task.wait(values.slider_delay / 100)
                    current.Value -= current.Step
                    local s, r = pcall(current.UpdateComp); if not s then error(r) end
                    local c, j = pcall(current.Function, current.Value); if not c then error(j) end
        
                    if current.Value < current.Range[1] then
                        current.Value = current.Range[2]
                        local x, y = pcall(current.UpdateComp); if not s then error(r) end
                        local l, z = pcall(current.Function, current.Value); if not c then error(j) end
                    end
                until not services.UIS:IsKeyDown(Enum.KeyCode.Left)
            end
        end
    end)

    task.defer(function()
        services.CAS:BindActionAtPriority("DisableArrowKeys", function() 
            return Enum.ContextActionResult.Sink;
        end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.Up, Enum.KeyCode.Down, Enum.KeyCode.Left, Enum.KeyCode.Right, Enum.KeyCode.Backspace)

        if not (isfolder(("%s"):format(s_dir))) then 
            makefolder(s_dir)
        end
        
        local scripts = submenu_handler:add_submenu("Scripts")
        local script_buttons = { }

        for i, x in pairs(listfiles(s_dir)) do 
            print(tostring(i), tostring(x))
        end

        local function create_script_buttons() 
            for i, s in pairs(listfiles(s_dir)) do 
                local button = scripts:add_button(string.match(tostring(s), "[^\\/]+$"), function() 
                    loadstring(readfile(("mystic/scripts/%s"):format(string.match(tostring(s), "[^\\/]+$"))))()
                end)

                table.insert(script_buttons, button)
            end
        end

        create_script_buttons()

        local m_settings = submenu_handler:add_submenu("Settings")

        local s_delay = m_settings:add_slider("Slider Delay", values.slider_delay, 1, 10, 0.1, function(value) 
            values.slider_delay = value / 100
        end)

        local pos_X = m_settings:add_slider("Position (X Axis)", menu_x, 0, workspace.CurrentCamera.ViewportSize.X - menu_width, 1, function(val)
            menu_x = val

            for i, r in pairs(movables) do 
                r.Object.Position = Vector2.new(menu_x + r.X, menu_y + r.Y)
            end
        end)

        local pos_Y = m_settings:add_slider("Position (Y Axis)", menu_y, 0, workspace.CurrentCamera.ViewportSize.Y - (menu_height), 1, function(val)
            menu_y = val

            for i, r in pairs(movables) do 
                r.Object.Position = Vector2.new(menu_x + r.X, menu_y + r.Y)
            end
        end)

        m_settings:add_button("Reset To Defaults", function() 
            s_delay:Set(0.01)
            pos_X:Set(MenuOptions.StartPos[1])
            pos_Y:Set(MenuOptions.StartPos[2])
        end)

        m_settings:add_modal("Save Configuration", MenuFunctions.Save)

        m_settings:add_modal("Load Configuration", function(t) 
            if (t ~= nil or " ") then 
                local suc, req = pcall(MenuFunctions.Load, 0, t)
                if not (suc) then 
                    error(req)
                end
            end
        end)

        m_settings:add_button("Quit", function() 
            for _, object in pairs(Gui.GUI_RENDERED) do 
                if object ~= nil then
                    object:Remove()
                end
            end

            for _, connection in pairs(connections) do 
                if connection ~= nil then
                    connection:Disconnect()
                end
            end

            for _, text_comp in pairs(game:GetService("CoreGui"):GetChildren()) do 
                if text_comp.Name == "TextComponent" then
                    text_comp:Destroy()
                end
            end

            getgenv().GLOBAL_ACTIONS = { }
            getgenv().CONFIGURATIONS = { }
            getgenv().RUNNING = false

            services.CAS:UnbindAction("DisableArrowKeys")
        end)
       
        local frame = Gui:draw_rect(menu_x, menu_y + menu_offset, menu_width, menu_height, Color3.fromRGB(28, 28, 28));
        local f_scroll = Gui:draw_image("https://raw.githubusercontent.com/wiIlow/mystic-icons/main/code.png", 
            menu_x + (menu_width / 2) - 5, menu_y + menu_offset + 4, 23, 23, 0)

        for i, sub in pairs(submenus) do 
            for i, action in pairs(sub.Actions) do 
                table.insert(getgenv().GLOBAL_ACTIONS, action)
            end
        end

        connections.hide_menu = services.UIS.InputBegan:Connect(function(input)
            if input.KeyCode == Enum.KeyCode.F4 and not flags.modal then
                for i, r in pairs(Gui.GUI_RENDERED) do
                    if r.Visible then
                        r.Visible = false
                    else
                        r.Visible = true
                    end
                end
            end
        end)            

        connections.update_context = services.RS.Heartbeat:Connect(function()
            context_menu_index.Text = string.format("%d/%d", submenu_index, #submenus)

            if (flags.in_menus) then
                local menu = GetSelectedMenu()
                current_menu = menu.Name
                context_title.Text = string.upper(current_menu)
            else
                current_menu = "menus"
                context_title.Text = string.upper(current_menu)
            end

            if (flags.in_menus) then
                local menu = GetSelectedMenu()
                context_menu_index.Text = string.format("%d/%d", menu.ActionIndex, #menu.Actions)
            else
                context_menu_index.Text = string.format("%d/%d", submenu_index, #submenus)
            end
        end)

        connections.update_bottom_frame = services.RS.Heartbeat:Connect(function()
            local menu = GetSelectedMenu()

            if (flags.in_menus) then
                frame.Position = Vector2.new(menu_x, menu_y + menu.ActionOffset)
                f_scroll.Position = Vector2.new(menu_x + (menu_width / 2) - 5, menu_y + menu.ActionOffset + 4)
            else
                frame.Position = Vector2.new(menu_x, menu_y + menu_offset)
                f_scroll.Position = Vector2.new(menu_x + (menu_width / 2) - 5, menu_y + menu_offset + 4)
            end

            task.wait()
        end)

        UpdateMenus()
    end)

    getgenv().API = { }

    function API:run_async(callback, ...) 
        local co = coroutine.create(callback)
        local args = {...}
        local function resume() 
            coroutine.resume(co, table.unpack(args))
        end 
        task.spawn(resume)
    end

    function API:get_menu(name) 
        local menu; for i, menus in pairs(submenus) do 
            if (menus.Name == name) then 
                menu = menus
                break
            end
        end
        return menu
    end

    function API:set_action_value(name, value)
        for i, menus in pairs(submenus) do 
            for i, action in pairs(menus.Actions) do 
                if (action.Name == name) then 
                    action:Set(value)
                    break
                end
            end
        end
    end

    function API:get_action_value(name) 
        for i, menus in pairs(submenus) do 
            for i, action in pairs(menus.Actions) do 
                if (action.Name == name) then 
                    return action.Value
                end
            end
        end
    end

    function API:set_action_active(name, v) 
        for i, menus in pairs(submenus) do 
            for i, action in pairs(menus.Actions) do 
                if (action.Name == name) then 
                    action.Selectable = v
                end
            end
        end
    end

    return submenu_handler
end

local gui = interface:BeginMenu({ StartPos = { 100, 100 }, Saves = true })

local t_1 = gui:add_submenu("Client")

t_1:add_label("Flags")

t_1:add_checkbox("Flag 1", false, function(v) print(v) end)
t_1:add_checkbox("Flag 2", true, function(v) print(v) end)
t_1:add_checkbox("Flag 3", true, function(v) print(v) end)

t_1:add_label("Client")

t_1:add_slider("WalkSpeed", 16, 16, 5000, 1, function(v) game:GetService("Players").LocalPlayer.Character.Humanoid.WalkSpeed = v end)
t_1:add_slider("JumpPower", 16, 16, 100, 1, function(v) game:GetService("Players").LocalPlayer.Character.Humanoid.JumpPower = v end)