local ws = syn.websocket.connect("ws://localhost:3000");

local function SendRequest(msg) 
    return game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(("[API/🧠]: %s"):format(msg), "All")
end

local LocalPlayer = game:GetService('Players').LocalPlayer;

function removeQuotes(str)
    if str:sub(1, 1) == '"' and str:sub(-1) == '"' then
      return str:sub(2, -2)
    else
      return str
    end
end  

LocalPlayer.Chatted:Connect(function(message, recipient)
    if recipient then
        return
    end

    ws:Send(message);
end)

ws.OnMessage:Connect(function(msg) 
    if LocalPlayer then 
        local message = string.gsub(removeQuotes(msg), "\\", "")
        SendRequest(message)
        print(message)
    end
end)
